var topology = {
	_initialize: function() {
		if(jQuery("#map-nms").size() < 1) {
			jQuery("body").append("<div id='map-nms'></div>");
		}
		if(jQuery("#map-device").size() < 1) {
			jQuery("#map-nms").append("<div id='map-device'></div>");
		}
	},
	add: function(node) {
	},
	focus: function(node) {
	},
	expand: function(node, depth) {
	},
	createDeviceView: function(device) {
		console.debug("START: createDeviceView", device);
		var color = 0x0000FF;
		if(!device) {
			console.error("INVALID DATA: createDeviceView", device);
			return null;
		}

		var mainGeometry;
		//mainGeometry = new THREE.BoxGeometry(128, 128, 128);	//	least memory
		mainGeometry = new THREE.SphereGeometry(64, 16, 16);	//	least memory
		mainGeometry.scale(1, 1, 1);
		
		var mainMaterial;
		mainMaterial = new THREE.MeshLambertMaterial({color: color, transparent: false, opacity: 0.9});
		//mainMaterial = new THREE.MeshBasicMaterial({color: color, transparent: true, opacity: 0.2});
		//mainMaterial = new THREE.MeshBasicMaterial({color: color, transparent: true, opacity: 0.2, wireframe: false, vertexColors: THREE.FaceColors});
		//mainMaterial = new THREE.MeshPhongMaterial({color: 0x0000FF, transparent: true, opacity: 0.5});
		//mainMaterial = new THREE.MeshPhongMaterial({color: 0x0000FF, transparent: false, opacity: 0.5});
		//mainMaterial = new THREE.MeshNormalMaterial({color: color, transparent: true, opacity: 0.5});
		
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(0, 0, 0);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);
		mainMaterial.onClickHandler = function() {
			topology.expand(device.deviceId, 1);
		};

		var position = {
			x: 0,
			y: 0,
			z: 128
		};

		var nameTag = _cmdb._createNameTag(device.cmdbDevice.hostname || "nonamed", 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);

		mainMesh.add(nameTag);
		console.debug("FINISH: createDeviceView", device);
		return mainMesh;
	},
	device: function(deviceId) {
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/topology/meta/device/" + deviceId + "/json",
			//"url": andold.threejs._contextPath + "http://batch2.nms2.navercorp.com/topology/meta/device/" + deviceId + "/json",
			"async": true,
			"data": {
				deviceId: deviceId
			},
			"success": function(data) {
				console.log("success", data);
				var device = data.nmsDevice;
				if(jQuery("#map-device").find("div#map-device-" + device.assetId).size() < 1) {
					var text = "<div id='map-device-" + device.deviceId + "'>" + JSON.stringify(device) + "</div>";
					console.debug(text);
					jQuery("#map-device").append(text);
				}
				topology.createDeviceView(device);
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	},

	dummy: function() {}
};

/**
 * dao section start. {get, set} x {device, interface, relation}
 */
var dao = {
	prefixUrl: "",
	containerMapId: "map-container",
	deviceMapId: "map-device",
	interfaceMapId: "map-interface",
	relationMapId: "map-relation"
};
dao.initialize = function(prefixUrl) {
	dao.prefixUrl = prefixUrl;
	
	if (jQuery("body").find("div#" + dao.containerMapId).length <= 0) {
		jQuery("body").append("<div id='" + dao.containerMapId + "'></div>");
	}

	if (jQuery("div#" + dao.containerMapId).find("div#" + dao.deviceMapId).length <= 0) {
		jQuery("div#" + dao.containerMapId).append("<div id='" + dao.deviceMapId + "'></div>");
	}
	if (jQuery("div#" + dao.containerMapId).find("div#" + dao.interfaceMapId).length <= 0) {
		jQuery("div#" + dao.containerMapId).append("<div id='" + dao.interfaceMapId + "'></div>");
	}
	if (jQuery("div#" + dao.containerMapId).find("div#" + dao.relationMapId).length <= 0) {
		jQuery("div#" + dao.containerMapId).append("<div id='" + dao.relationMapId + "'></div>");
	}
};
dao.getDevice	=	function(deviceNo) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.deviceMapId + " div#devcie-" + deviceNo;
	if(jQuery(selector).size() > 0) {
		return JSON.parse(jQuery(selector).text());
	}	//	if(jQuery(selector).size() == 0) {

	return null;
};
dao.setDevice	=	function(device) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.deviceMapId;
	var text = "<div id='devcie-" + device.deviceNo + "'>" + JSON.stringify(device) + "</div>";
	jQuery(selector).append(text);
};
dao.getInterface	=	function(interfaceId) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.interfaceMapId + " div#interface-" + interfaceId;
	if(jQuery(selector).size() > 0) {
		return JSON.parse(jQuery(selector).text());
	}

	return null;
};
dao.setInterface	=	function(interfac) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.interfaceMapId;
	var text = "<div id='interface-" + interfac.interfaceId + "'>" + JSON.stringify(interfac) + "</div>";
	jQuery(selector).append(text);
};
dao.getRelation	=	function(relationId) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.relationMapId + " div#relation-" + relationId;
	if(jQuery(selector).size() > 0) {
		return JSON.parse(jQuery(selector).text());
	}

	return null;
};
dao.setRelation	=	function(relation) {
	var selector = "div#" + dao.containerMapId + " div#" + dao.relationMapId;
	var text = "<div id='interface-" + relation.relationId + "'>" + JSON.stringify(relation) + "</div>";
	jQuery(selector).append(text);
};
/**
 * dao section end. {get, set} x {device, interface, relation}
 */

/**
 * utility section start.
 */
var utility	=	{
};
utility.toStringObject	=	function(object, offset) {
	var html ="";
	var htmlObject ="";
	var htmlArray ="";
	for (var key in object) {
		if(object.hasOwnProperty(key)) {
			if(object[key] == null || object[key] == "" || typeof object[key] === 'function') {
				continue;
			}

			if(Object.prototype.toString.call(object[key]) === '[object Array]') {
				htmlArray += "<dl class='dl-horizontal mg-reset indent'>"
						+ "<dt onclick='jQuery(this).next().toggle();'>" + key + "</dt> "
						+ "<dd class='hidden-on-load'>" + utility.toStringArray(object[key], offset + 1) + "</dd>"
						+ "</dl>";
				continue;
			}
			if(Object.prototype.toString.call(object[key]) === '[object Object]') {
				htmlObject += "<dl class='dl-horizontal mg-reset indent'>"
						+ "<dt onclick='jQuery(this).next().toggle();'>" + key + "</dt> "
						+ "<dd class='hidden-on-load'>" + utility.toStringObject(object[key], offset + 1) + "</dd>"
						+ "</dl>";
				continue;
			}
			if (key == "deviceNo" || key == "targetDeviceNo") {
				html += "<dl class='dl-horizontal mg-reset '>"
					+ "<dt onclick='jQuery(this).next().toggle();'>" + key + "</dt> "
					+ "<dd>"
					+ object[key]

					+ "<span class='label label-default mg-left-lg' onclick='searchInterface(" + object[key] + ", this);'>"
					+ "i/f"
					+ "</span>"

					+ "<span class='label label-default mg-left-lg' onclick='searchRelation(" + object[key] + ", this);'>"
					+ "rel"
					+ "</span>"

					+ "<br></dd>"
					+ "</dl>";
				continue;
			}

			html += "<dl class='dl-horizontal mg-reset '>"
					+ "<dt>" + key + "</dt> "
					+ "<dd>" + object[key] + "</dd>"
					+ "</dl>";
		}	//	if(object.hasOwnProperty(key)) {
	}
	return html + htmlObject + htmlArray;
};
utility.toStringArray	=	function(array, offset) {
	var html ="";
	for (var cx = 0; cx < array.length;cx++) {
/* 		html += "<dl class='dl-horizontal mg-reset indent'>"
					+ "<dt>" + cx + "</dt> "
					+ "<dd>" + toStringObject(array[cx], offset + 1) + "</dd>"
					+ "</dl>";
 */
		html += "<div class='indent'>" + utility.toStringObject(array[cx], offset + 1) + "</div>";
 	}
	return html;
};
/**
 * utility section end.
 */

/**
 * view section start.
 */
var	view = {
};
view.info	=	function(device) {
	jQuery("#infoBox div.panel-body").append(utility.toStringObject(device, 1) + "<br>");
};
view.createDevice	=	function(device) {
	console.debug("START: createDevice", device);
	var color = 0x0000FF;
	if(!device) {
		console.error("INVALID DATA: createDeviceView", device);
		return null;
	}

	var mainGeometry;
	mainGeometry = new THREE.SphereGeometry(64, 16, 16);	//	least memory
	mainGeometry.scale(1, 1, 1);
	
	var mainMaterial;
	mainMaterial = new THREE.MeshLambertMaterial({color: color, transparent: false, opacity: 0.9});
	
	var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
	mainMesh.position.set(0, 0, 0);
	mainMesh.castShadow = true;
	mainMesh.receiveShadow = true;
	andold.threejs._scene.add(mainMesh);
	andold.threejs._objects.push(mainMesh);
	mainMaterial.onClickHandler = function() {
		topology.expand(device.deviceId, 1);
	};

	var position = {
		x: 0,
		y: 0,
		z: 128
	};

	var nameTag = _cmdb._createNameTag(device.cmdbDevice.hostname || "nonamed", 16, position, 0xC00000, 0x808080, 4);
	andold.threejs._scene.add(nameTag);

	mainMesh.add(nameTag);
	console.debug("FINISH: createDeviceView", device);
	return mainMesh;
};
/**
 * view section end. {get, set} x {device, interface, relation}
 */

/**
 * service section start.
 */
var service = {
	prefixUrl: ""
};
service.initialize	=	function(prefixUrl) {
	service.prefixUrl	=	prefixUrl;
	dao.initialize(prefixUrl);
};
service.showDevice	=	function(deviceId) {
	var device = dao.getDevice(deviceId);
	if (device) {
		view.createDevice(device);
		view.info(device);
		return;
	}

	jQuery.ajax({
		"url": service.prefixUrl + "/device/" + deviceId + "/json",
		"dataType" : "jsonp",
		"async": true,
		"data": {},
		"success": function(data) {
			console.log("success", data);
			if (data && data.nmsDevice) {
				var device = data.nmsDevice;
				dao.setDevice(device);
				view.createDevice(device);
				view.info(device);
			}
		}	//	"success": function(data) {
	});	//	jQuery.ajax({
};
service.showMacTable	=	function(element, sourceDeviceNo, sourceInterfaceNo, targetMacAddress, targetDeviceNo, targetInterfaceNo, sourceMacAddress) {
	if (sourceDeviceNo && sourceDeviceNo > 0) {
		jQuery.ajax({
			"url": service.prefixUrl + "/mac/json",
			"dataType" : "jsonp",
			"async": true,
			"data": {
				deviceNo: sourceDeviceNo,
				interfaceNo: sourceInterfaceNo,
				macAddress: targetMacAddress
			},
			"success": function(data) {
				console.log("success", data);
				if (data && data.listNmsMacTable) {
					var listNmsMacTable = data.listNmsMacTable;
					jQuery(element).parent().append(utility.toStringArray(listNmsMacTable));
					return;
				}
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	}	//	if (sourceDeviceNo && sourceDeviceNo > 0) {

	if (targetDeviceNo && targetDeviceNo > 0) {
		jQuery.ajax({
			"url": service.prefixUrl + "/mac/json",
			"dataType" : "jsonp",
			"async": true,
			"data": {
				deviceNo: targetDeviceNo,
				interfaceNo: targetInterfaceNo,
				macAddress: sourceMacAddress
			},
			"success": function(data) {
				console.log("success", data);
				if (data && data.listNmsMacTable) {
					var listNmsMacTable = data.listNmsMacTable;
					jQuery(element).parent().append(utility.toStringArray(listNmsMacTable));
					return;
				}
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	}	//	if (targetDeviceNo && targetDeviceNo > 0) {
};
service.showArpTable	=	function(element, sourceDeviceNo, targetIpAddress, targetMacAddress, targetDeviceNo, sourceIpAddress, sourceMacAddress) {
	if (sourceDeviceNo && sourceDeviceNo > 0) {
		jQuery.ajax({
			"url": service.prefixUrl + "/arp/json",
			"dataType" : "jsonp",
			"async": true,
			"data": {
				deviceNo: sourceDeviceNo,
				ipAddress: targetIpAddress,
				macAddress: targetMacAddress
			},
			"success": function(data) {
				console.log("success", data);
				if (data && data.listNmsArp) {
					var listNmsArp = data.listNmsArp;
					jQuery(element).parent().append(utility.toStringArray(listNmsArp));
					return;
				}
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	}	//	if (sourceDeviceNo && sourceDeviceNo > 0) {

	if (targetDeviceNo && targetDeviceNo > 0) {
		jQuery.ajax({
			"url": service.prefixUrl + "/arp/json",
			"dataType" : "jsonp",
			"async": true,
			"data": {
				deviceNo: targetDeviceNo,
				ipAddress: sourceIpAddress,
				macAddress: sourceMacAddress
			},
			"success": function(data) {
				console.log("success", data);
				if (data && data.listNmsArp) {
					var listNmsArp = data.listNmsArp;
					jQuery(element).parent().append(utility.toStringArray(listNmsArp));
					return;
				}
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	}	//	if (targetDeviceNo && targetDeviceNo > 0) {
};
/**
 * service section end.
 */

andold = andold || {};
andold["topology"] = topology;
