var andold = {
	sort: function(element, index) {
		element = element || this;
		var column = index;
		if (isNaN(element)) {
			var base = jQuery(element).closest("table").find("thead");
			if (isNaN(index)) {
				column = base.find("th").index(element);
			} else {
				column = index;
			}
		} else {
			var base = jQuery(this);
			column = index;
		}
		console.log("sort " + column + "th column.");
		var	existAsc = jQuery(element).has("span.glyphicon-sort-by-alphabet").length > 0;
		var existDesc = jQuery(element).has("span.glyphicon-sort-by-alphabet-alt").length > 0;
		var asc = existAsc && !jQuery(element).find("span.glyphicon-sort-by-alphabet").hasClass("hidden");
		var desc = existDesc && !jQuery(element).find("span.glyphicon-sort-by-alphabet-alt").hasClass("hidden");
		if(!existAsc) {
			jQuery(element).prepend("<span class='glyphicon glyphicon-sort-by-alphabet hidden mg-right-sm'> ");
		}
		if(!existDesc) {
			jQuery(element).prepend("<span class='glyphicon glyphicon-sort-by-alphabet-alt hidden mg-right-sm'> ");
		}
		if(asc || desc) {
			jQuery(element).find("span.glyphicon").toggleClass("glyphicon-sort-by-alphabet glyphicon-sort-by-alphabet-alt");
			return andold._reverse(jQuery(element).closest("table").find("tbody tr"));
		}

		jQuery(element).closest("table").find("thead span.glyphicon").addClass("hidden");
		jQuery(element).find("span.glyphicon-sort-by-alphabet" + (!desc ? "" : "-alt")).removeClass("hidden");

		var body = jQuery(element).closest("table").find("tbody tr");
		andold._sort(body, column, !desc, 0, body.length - 1, /^(\-|\+)?([0-9,]+|Infinity)$/.test(andold._value(body, column, 0, false)));
	},
	_swap: function(base, left, right) {
		var t = base.eq(right).html();
		base.eq(right).html(base.eq(left).html());
		base.eq(left).html(t);
		return t;
	},
	_value: function(base, column, index, isNumber) {
		var text = base.eq(index).find("td:eq(" + column + ")").text().trim();
		return isNumber ? parseInt(text.replace(/,/g, "")) : text;
	},
	_compare: function(asc, x, y) {
		return asc ? (x < y) : (x > y);
	},
	_sort: function(base, column, asc, left, right, isNumber) {
		if(left >= right) {
			return;
		}
		var pivot = andold._value(base, column, left, isNumber);
		var i = left;
		var j = right + 1;
		do {
			do {
				i++;
			} while (andold._compare(asc, andold._value(base, column, i, isNumber), pivot) && i <= right);
			do {
				j--;
			} while (andold._compare(asc, pivot, andold._value(base, column, j, isNumber)));
			if(i < j) {
				andold._swap(base, i, j);;
			}
		} while (i < j);
		andold._swap(base, left, j);;
		andold._sort(base, column, asc, left, j - 1, isNumber);
		andold._sort(base, column, asc, j + 1, right, isNumber);
	},
	_reverse: function(base) {
		for(var cx = 0, size = parseInt(base.length / 2);cx < size;cx++) {
			andold._swap(base, cx, base.length - 1 - cx);
		}
	}
};

var _action_highlight = {
	//	@private
	_container: null,
	_camera: null,
	_controls: null,
	_renderer: null,
	_scene: null,
	_raycaster: null,
	_stats: null,
	_mouse: {},

	_theta: 0,
	_radius: 1000,
	_INTERSECTED: null,
	initialize: function(camera, renderer, controls, container, scene) {
		_action_highlight._camera = camera;
		_action_highlight._renderer = renderer;
		_action_highlight._controls = controls;
		_action_highlight._container = container || _threejs._container[0];
		_action_highlight._scene = scene || _threejs._scene;
		
		_action_highlight._raycaster = new THREE.Raycaster();
		_action_highlight._stats = new Stats();
		_action_highlight._stats.domElement.style.position = 'absolute';
		_action_highlight._stats.domElement.style.top = '0px';
		_action_highlight._container.appendChild(_action_highlight._stats.domElement);
	
		_action_highlight._renderer.domElement.addEventListener("mousemove", _action_highlight._onDocumentMouseMove, false);
		_action_highlight._renderer.domElement.addEventListener("mousedown", _action_highlight._onDocumentMouseDown, false);
		window.addEventListener("resize", _action_highlight._onWindowResize, false);
		
		_action_highlight._animate();
	},
	_animate: function() {
		requestAnimationFrame(_action_highlight._animate);
		_action_highlight._render();
		_action_highlight._stats.update();
	},
	_render: function() {
		_action_highlight._theta += 0.1;
	
		_action_highlight._camera.position.x = _action_highlight._radius * Math.sin(THREE.Math.degToRad(_action_highlight._theta));
		_action_highlight._camera.position.y = _action_highlight._radius * Math.sin(THREE.Math.degToRad(_action_highlight._theta));
		_action_highlight._camera.position.z = _action_highlight._radius * Math.cos(THREE.Math.degToRad(_action_highlight._theta));
		_action_highlight._camera.lookAt(_action_highlight._scene.position);
		_action_highlight._camera.updateMatrixWorld();
		_action_highlight._raycaster.setFromCamera(_action_highlight._mouse, _action_highlight._camera);
	
		var intersects = _action_highlight._raycaster.intersectObjects(_action_highlight._scene.children);
		if (intersects.length > 0) {
			if(_action_highlight._INTERSECTED != intersects[0].object) {
				if (_action_highlight._INTERSECTED) {
					//	Uncaught TypeError: Cannot read property 'setHex' of undefined
					if (_action_highlight._INTERSECTED.material && _action_highlight._INTERSECTED.material.emissive && _action_highlight._INTERSECTED.material.emissive.setHex) {
						_action_highlight._INTERSECTED.material.emissive.setHex(_action_highlight._INTERSECTED.currentHex);
					}
				}
	
				_action_highlight._INTERSECTED = intersects[0].object;
				//	Uncaught TypeError: Cannot read property 'getHex' of undefined
				if (_action_highlight._INTERSECTED && _action_highlight._INTERSECTED.material && _action_highlight._INTERSECTED.material.emissive && _action_highlight._INTERSECTED.material.emissive.getHex) {
					_action_highlight._INTERSECTED.currentHex = _action_highlight._INTERSECTED.material.emissive.getHex();
				}
				//	Uncaught TypeError: Cannot read property 'setHex' of undefined
				if (_action_highlight._INTERSECTED && _action_highlight._INTERSECTED.material && _action_highlight._INTERSECTED.material.emissive && _action_highlight._INTERSECTED.material.emissive.setHex) {
					_action_highlight._INTERSECTED.material.emissive.setHex(0xff0000);
				}
			}
		} else {
			if (_action_highlight._INTERSECTED) {
				//	Uncaught TypeError: Cannot read property 'setHex' of undefined
				if (_action_highlight._INTERSECTED.material && _action_highlight._INTERSECTED.material.emissive && _action_highlight._INTERSECTED.material.emissive.setHex) {
					_action_highlight._INTERSECTED.material.emissive.setHex(_action_highlight._INTERSECTED.currentHex);
				}
			}
			_action_highlight._INTERSECTED = null;
		}
		_action_highlight._renderer.render(_action_highlight._scene, _action_highlight._camera);
	},
	_onWindowResize: function() {
		_action_highlight._camera.aspect = window.innerWidth / window.innerHeight;
		_action_highlight._camera.updateProjectionMatrix();

		_action_highlight._renderer.setSize(window.innerWidth, window.innerHeight);
		//_action_highlight._renderer.setSize(jQuery(_action_highlight._container).innerWidth(), jQuery(_action_highlight._container).innerHeight());
	},
	_onDocumentMouseMove: function(evt) {
		evt.preventDefault();
		_action_highlight._mouse.x = ( evt.clientX / window.innerWidth ) * 2 - 1;
		_action_highlight._mouse.y = - ( evt.clientY / window.innerHeight ) * 2 + 1;
	},
	_onDocumentMouseDown: function(evt) {
		evt.preventDefault();
		if (_action_highlight._INTERSECTED && _action_highlight._INTERSECTED.material && _action_highlight._INTERSECTED.material.onClickHandler) {
			_action_highlight._INTERSECTED.material.onClickHandler();
		}
	}
};

var _action_grab = {
	_container: null,
	_camera: null,
	_controls: null,
	_renderer: null,
	_scene: null,
	_raycaster: null,
	_stats: null,
	_mouse: {},
	_raycaster: null,
	_mouse: null,
	_offset: null,
	_plane: null,
	_INTERSECTED: null,
	_SELECTED: null,

	initialize: function(camera, renderer, scene, controls, container) {
		_action_grab._camera = camera;
		_action_grab._renderer = renderer;
		_action_grab._scene = scene;
		_action_grab._controls = controls;
		_action_grab._container = container || _threejs._container[0];

		_action_grab._raycaster = new THREE.Raycaster();
		_action_grab._mouse = new THREE.Vector2();
		_action_grab._offset = new THREE.Vector3();
		_action_grab._plane = new THREE.Mesh(
						new THREE.PlaneBufferGeometry(2000, 2000, 8, 8),
						new THREE.MeshBasicMaterial({visible: false})
					);
		_action_grab._scene.add(_action_grab._plane);

		_action_grab._renderer.domElement.addEventListener("mousemove", _action_grab._onDocumentMouseMove, false);
		_action_grab._renderer.domElement.addEventListener("mousedown", _action_grab._onDocumentMouseDown, false);
		_action_grab._renderer.domElement.addEventListener("mouseup", _action_grab._onDocumentMouseUp, false);
		window.addEventListener("resize", _action_grab._onWindowResize, false);
		
		_action_grab._render();
	},
	_render: function () {
	    requestAnimationFrame(_action_grab._render);
	    _action_grab._controls.update();
	    _action_grab._renderer.render(_action_grab._scene, _action_grab._camera);
	},
	_onWindowResize: function() {
		_action_grab._camera.aspect = window.innerWidth / window.innerHeight;
		_action_grab._camera.updateProjectionMatrix();
		_action_grab._renderer.setSize(window.innerWidth, window.innerHeight);
	},
	_onDocumentMouseMove: function(evt) {
		evt.preventDefault();
		_action_grab._mouse.x = (evt.clientX / window.innerWidth) * 2 - 1;
		_action_grab._mouse.y = -(evt.clientY / window.innerHeight) * 2 + 1;

		_action_grab._raycaster.setFromCamera(_action_grab._mouse, _action_grab._camera);
		//	이미 잡고 있는게 있어?
		if (_action_grab._SELECTED) {
			//	그럼 움직여.
			var intersects = _action_grab._raycaster.intersectObject(_action_grab._plane);
			if (intersects.length > 0) {
				var difference = intersects[0].point.sub(_action_grab._offset);
				_action_grab._SELECTED["position"].copy(difference);
				for (var cx = 0, size = _action_grab._SELECTED["children"].length;cx < size;cx++) {
					//_action_grab._SELECTED["children"][cx]["position"].copy(difference);
				}
			}
			return;
		}
		
		//	밑에 있는게 있는지 알아바바.
		var intersects = _action_grab._raycaster.intersectObjects(andold.threejs._objects);
		//	걸리는게 있어?
		if (intersects.length > 0) {
			//	잡고 있는게 아니야?
			if (_action_grab._INTERSECTED != intersects[0].object) {
				//	원래것은 원래대로.
				if (_action_grab._INTERSECTED &&_action_grab._INTERSECTED.material && _action_grab._INTERSECTED.material.emissive && _action_grab._INTERSECTED.material.emissive.setHex) {
					_action_grab._INTERSECTED.material.emissive.setHex(_action_grab._INTERSECTED.currentHex);
				}

				_action_grab._INTERSECTED = intersects[0].object;

				//	highlight 하자.
				if (_action_grab._INTERSECTED && _action_grab._INTERSECTED.material && _action_grab._INTERSECTED.material.emissive && _action_grab._INTERSECTED.material.emissive.getHex) {
					_action_grab._INTERSECTED.currentHex = _action_grab._INTERSECTED.material.emissive.getHex();
				}
				if (_action_grab._INTERSECTED && _action_grab._INTERSECTED.material && _action_grab._INTERSECTED.material.emissive && _action_grab._INTERSECTED.material.emissive.setHex) {
					_action_grab._INTERSECTED.material.emissive.setHex(0xff0000);
				}

				_action_grab._plane["position"].copy( _action_grab._INTERSECTED["position"] );
				_action_grab._plane.lookAt( _action_grab._camera["position"] );
			}
			jQuery(_action_grab._container).css("cursor", "pointer");
		} else {
			if (_action_grab._INTERSECTED &&_action_grab._INTERSECTED.material && _action_grab._INTERSECTED.material.emissive && _action_grab._INTERSECTED.material.emissive.setHex) {
				_action_grab._INTERSECTED.material.emissive.setHex(_action_grab._INTERSECTED.currentHex);
			}
			_action_grab._INTERSECTED = null;
			jQuery(_action_grab._container).css("cursor", "auto");
		}
	},
	_onDocumentMouseDown: function(evt) {
		evt.preventDefault();
		//	뭔가 있다면, 하기로 했던거 해봐.
		if (_action_grab._INTERSECTED && _action_grab._INTERSECTED.material && _action_grab._INTERSECTED.material.onClickHandler) {
			_action_grab._INTERSECTED.material.onClickHandler();
		}
		_action_grab._raycaster.setFromCamera(_action_grab._mouse, _action_grab._camera);
		var intersects = _action_grab._raycaster.intersectObjects(andold.threejs._objects);
		//	잡힌게 있어?
		if (intersects.length > 0) {
			_action_grab._controls.enabled = false;
			_action_grab._SELECTED = intersects[0].object;
			var intersects = _action_grab._raycaster.intersectObject(_action_grab._plane);
			if (intersects.length > 0) {
				_action_grab._offset.copy(intersects[0].point).sub(_action_grab._plane["position"]);
			}
			jQuery(_action_grab._container).css("cursor", "move");
		}
	},
	_onDocumentMouseUp: function(evt) {
	    evt.preventDefault();
	    _action_grab._controls.enabled = true;
	    if (_action_grab._INTERSECTED) {
	    	_action_grab._plane["position"].copy(_action_grab._INTERSECTED["position"]);
	    	_action_grab._SELECTED = null;
	    }
	    jQuery(_action_grab._container).css("cursor", "auto");
	}
};

var _action = {
	highlight: _action_highlight,
	grab: _action_grab
};

var _threejs = {
	_contextPath: "/idcassign/batch",
	_container: null,
	_stats: null,
	_camera: null,
	_controls: null,
	_scene: null,
	_renderer: null,
	_objects: [],

	start: function(selector, contextPath, action) {
		if (contextPath) {
			andold.threejs._contextPath = contextPath;
		}
		_threejs._container = jQuery(selector);

		andold["threejs"]["cmdb"]._initialize();

		_threejs._initializeCamera();
		_threejs._initializeControl();
		_threejs._initializeScene();
		_threejs._initializeLight();
		_threejs._initializeRenderer();
		_threejs._initializeMaterial();
		_threejs._initializeAction(action);
		
		//_threejs._render();
	},
	
	_idcGroupMargin: 100,
	_idcGroupSize: {x: 100, y: 50, z: 500},
	_idcGroupPosition: {x: -500, y: -300, z: 0},
	addIdcGroup: function(idcGroup) {
		var margin = _threejs._idcGroupMargin;
		var size = _threejs._idcGroupSize;
		var position = _threejs._idcGroupPosition;
		
		var geometry = new THREE.BoxGeometry(size.x, size.y, size.z);
		var color = Math.random() * 0x40C0 + 0x000000;
		var texture = _threejs._createLabelTexture(idcGroup.idcGroupName, 0, 0, 0, 16, "black", "white", 1);
		var material = new THREE.MeshLambertMaterial({color: color, map: texture, transparent: true, opacity: 0.8});
		var object = new THREE.Mesh(geometry, material);
		object["position"].x = position.x;
		object["position"].y = position.y;
		object["position"].z = position.z;
		object.castShadow = true;
		object.receiveShadow = true;
		_threejs._scene.add( object );
		_threejs._objects.push( object );
		
		var label = _threejs._doorplate(" " + idcGroup.idcGroupName + " ", size);
		label["position"].set(position.x , position.y, position.z + size.z / 2 + 1);
		_threejs._scene.add( label );
		_threejs._objects.push( label );

		position.x += (size.x + margin);
		if(position.x >= 500) {
			position.x = -500;
			position.y += (size.y + margin);
		}
	},
	_doorplate: function(text, size) {
		var fontsize = 24;
		var borderThickness = 2;
		
		var canvas = document.createElement('canvas');
		var context = canvas.getContext('2d');
		context.font = fontsize + "px monospace";
		
		// get size data (height depends only on font size)
		var metrics = context.measureText(text);
		var textWidth = metrics.width;
		
		canvas.width = size.x;
		canvas.height = size.y;

		context.fillStyle = "rgba(255, 255, 255, 0.9)";
		context.strokeStyle = "rgba(0, 0, 128, 0.9)";
		context.lineWidth = borderThickness;
		_threejs._roundRect(context, borderThickness/2, borderThickness/2, size.x - borderThickness, size.y - borderThickness, 6);

		context.fillStyle = "rgba(0, 0, 0, 0.9)";
		context.fillText(text, borderThickness, fontsize + borderThickness);
	    
		// canvas contents will be used for a texture
		var texture = new THREE.Texture(canvas) 
		texture.needsUpdate = true;
	      
	    var material = new THREE.MeshBasicMaterial( {map: texture, side:THREE.DoubleSide } );
	    material.transparent = true;

	    var mesh = new THREE.Mesh(
			new THREE.PlaneGeometry(canvas.width, canvas.height),
			material
	    );
	    return mesh;
	},
	_addIdcGroupSprite: function(idcGroup) {
		var margin = _threejs._idcGroupMargin;
		var size = _threejs._idcGroupSize;
		var position = _threejs._idcGroupPosition;
		
		var geometry = new THREE.BoxGeometry(size.x, size.y, size.z);
		var color = Math.random() * 0x40C0 + 0x000000;
		var texture = _threejs._createLabelTexture(idcGroup.idcGroupName, 0, 0, 0, 16, "black", "white", 1);
		var material = new THREE.MeshLambertMaterial({color: color, map: texture, transparent: true, opacity: 0.8});
		var object = new THREE.Mesh(geometry, material);
		object["position"].x = position.x;
		object["position"].y = position.y;
		object["position"].z = position.z;
		object.castShadow = true;
		object.receiveShadow = true;
		_threejs._scene.add( object );
		_threejs._objects.push( object );
		
		var spritey = _threejs._makeTextSprite(idcGroup.idcGroupName, { fontsize: 24, borderColor: {r:0, g:0, b:128, a:1.0}, backgroundColor: {r:255, g:255, b:255, a:0.8} } );
		spritey["position"].set(position.x, position.y, position.z + size.z / 2 + 4);
		_threejs._scene.add( spritey );
		_threejs._objects.push( spritey );

		position.x += (size.x + margin);
		if(position.x >= 500) {
			position.x = -500;
			position.y += (size.y + margin);
		}
	},
	_makeTextSprite: function(message, parameters )		{
		if ( parameters === undefined ) parameters = {};
		var fontface = parameters.hasOwnProperty("fontface") ? parameters["fontface"] : "Arial";
		var fontsize = parameters.hasOwnProperty("fontsize") ? parameters["fontsize"] : 18;
		var borderThickness = parameters.hasOwnProperty("borderThickness") ? parameters["borderThickness"] : 4;
		var borderColor = parameters.hasOwnProperty("borderColor") ? parameters["borderColor"] : { r:0, g:0, b:0, a:1.0 };
		var backgroundColor = parameters.hasOwnProperty("backgroundColor") ? parameters["backgroundColor"] : { r:255, g:255, b:255, a:1.0 };
		var canvas = document.createElement('canvas');
		var context = canvas.getContext('2d');
		context.font = "Bold " + fontsize + "px " + fontface;
	    
		// get size data (height depends only on font size)
		var metrics = context.measureText( message );
		var textWidth = metrics.width;
		
		// background color
		context.fillStyle   = "rgba(" + backgroundColor.r + "," + backgroundColor.g + ","
									  + backgroundColor.b + "," + backgroundColor.a + ")";
		// border color
		context.strokeStyle = "rgba(" + borderColor.r + "," + borderColor.g + ","
									  + borderColor.b + "," + borderColor.a + ")";

		context.lineWidth = borderThickness;
		_threejs._roundRect(context, borderThickness/2, borderThickness/2, textWidth + borderThickness, fontsize * 1.4 + borderThickness, 6);
		// 1.4 is extra height factor for text below baseline: g,j,p,q.
		
		// text color
		context.fillStyle = "rgba(0, 0, 0, 1.0)";

		context.fillText( message, borderThickness, fontsize + borderThickness);
		
		// canvas contents will be used for a texture
		var texture = new THREE.Texture(canvas) 
		texture.needsUpdate = true;

		//var spriteMaterial = new THREE.SpriteMaterial({ map: texture, useScreenCoordinates: false, alignment: spriteAlignment } );
		var spriteMaterial = new THREE.SpriteMaterial({ map: texture, useScreenCoordinates: false} );
		var sprite = new THREE.Sprite( spriteMaterial );
		sprite.scale.set(100,50,1.0);
		return sprite;	
	},

	// function for drawing rounded rectangles
	_roundRect: function(ctx, x, y, w, h, r)		{
	    ctx.beginPath();
	    ctx.moveTo(x+r, y);
	    ctx.lineTo(x+w-r, y);
	    ctx.quadraticCurveTo(x+w, y, x+w, y+r);
	    ctx.lineTo(x+w, y+h-r);
	    ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
	    ctx.lineTo(x+r, y+h);
	    ctx.quadraticCurveTo(x, y+h, x, y+h-r);
	    ctx.lineTo(x, y+r);
	    ctx.quadraticCurveTo(x, y, x+r, y);
	    ctx.closePath();
	    ctx.fill();
		ctx.stroke();   
	},
	_addIdcGroupBox: function(idcGroup) {
		var margin = _threejs._idcGroupMargin;
		var size = _threejs._idcGroupSize;
		var position = _threejs._idcGroupPosition;
		
		var geometry = new THREE.BoxGeometry(size.x, size.y, size.z);
		var color = Math.random() * 0x40C0 + 0x000000;
		var texture = _threejs._createLabelTexture(idcGroup.idcGroupName, 0, 0, 0, 16, "black", "white", 1);
		var material = new THREE.MeshLambertMaterial({color: color, map: texture, transparent: true, opacity: 0.8});
		var object = new THREE.Mesh(geometry, material);
		object["position"].x = position.x;
		object["position"].y = position.y;
		object["position"].z = position.z;
		object.castShadow = true;
		object.receiveShadow = true;
		_threejs._scene.add( object );
		_threejs._objects.push( object );
		position.x += (size.x + margin);
		if(position.x >= 500) {
			position.x = -500;
			position.y += (size.y + margin);
		}
	},
	_addIdcGroupSphere: function(idcGroup) {
		var margin = _threejs._idcGroupMargin;
		var size = _threejs._idcGroupSize;
		var position = _threejs._idcGroupPosition;
		
		var geometry = new THREE.SphereGeometry(size.x, 8, 8);
		var color = Math.random() * 0x40C0 + 0x000000;
		var texture = _threejs._createLabelTexture(idcGroup.idcGroupName, 0, 0, 0, 16, "black", "white", 1);
		var material = new THREE.MeshLambertMaterial({color: color, map: texture, transparent: true, opacity: 0.8});
		var sphere = new THREE.Mesh(geometry, material);
		sphere["position"].set(position.x, position.y, position.z);
		sphere.castShadow = true;
		sphere.receiveShadow = true;
		_threejs._scene.add( sphere );
		_threejs._objects.push( sphere );

		position.x += (size.x * 2 + margin);
		if(position.x >= 500) {
			position.x = -500;
			position.y += (size.x * 2 + margin);
		}
	},
	_initializeCamera: function() {
		var ratio = _threejs._container.innerWidth() / _threejs._container.innerHeight();
		_threejs._camera = new THREE.PerspectiveCamera(70, ratio, 1, 10000);
		_threejs._camera.position.z = 1000;
	},
	_initializeControl: function() {
		_threejs._controls = new THREE.TrackballControls( _threejs._camera );
		_threejs._controls.rotateSpeed = 1.0;
		_threejs._controls.zoomSpeed = 1.2;
		_threejs._controls.panSpeed = 0.8;
		_threejs._controls.noZoom = false;
		_threejs._controls.noPan = false;
		_threejs._controls.staticMoving = true;
		_threejs._controls.dynamicDampingFactor = 0.3;
	},
	_initializeScene: function() {
		_threejs._scene = new THREE.Scene();
//		_threejs._scene.fog = new THREE.Fog( 0x000000, 1500, 4000 );
	},
	_initializeLight: function() {
		var light;
/*		light = new THREE.AmbientLight( 0x505050 );
		light = new THREE.AmbientLight(0xFFFFFF);
		_threejs._scene.add( light );
*/
		light = new THREE.DirectionalLight(0xffffff, 1);
		light.position.set( 1, 1, 1 ).normalize();
		_threejs._scene.add( light );

		light = new THREE.DirectionalLight(0xffffff, 1);
		light.position.set( -1, 1, -1 ).normalize();
		//_threejs._scene.add( light );

		light = new THREE.DirectionalLight(0xffffff, 1);
		light.position.set( -1, 1, 1 ).normalize();
		//_threejs._scene.add( light );

		light = new THREE.DirectionalLight(0xffffff, 1);
		light.position.set( 1, 1, -1 ).normalize();
		//_threejs._scene.add( light );

		var hemiLight = new THREE.HemisphereLight( 0xffffff, 0xffffff, 0.6 );
		hemiLight.color.setHSL( 0.6, 1, 0.6 );
		hemiLight.groundColor.setHSL( 0.095, 1, 0.75 );
		hemiLight.position.set( 0, 500, 0 );
		//_threejs._scene.add( hemiLight );

		var spotLight = new THREE.SpotLight( 0xffffff );
		spotLight.position.set( 100, 1000, 100 );
		spotLight.castShadow = true;
		spotLight.shadowMapWidth = 1024;
		spotLight.shadowMapHeight = 1024;
		spotLight.shadowCameraNear = 500;
		spotLight.shadowCameraFar = 4000;
		spotLight.shadowCameraFov = 30;
		//_threejs._scene.add( spotLight );
	},
	_createCubeTexture: function(text) {
		var canvas = document.createElement('canvas');
		canvas.id     = "hiddenCanvas";
		canvas.width  = 512;
		canvas.height = 128;
		canvas.style.display   = "none";
		var body = document.getElementsByTagName("body")[0];
		body.appendChild(canvas);        

		var cubeImage = document.getElementById('hiddenCanvas');
		var ctx = cubeImage.getContext('2d');
		ctx.beginPath();
		ctx.rect(0, 0, ctx.canvas.width, ctx.canvas.height);            
		ctx.fillStyle = 'rgba(255,255,255,0)';
		ctx.fill();
		ctx.fillStyle = 'black';
		ctx.font = "65px Arial";
		ctx.textAlign = 'center';            
		ctx.fillText(text, ctx.canvas.width / 2, ctx.canvas.height / 2);
		ctx.restore();        

		var gl = _threejs._renderer.getContext();
		var texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, texture);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

		gl.bindTexture(gl.TEXTURE_2D, texture);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cubeImage);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
		gl.generateMipmap(gl.TEXTURE_2D);
		gl.bindTexture(gl.TEXTURE_2D, null);

		return texture;
	},
	_createCubeTexture1: function(text, width, height) {
		var gl = _threejs._renderer.getContext();
		var canvas = document.createElement("canvas");
		var textConstext = canvas.getContext("2d");
		var fontsize = 20;
		
		textConstext.canvas.width  = width;
		textConstext.canvas.height = height;
		textConstext.font = "" + fontsize + "px Arial";
		textConstext.textAlign = "center";
		textConstext.textBaseline = "middle";
		textConstext.fillStyle = "black";
		textConstext.clearRect(0, 0, textConstext.canvas.width, textConstext.canvas.height);
		textConstext.fillText(text, width / 2, height / 2);
		console.debug(textConstext.canvas);

		// create text texture.
		var textCanvas = textConstext.canvas;
		var textWidth  = textCanvas.width;
		var textHeight = textCanvas.height;
		var texture = new THREE.Texture(canvas);
		texture.needsUpdate = true;
		return texture;
	},
	_getPowerOfTwo: function(value, pow) {
		var pow = pow || 1;
		while(pow<value) {
			pow *= 2;
		}
		return pow;
	},
	_measureText: function(ctx, textToMeasure) {
		return ctx.measureText(textToMeasure).width;
	},
	_createMultilineText: function(ctx, textToWrite, maxWidth, text) {
		textToWrite = textToWrite.replace("\n"," ");
		var currentText = textToWrite;
		var futureText;
		var subWidth = 0;
		var maxLineWidth = 0;
		
		var wordArray = textToWrite.split(" ");
		var wordsInCurrent, wordArrayLength;
		wordsInCurrent = wordArrayLength = wordArray.length;
		
		// Reduce currentText until it is less than maxWidth or is a single word
		// futureText var keeps track of text not yet written to a text line
		while (_threejs._measureText(ctx, currentText) > maxWidth && wordsInCurrent > 1) {
			wordsInCurrent--;
			var linebreak = false;
			
			currentText = futureText = "";
			for(var i = 0; i < wordArrayLength; i++) {
				if (i < wordsInCurrent) {
					currentText += wordArray[i];
					if (i+1 < wordsInCurrent) { currentText += " "; }
				}
				else {
					futureText += wordArray[i];
					if(i+1 < wordArrayLength) { futureText += " "; }
				}
			}
		}
		text.push(currentText); // Write this line of text to the array
		maxLineWidth = _threejs._measureText(ctx, currentText);
		
		// If there is any text left to be written call the function again
		if(futureText) {
			subWidth = _threejs._createMultilineText(ctx, futureText, maxWidth, text);
			if (subWidth > maxLineWidth) { 
				maxLineWidth = subWidth;
			}
		}
		
		// Return the maximum line width
		return maxLineWidth;
	},
	_createLabelTextureMultiLine: function(text, x, y, z, size, color, backGroundColor, backgroundMargin) {
		var textResult = [];
		if(!backgroundMargin) {
			backgroundMargin = 50;
		}

		var canvas = document.createElement("canvas");
		var context = canvas.getContext("2d");
		context.font = size + "pt Arial";
		
		var maxWidth = _threejs._createMultilineText(context, text, 128, textResult);
		var canvasX = _threejs._getPowerOfTwo(maxWidth);
		var canvasY = _threejs._getPowerOfTwo(size*(textResult.length+1));
		canvas.width = canvasX;
		canvas.height = canvasY;
		var textX = canvasX/2;
		var offset = (canvasY - size*(textResult.length+1)) * 0.5;
		for(var i = 0; i < textResult.length; i++) {
			var textY = (i+1)*size + offset;
			context.fillText(textResult[i], textX,  textY);
		}
		
		if(backGroundColor) {
			context.fillStyle = backGroundColor;
			context.fillRect(0, 0, canvas.width, canvas.height);
		}
		context.textAlign = "center";
		context.textBaseline = "middle";
		context.fillStyle = color;
		var texture = new THREE.Texture(canvas);
		texture.needsUpdate = true;
		return texture;
	},
	_createLabelTexture: function(text, x, y, z, fontsize, color, backGroundColor, backgroundMargin) {
		var textResult = [];
		if(!backgroundMargin) {
			backgroundMargin = 50;
		}

		var canvas = document.createElement("canvas");
		var context = canvas.getContext("2d");
		context.font = fontsize + "pt Arial";
		canvas.width = text.length * 8;
		canvas.height = 16;
		if(backGroundColor) {
			context.fillStyle = backGroundColor;
			context.fillRect(0, 0, canvas.width, canvas.height);
		}
		context.textAlign = "center";
		context.textBaseline = "middle";
		context.fillStyle = color;
		context.fillText(text, canvas.width / 2, canvas.height / 2);
		var texture = new THREE.Texture(canvas);
		texture.needsUpdate = true;
		return texture;
	},
	_initializeMaterialSample: function(count) {
		var geometry = new THREE.BoxGeometry( 40, 40, 40);
		for ( var i = 0; i < count; i ++ ) {
			var color = Math.random() * 0xC0 + 0x000000;
			var texture = _threejs._createLabelTexture(
							"andold's " + i + "th text.",
							0, 0, 0,
							16,
							"green",
							"white",
							1
						);
			var material = new THREE.MeshLambertMaterial({color: color, map: texture});
			var object = new THREE.Mesh(geometry, material);
			
			var x = Math.random() * 1000 - 500;
			var y = Math.random() * 600 - 300;
			var z = Math.random() * 800 - 400;

			object["position"].x = x;
			object["position"].y = y;
			object["position"].z = z;

			object.rotation.x = Math.random() * 2 * Math.PI;
			object.rotation.y = Math.random() * 2 * Math.PI;
			object.rotation.z = Math.random() * 2 * Math.PI;

			object.scale.x = Math.random() * 2 + 1;
			object.scale.y = Math.random() * 2 + 1;
			object.scale.z = Math.random() * 2 + 1;

			object.castShadow = true;
			object.receiveShadow = true;

			_threejs._scene.add( object );
			_threejs._objects.push( object ); 
		}
	},
	_initializeMaterialSampleSphere: function() {
		var texture = _threejs._createLabelTexture(
						"andold's sample sphere.",
						0, 0, 0,
						16,
						"green",
						"white",
						1
					);
		var geometry = new THREE.SphereGeometry(40, 32, 32);
		var material = new THREE.MeshLambertMaterial( {color: 0x0040ff, map: texture} );
		var sphere = new THREE.Mesh( geometry, material );
		sphere["position"].set(2, 4, 2);
		sphere.castShadow = true;
		sphere.receiveShadow = true;
		_threejs._scene.add( sphere );
		_threejs._objects.push( sphere );
		
	},
	_initializeMaterialGround: function() {
		//	바닥
		var geometry = new THREE.BoxGeometry(2000, 1, 2000);
		var textureLoader = new THREE.TextureLoader();
		var texture = textureLoader.load(_threejs._contextPath + "/image/collection-tree-15.png");
		texture.wrapS = THREE.RepeatWrapping;
		texture.wrapT = THREE.RepeatWrapping;
		texture.repeat.set(16, 16);
		if(texture && texture.image && texture.image.height) {
			if (texture.image.height < texture.image.width) {
				texture.offset = texture.image.height / texture.image.width;
			} else {
				texture.offset = texture.image.width / texture.image.height;
			}
		} else {
			texture && console.error(texture);
			texture && texture.image && console.log(texture.image);
			texture && texture.image && texture.image.height && console.log(texture.image.height);
		}
		var material = new THREE.MeshLambertMaterial({color: "white", map: texture, transparent: false, opacity: 0.5});
		var object = new THREE.Mesh(geometry, material);
		object["position"].set(0, -1, 0);
		object.castShadow = true;
		object.receiveShadow = true;
		_threejs._scene.add( object );
		_threejs._objects.push( object );
	},
	_initializeAxis: function() {
		var axisHelper = new THREE.AxisHelper(1000);
		_threejs._scene.add(axisHelper);
	},
	_initializeMaterial: function() {
		//_threejs._initializeMaterialSample(1);
		//_threejs._initializeMaterialSampleSphere();
		//_threejs._initializeMaterialGround();
		_threejs._initializeAxis();
	},
	_initializeRenderer: function() {
		_threejs._renderer = new THREE.WebGLRenderer( { antialias: true } );
		//_threejs._renderer.setClearColor( 0xf0f0f0, 0.5);
		_threejs._renderer.setClearColor(0xFFFFFF, 0.5);
		_threejs._renderer.setClearColor(0xFFFFFF, 1);
		//_threejs._renderer.setClearColor(0xFFFFFF, 0);
		_threejs._renderer.setPixelRatio( window.devicePixelRatio );
		_threejs._renderer.setSize(_threejs._container.innerWidth(), _threejs._container.innerHeight());
		_threejs._renderer.sortObjects = false;

		_threejs._renderer.shadowMap.enabled = true;
		_threejs._renderer.shadowMap.type = THREE.PCFShadowMap;

		_threejs._container.append( _threejs._renderer.domElement );

		var info = document.createElement( 'div' );
		info.style["position"] = 'absolute';
		info.style.top = '10px';
		info.style.width = '100%';
		info.style.textAlign = 'center';
		_threejs._container.append( info );

/*		_threejs._stats = new Stats();
		_threejs._stats.domElement.style["position"] = 'absolute';
		_threejs._stats.domElement.style.top = '0px';
		_threejs._container.append( _threejs._stats.domElement );
*/
	},
	_initializeAction: function(action) {
		switch(action) {
			case 0:
				return _action_highlight.initialize(_threejs._camera, _threejs._renderer, _threejs._controls, _threejs._container[0]);
			case 1:
				return _action_grab.initialize(_threejs._camera, _threejs._renderer, _threejs._scene, _threejs._controls, _threejs._container[0]);
			default:
				return _action_grab.initialize(_threejs._camera, _threejs._renderer, _threejs._scene, _threejs._controls, _threejs._container[0]);
		}
	},
	_render: function () {
	    requestAnimationFrame(_threejs._render);
	    _threejs._controls.update();
	    _threejs._renderer.render(_threejs._scene, _threejs._camera);
	}
};

var _computer_size = {
	x: 128,
	y: 32,
	z: 128
};
var _cmdb = {
	_computer: {
		color: 0xFF0000,
		size:	{
			x: _computer_size.x,
			y: _computer_size.y,
			z: _computer_size.z
		},
		texture:	null
	},
	_rack: {
		color: 0x8080FF,
		size:	{
			x: _computer_size.x - 4,
			y: _computer_size.y,
			z: _computer_size.z - 2
		},
		texture:	null
	},
	_rackColumn: {
		color: 0xFFFFFF,
		size:	{
			x: _computer_size.x * 5 / 4,
			y: _computer_size.y,
			z: _computer_size.z * 5 / 4
		},
		texture:	null
	},
	_idcZone: {
		color: 0xFFFFFF,
		size:	{
			x: _computer_size.x * 4 / 3,
			y: _computer_size.y,
			z: _computer_size.z * 4 / 3
		},
		texture:	null
	},
	
	_idcGroup: {
		color: 0x0000FF,
		size:	{
			x: _computer_size.x * 4 / 3,
			y: _computer_size.y,
			z: _computer_size.z * 4 / 3
		},
		texture:	null
	},
	
	_mapComputer: new Map(),
	_mapRack: new Map(),
	_mapRackColumn: new Map(),
	_mapIdcZone: new Map(),
	
	_initialize: function() {
		var textureLoader = new THREE.TextureLoader();
		_cmdb._computer.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-10.jpg");
		_cmdb._computer.texture.wrapS = THREE.RepeatWrapping;
		_cmdb._computer.texture.wrapT = THREE.RepeatWrapping;
		_cmdb._computer.texture.repeat.set(1, 1);
		
		//_cmdb._rack.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-17.png");
		_cmdb._rack.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-02.png");
		_cmdb._rack.texture.wrapS = THREE.RepeatWrapping;
		_cmdb._rack.texture.wrapT = THREE.RepeatWrapping;
		
		_cmdb._rackColumn.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-17.png");
		_cmdb._rackColumn.texture.wrapS = THREE.RepeatWrapping;
		_cmdb._rackColumn.texture.wrapT = THREE.RepeatWrapping;

		_cmdb._idcZone.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-17.png");
		_cmdb._idcZone.texture.wrapS = THREE.RepeatWrapping;
		_cmdb._idcZone.texture.wrapT = THREE.RepeatWrapping;
		
		_cmdb._idcGroup.texture = textureLoader.load(andold.threejs._contextPath + "/image/collection-tree-17.png");
		_cmdb._idcGroup.texture.wrapS = THREE.RepeatWrapping;
		_cmdb._idcGroup.texture.wrapT = THREE.RepeatWrapping;
		
		if(jQuery("#map-computer").size() < 1) {
			jQuery("body").append("<div id='map-computer'></div>");
		}
		if(jQuery("#map-rack").size() < 1) {
			jQuery("body").append("<div id='map-rack'></div>");
		}
		if(jQuery("#map-rack-column").size() < 1) {
			jQuery("body").append("<div id='map-rack-column'></div>");
		}
		if(jQuery("#map-idc-zone").size() < 1) {
			jQuery("body").append("<div id='map-idc-zone'></div>");
		}
		if(jQuery("#map-idc-group").size() < 1) {
			jQuery("body").append("<div id='map-idc-group'></div>");
		}
	},
	_createNameTag: function(name, fontsize, position, fcolor, scolor, height) {
		if (!name || !name.length || !fontsize) {
			console.warn("invalid data:: ", name, fontsize, position, fcolor, scolor, height);
			return;
		}
		var size = {
			x: _threejs._getPowerOfTwo(fontsize * name.length) / 3,
			y: 32
		};
		var meshDooreplate = _threejs._doorplate(name, size);
		meshDooreplate.position.x = position.x - size.x / 2;
		meshDooreplate.position.y = position.y;
		meshDooreplate.position.z = position.z + 8;
		return meshDooreplate;
		//	text geometry
		var textGeometry = new THREE.TextGeometry(name, {
			size: fontsize,
			height: height,
			curveSegments: 8,

			font: "helvetiker",
			weight: "bold",
			style: "normal",

			bevelThickness: 1,
			bevelSize: 1.5,
			bevelEnabled: height > 2,

			material: 0,
			extrudeMaterial: 1
		});
		var textMaterial = new THREE.MeshFaceMaterial( [
			new THREE.MeshPhongMaterial( { color: fcolor, shading: THREE.FlatShading } ), // front
			new THREE.MeshPhongMaterial( { color: scolor, shading: THREE.SmoothShading } ) // side
		] );
		var textMesh = new THREE.Mesh(textGeometry, textMaterial);

		textMesh.position.x = position.x;
		textMesh.position.y = position.y;
		textMesh.position.z = position.z;

		return textMesh;
	},
	_createComputerView1: function(computer) {
		console.debug("START: _createComputerView", computer);
		if(!computer || computer.view) {
			console.error("INVALID DATA: _createComputerView", computer);
			return;
		}
		var color = _cmdb._computer.color;
		var size = _cmdb._computer.size;

		var mainGeometry = new THREE.BoxGeometry(size.x, size.y, size.z);
		mainGeometry.scale(1, computer.unitSize, 1);
		mainGeometry.rotateX(Math.PI / 4);
		var label = computer["hostname"] + " : " + computer["holeNumber"];
		//var mainTexture = andold.threejs._createLabelTexture(label, computer.position.x, computer.position.y, computer.position.z, 16, "black", "white", 0.8);
		//var mainMaterial = new THREE.MeshLambertMaterial({color: color, map: mainTexture, transparent: true, opacity: 0.5});
		//var mainMaterial = new THREE.MeshLambertMaterial({color: color, transparent: true, opacity: 0.5});
		var mainMaterial = new THREE.MeshLambertMaterial({color: color, map: _cmdb._computer.texture, transparent: false, opacity: 0.2});
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh["position"].x = computer["position"].x;
		mainMesh["position"].y = computer["position"].y;
		mainMesh["position"].z = computer["position"].z;
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateAsset(computer, 1);
		};

		var position = {
			x: computer["position"].x - size.x / 2 + 4,
			y: computer["position"].y - size.y / 4,
			z: computer["position"].z + size.z / 2
		};
		var nameTag = _cmdb._createNameTag(computer.hostname + " " + computer.unitSize + " " + computer.holeNumber, 4, position, 0x404080, 0xFFFFFF, 1);
		andold.threejs._scene.add(nameTag);
		andold.threejs._objects.push(nameTag);

		computer.view = {
			main: mainMesh,
			tag: nameTag
		};

		console.debug("FINISH: _createComputerView", computer);
	},
	_createComputerView: function(computer) {
		console.debug("START: _createComputerView", computer);
		if(!computer) {
			console.error("INVALID DATA: _createComputerView", computer);
			return null;
		}
		var color = _cmdb._computer.color;
		var size = _cmdb._computer.size;

		var mainGeometry;
		mainGeometry = new THREE.BoxGeometry(size.x, size.y, size.z);	//	least memory
		//mainGeometry = new THREE.CylinderGeometry(size.x / 2, size.x / 2, size.y, 32);	//	tolerent memory
		//mainGeometry = new THREE.TorusGeometry(size.x / 2, 16, 8, 16);	mainGeometry.rotateX(Math.PI / 2);	//	OOM
		mainGeometry.scale(1, computer.unitSize, 1);
		
		var mainMaterial;
		//mainMaterial = new THREE.MeshLambertMaterial({color: color, transparent: true, opacity: 0.5});
		//mainMaterial = new THREE.MeshBasicMaterial({color: color, transparent: true, opacity: 0.2});
		//mainMaterial = new THREE.MeshBasicMaterial({color: color, transparent: true, opacity: 0.2, wireframe: false, vertexColors: THREE.FaceColors});
		mainMaterial = new THREE.MeshPhongMaterial({color: color, transparent: true, opacity: 0.5});
		//mainMaterial = new THREE.MeshNormalMaterial({color: color, transparent: true, opacity: 0.5});
		
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(computer.position.x, computer.position.y, computer.position.z);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateAsset(computer.assetId, 1);
		};

		var position = {
			x: _cmdb._computer.size.x / 2,
			y: _cmdb._computer.size.y / 2 * 0,
			z: size.x / 2 + 8
		};

		var nameTag = _cmdb._createNameTag(computer.hostname, 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);
		//andold.threejs._objects.push(nameTag);

		mainMesh.add(nameTag);
		console.debug("FINISH: _createComputerView", computer);
		return mainMesh;
	},
	_createRackColumnView: function(rackColumn) {
		console.debug("START: _createRackColumnView", rackColumn);

		//	main geometry
		var mainGeometry = new THREE.BoxGeometry(_cmdb._rackColumn.size.x, _cmdb._rackColumn.size.y, _cmdb._rackColumn.size.z);
		var scale = (rackColumn && rackColumn.children) ? rackColumn.children.length : 1;
		mainGeometry.scale(scale, 1, 1);
		//	main texture
		var mainTexture = _cmdb._rackColumn.texture;
		mainTexture.repeat.set(_cmdb._rackColumn.size.x / 32, _cmdb._rackColumn.size.y / 32);
		//	main material
		var mainMaterial = new THREE.MeshLambertMaterial({color: _cmdb._rackColumn.color, map: mainTexture, transparent: false, opacity: 0.2});
		//	main mesh
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(rackColumn.position.x + _cmdb._rackColumn.size.x * scale / 2, rackColumn.position.y, rackColumn.position.z);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateRackColumn(rackColumn.rackColumnCode, 1);
		};
		
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);

		var position = {
			x: rackColumn.position.x,
			y: rackColumn.position.y + _cmdb._rackColumn.size.y / 2,
			z: rackColumn.position.z + _cmdb._rackColumn.size.z / 2
		};

		var nameTag = _cmdb._createNameTag(rackColumn["rackColumnName"], 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);

		rackColumn.view = {
			main: mainMesh,
			tag: nameTag
		};

		console.debug("FINISH: _createRackColumnView", rackColumn);
	},
	_getRack1: function(rackCode) {
		return _cmdb._mapRack.get(rackCode);
	},
	_getRack: function(rackCode) {
		if(!rackCode) {
			return null;
		}
		
		var selector = jQuery("#map-rack");
		if(!selector || !selector.size || selector.size() < 1) {
			return null;
		}
		selector = selector.find("div#map-rack-" + rackCode);
		if(!selector || !selector.size || selector.size() < 1 || !selector.text) {
			return null;
		}
		
		return JSON.parse(selector.text());
	},
	_setRack: function(rack) {
		jQuery("#map-rack").find("div#map-rack-" + rack.rackCode).text(JSON.stringify(rack));
	},
	_setRackColumn: function(rackColumn) {
		jQuery("#map-rack-column").find("div#map-rack-column-" + rackColumn.rackColumnCode).text(JSON.stringify(rackColumn));
	},
	_registerRack1: function(rack) {
		var mapRack = _cmdb._mapRack;
		if(!mapRack.has(rack.rackCode)) {
			mapRack.set(rack.rackCode, rack);
		}
		return mapRack.get(rack.rackCode);
	},
	_registerRack: function(rack) {
		if(jQuery("#map-rack").find("div#map-rack-" + rack.rackCode).size() < 1) {
			var text = "<div id='map-rack-" + rack.rackCode + "'>" + JSON.stringify(rack) + "</div>";
			console.debug(text);
			jQuery("#map-rack").append(text);
		}
		return JSON.parse(jQuery("#map-rack").find("div#map-rack-" + rack.rackCode).text());
	},
	_registerRackColumn20151218: function(rackColumn) {
		var mapRackColumn = _cmdb._mapRackColumn;
		if(!mapRackColumn.has(rackColumn.rackColumnCode)) {
			mapRackColumn.set(rackColumn.rackColumnCode, rackColumn);
		}
		return mapRackColumn.get(rackColumn.rackColumnCode);
	},
	_registerRackColumn: function(rackColumn) {
		if(jQuery("#map-rack-column").find("div#map-rack-column-" + rackColumn.rackColumnCode).size() < 1) {
			var text = "<div id='map-rack-column-" + rackColumn.rackColumnCode + "'>" + JSON.stringify(rackColumn) + "</div>";
			console.debug(text);
			jQuery("#map-rack-column").append(text);
		}
		return JSON.parse(jQuery("#map-rack-column").find("div#map-rack-column-" + rackColumn.rackColumnCode).text());
	},
	_getRackColumn: function(rackColumnCode) {
		if(!rackColumnCode) {
			return null;
		}
		
		var selector = jQuery("#map-rack-column");
		if(!selector || !selector.size || selector.size() < 1) {
			return null;
		}
		selector = selector.find("div#map-rack-column-" + rackColumnCode);
		if(!selector || !selector.size || selector.size() < 1 || !selector.text) {
			return null;
		}
		
		return JSON.parse(selector.text());
	},
	_moveRack: function(rack) {
		if(!rack || !rack.position || !rack.view) {
			return;
		}
		rack.view.main.position.set(
			rack.position.x,
			rack.position.y + _cmdb._rack.size.y * rack.rackSize / 2,
			rack.position.z
		);
		if (rack.view.tag && rack.view.tag.position && rack.view.tag.position.set) {
			rack.view.tag.position.set(
				rack.position.x - _cmdb._rack.size.x / 2,
				rack.position.y + _cmdb._rack.size.y * (rack.rackSize + 2),
				rack.position.z + _cmdb._rack.size.z / 2 + 4
			);
		}
	},
	_loadRackColumnChildren: function(rackColumn, delta) {
		if(delta < 0) {
			return;
		}
		if(!rackColumn || !rackColumn.rackColumnCode) {
			console.warn("invalid parameter:: ", rackColumn, delta);
			return;
		}
		
		var already = _cmdb._getRackColumn(rackColumn.rackColumnCode);
		if(already && already.children) {
			console.warn("invalid data:: ", rackColumn, delta, already);
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/rack/json",
			"data": {
				rackColumnCode: rackColumn.rackColumnCode
			},
			"success": function(data) {
				rackColumn.children = [];
				//	뭐 이상해?
				if(!data || !data.listRack || !data.listRack.length || data.listRack.length < 0) {
					return;
				}

				for (var cx = 0;cx < data.listRack.length;cx++) {
					var rack = data.listRack[cx];
					rack.parent = rackColumn.rackColumnCode;
					rack.position = {
									x: rackColumn.position.x + (_cmdb._rackColumn.size.x) * (cx + 1),
									y: rackColumn.position.y,
									z: rackColumn.position.z
					};
					rack = _cmdb._registerRack(rack);
					rackColumn.children.push(rack.rackCode);
					_cmdb._createRackView(rack);
					_cmdb._moveRack(rack);
				}	//	for (var cx = 0;cx < data["listRack"].length;cx++) {
				_cmdb._setRackColumn(rackColumn);
				_cmdb._resizeRackColumn(rackColumn);
				for (var cx = 0;cx < rackColumn.children.length;cx++) {
					_cmdb.propagateRack(rackColumn.children[cx], delta - 1);
				}
			}	//	"success": function(data) {
		});
	},
	_registerIdcZone20151218: function(idcZone) {
		var mapIdcZone = _cmdb._mapIdcZone;
		if(!mapIdcZone.has(idcZone.idcZoneCode)) {
			mapIdcZone.set(idcZone.idcZoneCode, idcZone);
		}
		return mapIdcZone.get(idcZone.idcZoneCode);
	},
	_registerIdcZone: function(idcZone) {
		if(jQuery("#map-idc-zone").find("div#map-idc-zone-" + idcZone.idcZoneCode).size() < 1) {
			var text = "<div id='map-idc-zone-" + idcZone.idcZoneCode + "'>" + JSON.stringify(idcZone) + "</div>";
			console.debug(text);
			jQuery("#map-idc-zone").append(text);
		}
		return JSON.parse(jQuery("#map-idc-zone").find("div#map-idc-zone-" + idcZone.idcZoneCode).text());
	},
	_createIdcZoneView: function(idcZone) {
		console.debug("START: _createIdcZoneView", idcZone);

		//	main geometry
		var mainGeometry = new THREE.BoxGeometry(_cmdb._idcZone.size.x, _cmdb._idcZone.size.y, _cmdb._idcZone.size.z);
		var scalex = (idcZone && idcZone.children && idcZone.children.length && idcZone.children.length > 0) ? idcZone.children.length : 1;
		mainGeometry.scale(scalex, 1, 1);
		//	main texture
		var mainTexture = _cmdb._idcZone.texture;
		mainTexture.repeat.set(_cmdb._idcZone.size.x / 32, _cmdb._idcZone.size.y / 32);
		//	main material
		var mainMaterial = new THREE.MeshLambertMaterial({color: _cmdb._idcZone.color, map: mainTexture, transparent: false, opacity: 0.2});
		//	main mesh
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(idcZone.position.x + _cmdb._idcZone.size.x * scalex / 2, idcZone.position.y, idcZone.position.z);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateIdcZone(idcZone.idcZoneCode, 1);
		};
		
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);

		var position = {
			x: idcZone.position.x,
			y: idcZone.position.y + _cmdb._idcZone.size.y / 2,
			z: idcZone.position.z + _cmdb._idcZone.size.z / 2
		};

		var nameTag = _cmdb._createNameTag(idcZone.idcZoneName, 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);
		andold.threejs._objects.push(nameTag);

		idcZone.view = {
			main: mainMesh,
			tag: nameTag,
			scale: {
				x: 1,
				y: 1,
				z: 1
			}
		};

		console.debug("FINISH: _createIdcZoneView", idcZone);
	},
	_createIdcGroupView: function(idcGroup) {
		console.debug("START: _createIdcGroupView", idcGroup);

		//	main geometry
		var mainGeometry = new THREE.BoxGeometry(_cmdb._idcGroup.size.x, _cmdb._idcGroup.size.y, _cmdb._idcGroup.size.z);
		var scalex = (idcGroup && idcGroup.children && idcGroup.children.length && idcGroup.children.length > 0) ? idcGroup.children.length : 1;
		var scalez = 16;
		mainGeometry.scale(scalex, 1, scalez);
		//	main texture
		var mainTexture = _cmdb._idcGroup.texture;
		mainTexture.repeat.set(scalex, scalez);
		//	main material
		var mainMaterial = new THREE.MeshLambertMaterial({color: _cmdb._idcGroup.color, map: mainTexture, transparent: false, opacity: 0.2});
		//	main mesh
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(idcGroup.position.x - _cmdb._idcGroup.size.x * (scalex + 2 - scalex) / 2, idcGroup.position.y - _cmdb._idcGroup.size.y * 2, idcGroup.position.z - _cmdb._idcGroup.size.z * scalez / 2);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateIdcGroup(idcGroup.idcGroupCode, 1);
		};
		
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);

		var position = {
			x: idcGroup.position.x,
			y: idcGroup.position.y + _cmdb._idcGroup.size.y / 2,
			z: idcGroup.position.z + _cmdb._idcGroup.size.z / 2
		};

		var nameTag = _cmdb._createNameTag(idcGroup.idcGroupName, 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);
		andold.threejs._objects.push(nameTag);

		idcGroup.view = {
			main: mainMesh,
			tag: nameTag,
			scale: {
				x: 1,
				y: 1,
				z: 1
			}
		};

		console.debug("FINISH: _createIdcGroupView", idcGroup);
	},
	_loadRackColumnParent: function(rackColumn, delta, direction) {
		console.debug("START: _loadRackColumnParent", rackColumn, delta);
		if(delta < 0 || !rackColumn || !rackColumn.idcZoneCode) {
			return;
		}
		
		var idcZone = _cmdb._getIdcZone(rackColumn.idcZoneCode);
		if(idcZone) {
			console.warn("aleady loaded!", idcZone);
			return;
		}

		jQuery.ajax({
			"url": andold.threejs._contextPath + "/idcZone/json",
			"async": true,
			"data": {
				idcZoneCode: rackColumn.idcZoneCode
			},
			"success": function(data) {
				if (!data || !data.listIdcZone || !data.listIdcZone.length || data.listIdcZone.length < 1) {
					rackColumn.parent = true;
					return;
				}
				
				for (var cx = 0;cx < data.listIdcZone.length;cx++) {
					var idcZone = data.listIdcZone[cx];
					if(!idcZone) {
						continue;
					}

					if(rackColumn.position) {
						idcZone.position = {
							x: rackColumn.position.x,
							y: rackColumn.position.y - _cmdb._rackColumn.size.y * 2,
							z: rackColumn.position.z,
						};
					} else {
						idcZone.position = {
							x: 0,
							y: 0,
							z: 0,
						};
					}
					idcZone = _cmdb._registerIdcZone(idcZone);
					rackColumn.parent = rackColumn.idcZoneCode;
					_cmdb._createIdcZoneView(idcZone);
					break;
				}
				_cmdb.propagateIdcZone(rackColumn.idcZoneCode, delta - 1, direction);
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
		console.debug("FINISH: _loadRackColumnParent", rackColumn, delta);
	},
	_loadIdcZoneParent: function(idcZone, delta) {
		console.debug("START: _loadIdcZoneParent", idcZone, delta);
		if(delta < 0 || !idcZone || !idcZone.idcGroupCode) {
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/idcGroup/json",
			"async": false,
			"data": {
				idcGroupCode: idcZone.idcGroupCode
			},
			"success": function(data) {
				if(!data || !data.listIdcGroup || !data.listIdcGroup.length || data.listIdcGroup.length < 1) {
					idcZone.parent = false;
					return;
				}
				
				for (var cx = 0;cx < data.listIdcGroup.length;cx++) {
					var idcGroup = data.listIdcGroup[cx];
					if(!idcGroup) {
						continue;
					}
					
					if(idcZone.position) {
						idcGroup.position = {
							x: idcZone.position.x,
							y: idcZone.position.y,
							z: idcZone.position.z,
						};
					} else {
						idcGroup.position = {
							x: 0,
							y: 0,
							z: 0,
						};
					}
					idcGroup = _cmdb._registerIdcGroup(idcGroup);
					idcZone.parent = idcGroup.idcGroupCode;
					if(idcGroup.idcGroupCode == data.listIdcGroup[cx].idcGroupCode) {
						_cmdb._createIdcGroupView(idcGroup);
					}
					break;
				}	//	for (var cx = 0;cx < data["listRackColumn"].length;cx++) {
				_cmdb.propagateIdcGroup(idcZone.parent, delta - 1);
			}	//	"success": function(data) {
		});	//	jQuery.ajax({

		console.debug("FINISH: _loadIdcZoneParent", idcZone, delta);
	},
	_loadIdcGroupParent: function(idcGroup, delta) {
		console.info("START: _loadIdcGroupParent", idcGroup, delta);
		if(delta < 0 || !idcGroup || !idcGroup.idcGroupCode) {
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/idcGroup/json",
			"async": false,
			"data": {},
			"success": function(data) {
				if(!data || !data.listIdcGroup || !data.listIdcGroup.length || data.listIdcGroup.length < 1) {
					idcZone.parent = false;
					return;
				}
				
				var positiony = idcGroup.position.y || 0;
				for (var cx = 0;cx < data.listIdcGroup.length;cx++) {
					var sibling = data.listIdcGroup[cx];
					if(!sibling || !sibling.idcGroupCode) {
						continue;
					}

					var already = _cmdb._getIdcGroup(sibling.idcGroupCode);
					if(already) {
						already.position.y = positiony + _cmdb._idcGroup.size.y * 64 * cx;
						already.parent = true;
						_cmdb._setIdcGroup(already);
						_cmdb._moveIdcGroup(already);
						continue;
					}
					
					if(idcGroup.position) {
						sibling.position = {
							x: idcGroup.position.x,
							y: positiony + _cmdb._idcGroup.size.y * 62 * cx,
							z: idcGroup.position.z
						};
					} else {
						sibling.position = {
							x: 0,
							y: positiony + _cmdb._idcGroup.size.y * 62 * cx,
							z: 0
						};
					}
					sibling.parent = true;
					sibling = _cmdb._registerIdcGroup(sibling);
					_cmdb._createIdcGroupView(sibling);
				}	//	for (var cx = 0;cx < data["listRackColumn"].length;cx++) {
			}	//	"success": function(data) {
		});	//	jQuery.ajax({

		console.info("FINISH: _loadIdcGroupParent", idcGroup, delta);
	},
	_loadIdcZoneChildren: function(idcZone, delta) {
		if(delta < 0 || !idcZone || !idcZone.idcZoneCode) {
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/rackColumn/json",
			"data": {
				idcZoneCode: idcZone.idcZoneCode
			},
			"success": function(data) {
				idcZone.children = [];
				//	뭐 이상해?
				if(!data || !data.listRackColumn || !data.listRackColumn.length || data.listRackColumn.length < 0) {
					return;
				}

				for (var cx = 0;cx < data.listRackColumn.length;cx++) {
					var rackColumn = data.listRackColumn[cx];
					rackColumn.parent = idcZone.idcZoneCode;
					rackColumn.position = {
									x: idcZone.position.x,
									y: idcZone.position.y + _cmdb._rackColumn.size.y * 2,
									z: idcZone.position.z - (_cmdb._rackColumn.size.z + 16) * cx
					};
					rackColumn = _cmdb._registerRackColumn(rackColumn);
					idcZone.children.push(rackColumn.rackColumnCode);
					_cmdb._createRackColumnView(rackColumn);
				}
				_cmdb._setIdcZone(idcZone);
				_cmdb._resizeIdcZone(idcZone);
				for (var cx = 0;cx < idcZone.children.length;cx++) {
					_cmdb.propagateRackColumn(idcZone.children[cx], delta - 1, 0x01);
				}
			}	//	"success": function(data) {
		});
	},
	_loadIdcGroupChildren: function(idcGroup, delta) {
		if(delta < 0 || !idcGroup || !idcGroup.idcGroupCode) {
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/idcZone/json",
			"data": {
				idcGroupCode: idcGroup.idcGroupCode
			},
			"success": function(data) {
				idcGroup.children = [];
				//	뭐 이상해?
				if(!data || !data.listIdcZone || !data.listIdcZone.length || data.listIdcZone.length < 0) {
					console.warn("invalid data:: ", data);
					return;
				}

				for (var cx = 0;cx < data.listIdcZone.length;cx++) {
					var idcZone = data.listIdcZone[cx];
					idcZone.parent = idcGroup.idcGroupCode;
					idcZone.position = {
									x: idcGroup.position.x,
									y: idcGroup.position.y,
									z: idcGroup.position.z - _cmdb._idcZone.size.z * cx * 2
					};
					idcZone = _cmdb._registerIdcZone(idcZone);
					idcGroup.children.push(idcZone.idcZoneCode);
					if(idcZone.idcZoneCode == data.listIdcZone[cx].idcZoneCode) {
						_cmdb._createIdcZoneView(idcZone);
					} else {
						_cmdb._moveIdcZone(idcZone);
					}
					_cmdb._setIdcGroup(idcGroup);
				}
				_cmdb._resizeIdcZone(idcZone);
				for (var cx = 0;cx < idcGroup.children.length;cx++) {
					_cmdb.propagateIdcZone(idcGroup.children[cx], delta - 1, 0x01);
				}
			}	//	"success": function(data) {
		});
	},
	propagateIdcZone: function(idcZoneCode, delta, direction) {
		if (delta < 0) {
			return;
		}

		if (!idcZoneCode) {
			console.warn("invalid data:: propagateIdcZone", idcZoneCode, delta);
			return;
		}


		var idcZone = _cmdb._getIdcZone(idcZoneCode);
		if(!idcZone) {
			console.warn("no data:: propagateIdcZone", idcZoneCode, delta);
			return;
		}

		direction = direction || 3;
		console.debug("START: propagateIdcZone", idcZoneCode, delta, direction);

		//	아래쪽 전파
		if(direction & 0x01) {
			if(idcZone.children) {
				for (var cx = 0;cx < idcZone.children.length;cx++) {
					_cmdb.propagateRackColumn(idcZone.children[cx], delta - 1, 0x01);
				}
			} else {
				_cmdb._loadIdcZoneChildren(idcZone, delta - 1, 0x01);
			}
		}

		//	위쪽 전파
		if(direction & 0x02) {
			if(idcZone.parent) {
				_cmdb.propagateIdcGroup(idcZone.parent, delta - 1, 0x02);
			} else {	//	if(!rack["parent"]) {
				_cmdb._loadIdcZoneParent(idcZone, delta - 1, 0x02);
			}
		}

		console.debug("FINISH: propagateIdcZone", idcZone, delta);
	},
	propagateIdcGroup: function(idcGroupCode, delta, direction) {
		if (delta < 0) {
			return;
		}
		if (!idcGroupCode) {
			console.warn("invalid data:: propagateIdcGroup", idcGroupCode, delta, direction);
			return;
		}
		
		direction = direction || 3;
		console.info("START: propagateIdcGroup", idcGroupCode, delta, direction);
		var idcGroup = _cmdb._getIdcGroup(idcGroupCode);
		if(!idcGroup) {
			console.warn("invalid data:: propagateIdcGroup", idcGroupCode, delta, direction, idcGroup);
			return;
		}

		//	아래쪽 전파
		if(direction & 0x01) {
			if(idcGroup.children) {
				for (var cx = 0;cx < idcGroup.children.length;cx++) {
					_cmdb.propagateIdcZone(idcGroup.children[cx], delta - 1, 0x01);
				}
			} else {
				_cmdb._loadIdcGroupChildren(idcGroup, delta - 1, 0x01);
			}
		}

		//	위쪽 전파
		if(direction & 0x02) {
			if(idcGroup.parent) {
				//_cmdb.propagateIdcGroup(idcGroup.parent, delta - 1, 0x02);
			} else {	//	if(!rack["parent"]) {
				_cmdb._loadIdcGroupParent(idcGroup, delta - 1, 0x02);
			}
		}

		console.info("FINISH: propagateIdcGroup", idcGroupCode, delta, direction);
	},
	_moveRackColumn: function(rackColumn) {
		if(!rackColumn || !rackColumn.position || !rackColumn.view) {
			return;
		}
		var scale = (rackColumn && rackColumn.children && rackColumn.children.length && rackColumn.children.length > 0) ? rackColumn.children.length : 1;
		var positionx = rackColumn.position.x + _cmdb._rackColumn.size.x * scale / 2;
		rackColumn.view.main.position.set(
			rackColumn.position.x + _cmdb._rackColumn.size.x * scale / 2,
			rackColumn.position.y,
			rackColumn.position.z
		);
		rackColumn.view.tag.position.set(
			rackColumn.position.x,
			rackColumn.position.y + _cmdb._rackColumn.size.y / 2,
			rackColumn.position.z + _cmdb._rackColumn.size.z / 2
		);

		for (var cx = 0;cx < rackColumn.children.length;cx++) {
			var rack = rackColumn.children[cx];
			rack.position = {
							x: rackColumn.position.x + (_cmdb._rackColumn.size.x) * (cx),
							y: rackColumn.position.y,
							z: rackColumn.position.z
			};
			_cmdb._moveRack(rack);
		}
	},
	_moveIdcZone: function(idcZone) {
		if(!idcZone || !idcZone.position || !idcZone.view) {
			return;
		}

		var positionx = idcZone.position.x + _cmdb._idcZone.size.x * idcZone.view.scale.x / 2 - _cmdb._idcZone.size.x;
		var positionz = idcZone.position.z - _cmdb._idcZone.size.z * idcZone.view.scale.z / 2 + _cmdb._idcZone.size.z * 0;
		idcZone.view.main.position.set(positionx, idcZone.position.y, positionz);
		idcZone.view.tag.position.set(positionx, idcZone.position.y, positionz);
	},
	_moveIdcGroup: function(idcGroup) {
		if(!idcGroup || !idcGroup.position || !idcGroup.view) {
			return;
		}

		var positionx = idcGroup.position.x + _cmdb._idcZone.size.x * idcGroup.view.scale.x / 2 - _cmdb._idcZone.size.x;
		var positionz = idcGroup.position.z - _cmdb._idcZone.size.z * idcGroup.view.scale.z / 2 + _cmdb._idcZone.size.z * 0;
		idcGroup.view.main.position.set(positionx, idcGroup.position.y, positionz);
		idcGroup.view.tag.position.set(positionx, idcGroup.position.y, positionz);
	},
	_resizeIdcZone: function(idcZone) {
		if (!idcZone || !idcZone.view || !idcZone.view.main || !idcZone.view.main.geometry) {
			return;
		}

		if(idcZone.view.scale.x == 1) {
			idcZone.view.scale.x = (idcZone && idcZone.children && idcZone.children.length && idcZone.children.length > 0
							&& idcZone.children[0] && idcZone.children[0].children && idcZone.children[0].children.length && idcZone.children[0].children.length > 0) ? idcZone.children[0].children.length : 1;
			if(idcZone.view.scale.x > 1) {
				idcZone.view.main.geometry.scale(idcZone.view.scale.x + 2, 1, 1);
			}
		}
		if(idcZone.view.scale.z == 1) {
			idcZone.view.scale.z = (idcZone && idcZone.children && idcZone.children.length && idcZone.children.length > 0) ? idcZone.children.length : 1;
			idcZone.view.main.geometry.scale(1, 1, idcZone.view.scale.z + 2);
		}
		idcZone.view.main.material.map.repeat.set(idcZone.view.scale.x, idcZone.view.scale.z);
		_cmdb._moveIdcZone(idcZone);
	},
	_resizeRackColumn: function(rackColumn) {
		if (!rackColumn || !rackColumn.view || !rackColumn.view.main || !rackColumn.view.main.geometry) {
			return;
		}
		
		var scale = (rackColumn && rackColumn.children && rackColumn.children.length && rackColumn.children.length > 0) ? rackColumn.children.length : 1;
		rackColumn.view.main.geometry.scale(scale + 2, 1, 1);
		rackColumn.view.main.position.set(rackColumn.position.x - _cmdb._rackColumn.size.x * scale / 2, rackColumn.position.y, rackColumn.position.z);
		//mainMesh.position.set(rackColumn.position.x + _cmdb._rackColumn.size.x * scale / 2, rackColumn.position.y, rackColumn.position.z);

		_cmdb._moveRackColumn(rackColumn);
		if(rackColumn.parent && rackColumn.parent.children && rackColumn.parent.children.length && rackColumn.parent.children.length > 0 && rackColumn.parent.children[0] && rackColumn == rackColumn.parent.children[0]) {
			_cmdb._resizeIdcZone(rackColumn.parent);
		}
	},
	_resizeRack: function(rack) {
		if (!rack || !rack.view || !rack.view.main || !rack.view.main.geometry) {
			return;
		}
		
		var scale = (rack && rack.children && rack.children.length && rack.children.length > 0) ? rack.children.length : 1;
		rack.view.main.geometry.scale(scale + 2, 1, 1);
		rack.view.main.position.set(rack.position.x - _cmdb._rackColumn.size.x * scale / 2, rack.position.y, rack.position.z);

		_cmdb._moveRackColumn(rack);
		if(rack.parent && rack.parent.children && rack.parent.children.length && rack.parent.children.length > 0 && rack.parent.children[0] && rack == rack.parent.children[0]) {
			_cmdb._resizeIdcZone(rack.parent);
		}
	},
	_registerComputer0: function(computer) {
		var mapComputer = _cmdb._mapComputer;
		if(!mapComputer.has(computer.assetId)) {
			mapComputer.set(computer.assetId, computer);
		}
		return mapComputer.get(computer.assetId);
	},
	_registerComputer: function(computer) {
		if(jQuery("#map-computer").find("div#map-computer-" + computer.assetId).size() < 1) {
			var text = "<div id='map-computer-" + computer.assetId + "'>" + JSON.stringify(computer) + "</div>";
			console.debug(text);
			jQuery("#map-computer").append(text);
		}
		return JSON.parse(jQuery("#map-computer").find("div#map-computer-" + computer.assetId).text());
	},
	_getComputer: function(assetId) {
		if(!assetId) {
			return null;
		}
		
		var selector = jQuery("#map-computer");
		if(!selector || !selector.size || selector.size() < 1) {
			return null;
		}
		selector = selector.find("div#map-computer-" + assetId);
		if(!selector || !selector.size || selector.size() < 1 || !selector.text) {
			return null;
		}
		
		return JSON.parse(selector.text());
	},
	_registerIdcGroup: function(idcGroup) {
		if(jQuery("#map-idc-group").find("div#map-idc-group-" + idcGroup.idcGroupCode).size() < 1) {
			var text = "<div id='map-idc-group-" + idcGroup.idcGroupCode + "'>" + JSON.stringify(idcGroup) + "</div>";
			console.debug(text);
			jQuery("#map-idc-group").append(text);
		}
		return JSON.parse(jQuery("#map-idc-group").find("div#map-idc-group-" + idcGroup.idcGroupCode).text());
	},
	_getIdcZone: function(idcZoneCode) {
		var selector = jQuery("#map-idc-zone");
		if(selector.size() < 1) {
			return null;
		}
		
		selector = selector.find("div#map-idc-zone-" + idcZoneCode);
		if(selector.size() < 1) {
			return null;
		}

		var text = selector.text();
		if (!text || text == "") {
			return null;
		}
		
		return JSON.parse(text);
	},
	_getIdcGroup: function(idcGroupCode) {
		var selector = jQuery("#map-idc-group");
		if(selector.size() < 1) {
			return null;
		}
		
		selector = selector.find("div#map-idc-group-" + idcGroupCode);
		if(selector.size() < 1) {
			return null;
		}

		var text = selector.text();
		if (!text || text == "") {
			return null;
		}
		
		return JSON.parse(text);
	},
	_setIdcZone: function(idcZone) {
		jQuery("#map-idc-zone").find("div#map-idc-zone-" + idcZone.idcZoneCode).text(JSON.stringify(idcZone));
	},
	_setIdcGroup: function(idcGroup) {
		jQuery("#map-idc-group").find("div#map-idc-group-" + idcGroup.idcGroupCode).text(JSON.stringify(idcGroup));
	},
	_loadRackChildren: function(rack, delta) {
		if(delta < 0 || !rack || !rack.rackCode) {
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/computer/json",
			"async": false,
			"data": {
				rackCode: rack.rackCode
			},
			"success": function(data) {
				//	이상혀?
				rack.children = [];
				if(!data || !data["listComputerSystem"] || !data["listComputerSystem"].length || data["listComputerSystem"].length < 1) {
					return;
				}

				for (var cx = 0;cx < data.listComputerSystem.length;cx++) {
					var computer = data.listComputerSystem[cx];
					computer.parent = rack.rackCode;
					computer = _cmdb._registerComputer(computer);
					computer.position = {
						x: rack.position.x,
						y: rack.position.y + (_cmdb._computer.size.y + 1) * computer.holeNumber,
						z: rack.position.z
					};
					computer.hostname = computer.hostname || "null";
					rack.children.push(computer.assetId);
					_cmdb._createComputerView(computer);
				}
				_cmdb._setRack(rack);
				for (var cx = 0;cx < rack.children.length;cx++) {
					_cmdb.propagateAsset(rack.children[cx], delta - 1);
				}
				_cmdb._resizeRack(rack);
			}	//	if(data && data["listComputerSystem"]) {
		});	//	jQuery.ajax({
	},
	_loadRackParent: function(rack, delta) {
		console.debug("START: _loadRackParent", rack, delta);
		if(!rack || !rack.rackColumnCode) {
			return;
		}
		
		var rackColumn = _cmdb._getRackColumn(rack.rackColumnCode);
		if(rackColumn) {
			console.warn("already loaded:: ", rackColumn);
			return;
		}
		

		jQuery.ajax({
			"url": andold.threejs._contextPath + "/rackColumn/json",
			"async": false,
			"data": {
				rackColumnCode: rack.rackColumnCode
			},
			"success": function(data) {
				if(!data || !data.listRackColumn || !data.listRackColumn.length || data.listRackColumn.length < 1) {
					rack.parent = false;
					return;
				}
				
				for (var cx = 0;cx < data.listRackColumn.length;cx++) {
					var rackColumn = data.listRackColumn[cx];
					if(!rackColumn) {
						continue;
					}
					
					if(rack.position) {
						rackColumn.position = {
							x: rack.position.x,
							y: rack.position.y,
							z: rack.position.z,
						};
					} else {
						rackColumn.position = {
							x: 0,
							y: 0,
							z: 0,
						};
					}
					rackColumn = _cmdb._registerRackColumn(rackColumn);
					rack.parent = rackColumn.rackColumnCode;
					_cmdb._createRackColumnView(rackColumn);
					break;
				}	//	for (var cx = 0;cx < data["listRackColumn"].length;cx++) {
				_cmdb.propagateRackColumn(rack.rackColumnCode, delta - 1);
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
	},
	propagateRack: function(rackCode, delta, direction) {
		//	많이 묶었나?
		if (delta < 0) {
			return;
		}
		if (!rackCode) {
			console.error("INVALID PARAMETER: propagateRack", rackCode, delta);
			return;
		}

		direction = direction || 3;

		console.debug("START: propagateRack", rackCode, delta, direction);
		var rack = _cmdb._getRack(rackCode);
		if(!rack) {
			console.error("INVALID data: propagateRack", rackCode, delta, direction);
			return;
		}
		//	아래쪽 전파
		if(direction & 0x01) {
			if(rack.children) {
				for (var cx = 0;cx < rack.children.length;cx++) {
					_cmdb.propagateAsset(rack.children[cx], delta - 1, 0x01);
				}
			} else {
				_cmdb._loadRackChildren(rack, delta - 1);
			}
		}

		//	위쪽 전파
		if(direction & 0x02) {
			if(rack.parent) {
				_cmdb.propagateRackColumn(rack.parent, delta - 1, 0x02);
			} else {	//	if(!rack["parent"]) {
				_cmdb._loadRackParent(rack, delta - 1);
			}
		}

		console.debug("FINISH: propagateRack", rack, delta);
	},
	propagateRackColumn: function(rackColumnCode, delta, direction) {
		if (delta < 0) {
			return;
		}
		if (!rackColumnCode) {
			console.error("INVALID PARAMTER: propagateRackColumn", rackColumnCode, delta, direction);
			return;
		}
		
		direction = direction || 3;
		console.debug("START: propagateRackColumn", rackColumnCode, delta, direction);
		var rackColumn = _cmdb._getRackColumn(rackColumnCode);
		//	아래쪽 전파
		if(direction & 0x01) {
			if(rackColumn.children) {
				for (var cx = 0;cx < rackColumn.children.length;cx++) {
					_cmdb.propagateRack(rackColumn.children[cx], delta + 1);
				}
			} else {
				_cmdb._loadRackColumnChildren(rackColumn, delta + 1);
			}
		}

		//	위쪽 전파
		if(direction & 0x02) {
			if(rackColumn.parent) {
				_cmdb.propagateIdcZone(rackColumn.parent, delta - 1, 0x02);
			} else {	//	if(!rack["parent"]) {
				_cmdb._loadRackColumnParent(rackColumn, delta - 1, 0x02);
			}
		}

		console.debug("FINISH: propagateRackColumn", rackColumn, delta, direction);
	},
	_createRackView1: function(rack) {
		console.debug("START: _createRackView", rack);

		var mainGeometry = new THREE.BoxGeometry(_cmdb._rack.size.x, _cmdb._rack.size.y, _cmdb._rack.size.z);
		mainGeometry.scale(1, rack.rackSize, 1);
		var mainTexture = _cmdb._rack.texture;
		mainTexture.repeat.set(_cmdb._rack.size.x / 32, _cmdb._rack.size.y / 32);
		var mainMaterial = new THREE.MeshLambertMaterial({color: _cmdb._rack.color, map: mainTexture, transparent: false, opacity: 0.2});
		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(rack.position.x, rack.position.y + (_cmdb._rack.size.y * rack.rackSize) / 2, rack.position.z);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateRack(rack.rackCode, 1);
		};

		var position = {
			x: rack.position.x,
			y: rack.position.y + _cmdb._rack.size.y * rack.rackSize,
			z: rack.position.z + andold.threejs.cmdb._rack.size.z / 2 + 4
		};
		var nameTag = _cmdb._createNameTag(rack.rackName + " " + rack.rackSize, 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);
		andold.threejs._objects.push(nameTag);

		rack.view = {
			main: mainMesh,
			tag: nameTag
		};

		console.debug("FINISH: _createRackView", rack);
	},
	_createRackView: function(rack) {
		console.debug("START: _createRackView", rack);

		var mainGeometry;
		//mainGeometry = new THREE.BoxGeometry(_cmdb._rack.size.x, _cmdb._rack.size.y, _cmdb._rack.size.z);
		mainGeometry = new THREE.CylinderGeometry(_cmdb._rack.size.x / 4, _cmdb._rack.size.x / 4, _cmdb._rack.size.y, 32);
		mainGeometry.scale(1, rack.rackSize, 1);
		var mainMaterial;
		//mainMaterial = new THREE.MeshBasicMaterial({color: _cmdb._rack.color, transparent: true, opacity: 0.9});
		//mainMaterial = new THREE.MeshNormalMaterial({color: _cmdb._rack.color, transparent: true, opacity: 0.9});
		//mainMaterial = new THREE.MeshPhongMaterial({color: 0x8080FF, transparent: true, opacity: 0.05});	//	빛나는
		//mainMaterial = new THREE.MeshNormalMaterial({color: _cmdb._rack.color, transparent: true, opacity: 0.1});
		mainMaterial = new THREE.MeshPhongMaterial({color: _cmdb._rack.color, transparent: true, opacity: 0.2});	//	빛나는

		var mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
		mainMesh.position.set(rack.position.x, rack.position.y + (_cmdb._rack.size.y * rack.rackSize) / 2, rack.position.z);
		mainMesh.castShadow = true;
		mainMesh.receiveShadow = true;
		andold.threejs._scene.add(mainMesh);
		andold.threejs._objects.push(mainMesh);
		mainMaterial.onClickHandler = function() {
			_cmdb.propagateRack(rack.rackCode, 1);
		};

		var position = {
			x: 0,
			y: _cmdb._rack.size.y * (rack.rackSize + 2) / 2,
			z: 32
		};

		var nameTag = _cmdb._createNameTag(rack.rackName, 16, position, 0xC00000, 0x808080, 4);
		andold.threejs._scene.add(nameTag);
		//andold.threejs._objects.push(nameTag);

		mainMesh.add(nameTag);

		console.debug("FINISH: _createRackView", rack);
	},
	_loadComputerParent: function(computer, delta) {
		console.debug("START: _loadComputerParent", computer, delta);
		if(!computer || !computer.rackCode) {
			return;
		}
		
		var rack = _cmdb._getRack(computer.rackCode);
		if(rack) {
			console.warn("already loaded:: ", rack);
			return;
		}
		
		jQuery.ajax({
			"url": andold.threejs._contextPath + "/rack/json",
			"async": true,
			"data": {
				rackCode: computer.rackCode
			},
			"success": function(data) {
				if (!data || !data["listRack"] || !data["listRack"].length || data["listRack"].length < 1) {
					computer.parent = true;
					return;
				}
				
				for (var cx = 0;cx < data["listRack"].length;cx++) {
					var rack = data["listRack"][cx];
					if(!rack) {
						continue;
					}

					if(computer.position) {
						rack.position = {
							x: computer.position.x,
							y: computer.position.y,
							z: computer.position.z,
						};
					} else {
						rack.position = {
							x: 0,
							y: 0,
							z: 0,
						};
					}
					rack = _cmdb._registerRack(rack);
					computer.parent = computer.rackCode;
					_cmdb._createRackView(rack);
					break;
				}
				_cmdb.propagateRack(computer.parent, delta - 1);
			}	//	"success": function(data) {
		});	//	jQuery.ajax({
		console.debug("FINISH: _loadComputerParent", computer, delta);
	},
	propagateAsset: function(assetId, delta, direction) {
		if (delta < 0) {
			return;
		}

		if (!assetId) {
			console.error("INVALID PARAMETER: propagateAsset", assetId, delta);
			return;
		}

		direction = direction || 3;
		console.debug("START: propagateAsset", assetId, delta, direction);
		
		var computer = _cmdb._getComputer(assetId);
		//	위쪽 전파
		if(direction & 0x02) {
			if(!computer.parent) {
				_cmdb._loadComputerParent(computer, delta - 1);
			} else {
				_cmdb.propagateRack(computer.parent, delta - 1, 0x02);
			}
		}
		console.debug("FINISH: propagateAsset", computer, delta);
	}
};

andold["threejs"] = _threejs;
andold["threejs"]["action"] = _action;
andold["threejs"]["cmdb"] = _cmdb;

