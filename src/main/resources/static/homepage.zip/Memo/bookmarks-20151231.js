﻿var bookmarks = {
	"title": "잡다한 인연들",
	"type": "root",
	"children": []
};
bookmarks["children"].push({
	"title": "Neo NMS: 2015-11",
	"type": "section",
	"children": [{
		"title": "Portal",
		"type": "site",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "위키",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218"
		}, {
			"title": "BTS",
			"url": "http://bts4.navercorp.com/nhnbts/secure/Dashboard.jspa?selectPageId=11856"
		}]
	}, {
		"title": "andold",
		"type": "site",
		"url": "http://dev.nms2.navercorp.com/",
		"children": [{
			"title": "HBase Manager",
			"url": "http://dev-nms-storage-gateway.ncl/hbase/manager/"
		}, {
			"title": "jenkins",
			"url": "http://dev-nms-storage-gateway.ncl/jenkins/"
		}, {
			"title": "batch-tm",
			"url": "http://andold.kr:8080/nms-web-batch/topology/meta/"
		}, {
			"title": "prototype",
			"url": "http://dev-nms-storage-gateway.ncl/prototype/"
		}, {
			"title": "bmt",
			"url": "http://dev-nms-storage-gateway.ncl/bmt/"
		}, {
			"title": "download log",
			"url": "http://dev-nms-storage-gateway.ncl/prototype/log/minutes/download"
		}]
	}, {
		"title": "dev",
		"type": "site",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "Yobi",
			"url": "http://yobi.navercorp.com/organizations/NMS"
		}, {
			"title": "nDeploy",
			"url": "http://ndeploy.navercorp.com/"
		}, {
			"title": "web",
			"url": "http://dev.nms2.navercorp.com/"
		}, {
			"title": "batch",
			"url": "http://10.113.182.89:9001/batch/"
		}, {
			"title": "tm",
			"url": "http://10.113.182.89:9001/topology/meta/"
		}, {
			"title": "CI",
			"url": "http://ci.nms.navercorp.com/jenkins/"
		}, {
			"title": "hbase",
			"url": "http://10.99.211.34:16010/master-status"
		}]
	}, {
		"title": "real",
		"type": "site",
		"url": "http://nms2.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://nms2.navercorp.com/"
		}, {
			"title": "batch1",
			"url": "http://batch1.nms2.navercorp.com/"
		}, {
			"title": "batch1-tm",
			"url": "http://batch1.nms2.navercorp.com/topology/meta/"
		}, {
			"title": "batch2",
			"url": "http://batch2.nms2.navercorp.com/"
		}, {
			"title": "batch2-tm",
			"url": "http://batch2.nms2.navercorp.com/topology/meta/"
		}, {
			"title": "HBase",
			"url": "http://10.114.37.41:16010/master-status"
		}]
	}]
});
bookmarks["children"].push({
	"title": "localhost",
	"type": "section",
	"children": [{
		"title": "2013년 03월 11일 백업",
		"type": "site",
		"url": "./Memo/20130311.html"
	}, {
		"title": "나의 달력",
		"type": "site",
		"url": "./Calendar/MyCalendar.html"
	}, {
		"title": "Suvival",
		"type": "site",
		"url": "Column/20110307.html"
	}, {
		"title": ":8080",
		"type": "site",
		"url": "http://localhost:8080/links.html",
		"children": [{
			"title": "household",
			"url": "http://localhost:8080/household/v3/"
		}, {
			"title": "appd",
			"url": "http://localhost:8080/appd/"
		}, {
			"title": "nms/batch/tm",
			"url": "http://localhost:8080/nms/batch/topology/meta/"
		}, {
			"title": "idcassign",
			"url": "http://localhost:8080/idcassign/v2/step1"
		}, {
			"title": "batch",
			"url": "http://localhost:8080/idcassign/batch/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "andold.kr",
	"type": "section",
	"children": [{
		"title": "andold",
		"type": "site",
		"url": "http://andold.kr/links.html",
		"children": [{
			"title": "IP-Addr",
			"url": "http://10.64.49.169/links.html"
		}, {
			"title": "html",
			"url": "http://andold.kr/links.html"
		}]
	}, {
		"title": ":8080",
		"type": "site",
		"url": "http://andold.kr:8080/links.html",
		"children": [{
			"title": "household",
			"url": "http://andold.kr:8080/household/v3/"
		}, {
			"title": "appd",
			"url": "http://andold.kr:8080/appd/"
		}, {
			"title": "nms/batch/tm",
			"url": "http://andold.kr:8080/nms/batch/topology/meta/"
		}, {
			"title": "idcassign",
			"url": "http://andold.kr:8080/idcassign/v2/step1"
		}, {
			"title": "batch",
			"url": "http://andold.kr:8080/idcassign/batch/"
		}]
	}, {
		"title": "household",
		"type": "site",
		"url": "http://andold.kr/household/",
		"children": [{
			"title": "V3",
			"url": "http://andold.kr/household/v3"
		}]
	}, {
		"title": "Neo NMS",
		"type": "site",
		"children": [{
			"title": "HBase Manager",
			"url": "http://andold.kr/hbase/manager/"
		}, {
			"title": "prototype",
			"url": "http://andold.kr/prototype/"
		}, {
			"title": "bmt",
			"url": "http://andold.kr/bmt/"
		}]
	}, {
		"title": "phoneooh",
		"type": "site",
		"url": "http://m.phoneooh.com/"
	}]
});
bookmarks["children"].push({
	"title": "ich",
	"type": "section",
	"children": [{
		"title": "ich",
		"type": "site",
		"url": "http://ich.andold.kr/links.htm",
		"children": [{
			"title": "htm",
			"url": "http://ich.andold.kr/links.htm"
		}, {
			"title": "html",
			"url": "http://ich.andold.kr/links.html"
		}, {
			"title": "awstats",
			"url": "http://ich.andold.kr/awstats/awstats.ich.html"
		}, {
			"title": "ci",
			"url": "http://ich.andold.kr/jenkins/"
		}, {
			"title": "download",
			"url": "http://ich.andold.kr/download/repository-20140420.dump.gz"
		}]
	}, {
		"title": "household",
		"type": "site",
		"url": "http://ich.andold.kr/links.htm",
		"children": [{
			"title": "V3",
			"url": "http://ich.andold.kr/household/v3/"
		}]
	}, {
		"title": "ip",
		"type": "site",
		"url": "http://10.101.48.155/links.html",
		"children": [{
			"title": "V3",
			"url": "http://10.101.48.155/household/v3/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "금융♤",
	"type": "section",
	"children": [{
		"title": "은행권",
		"type": "site",
		"children": [{
			"title": "신한",
			"url": "http://www.shinhan.com/"
		}, {
			"title": "하나",
			"url": "http://www.hanabank.com/"
		}, {
			"title": "국민",
			"url": "http://www.kbstar.com/"
		}, {
			"title": "외환",
			"url": "http://www.keb.co.kr/"
		}, {
			"title": "산업",
			"url": "https://www.kdb.co.kr/"
		}, {
			"title": "농협",
			"url": "http://banking.nonghyup.com/"
		}]
	}, {
		"title": "신용카드",
		"type": "site",
		"children": [{
			"title": "현대",
			"url": "http://www.hyundaicard.com/"
		}, {
			"title": "삼성",
			"url": "http://www.samsungcard.co.kr/"
		}]
	}, {
		"title": "증권 기타",
		"type": "site",
		"children": [{
			"title": "한국투자",
			"url": "http://www.truefriend.com/"
		}, {
			"title": "삼성생명",
			"url": "http://www.samsunglife.com/"
		}]
	}, {
		"title": "금융 통계",
		"type": "site",
		"children": [{
			"title": "국세청",
			"url": "http://kosis.kr/nsp/abroad/abroad_01List.jsp"
		}, {
			"title": "한국은행",
			"url": "http://ecos.bok.or.kr/"
		}]
	}, {
		"title": "금융 기관",
		"type": "site",
		"children": [{
			"title": "홈텍스",
			"url": "http://www.hometax.go.kr/"
		}, {
			"title": "지로",
			"url": "http://www.giro.or.kr/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "API Reference 2/2",
	"type": "section",
	"children": [{
		"title": "js 2d",
		"type": "site",
		"children": [{
			"title": "Raphael",
			"url": "http://raphaeljs.com/"
		}]
	}, {
		"title": "js 3d",
		"type": "site",
		"children": [{
			"title": "three.js",
			"url": "http://threejs.org/examples/"
		}, {
			"title": "pre3d",
			"url": "http://ich.deanmcnamee.com/pre3d/"
		}, {
			"title": "d3js",
			"url": "http://d3js.org/"
		}, {
			"title": "babylonjs",
			"url": "http://www.babylonjs.com/"
		}]
	}, {
		"title": "js chart",
		"type": "site",
		"children": [{
			"title": "RGraph",
			"url": "http://www.rgraph.net/"
		}, {
			"title": "Highcharts",
			"url": "http://www.highcharts.com/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}, {
			"title": "Awesome",
			"url": "http://cyberpython.github.com/AwesomeChartJS/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}]
	}, {
		"title": "webGL",
		"type": "site",
		"children": [{
			"title": "home",
			"url": "https://www.khronos.org/webgl/"
		}, {
			"title": "wikipedia",
			"url": "https://ko.wikipedia.org/wiki/WebGL"
		}, {
			"title": "Tutorial",
			"url": "https://developer.mozilla.org/ko/docs/Web/API/WebGL_API/Tutorial/Getting_started_with_WebGL"
		}, {
			"title": "demo",
			"url": "https://www.chromeexperiments.com/webgl"
		}, {
			"title": "demo",
			"url": "https://developer.mozilla.org/ko/demos/tag/tech%3Awebgl"
		}]
	}]
});
bookmarks["children"].push({
	"title": "단골 ♤",
	"type": "section",
	"children": [{
		"title": "매피",
		"type": "site",
		"url": "http://www.speednavi.co.kr/"
	}, {
		"title": "철천지",
		"type": "site",
		"url": "http://www.77g.com/"
	}, {
		"title": "대신특수목재",
		"type": "site",
		"url": "http://www.wood21.co.kr/"
	}, {
		"title": "[메일] 한메일",
		"type": "site",
		"url": "http://www.daum.net/"
	}, {
		"title": "공동육아",
		"type": "site",
		"url": "http://www.gongdong.or.kr/"
	}, {
		"title": "김대성",
		"type": "site",
		"url": "http://www.aeris.net/"
	}, {
		"title": "SKT",
		"type": "site",
		"url": "http://www.tworld.co.kr/"
	}, {
		"title": "[신문] 한겨레신문",
		"type": "site",
		"url": "http://www.hani.co.kr/"
	}]
});
bookmarks["children"].push({
	"title": "찾기",
	"type": "section",
	"children": [{
		"title": "[지도] 네이버",
		"type": "site",
		"url": "http://map.naver.com/"
	}, {
		"title": "다음",
		"type": "site",
		"url": "http://www.daum.net/"
	}, {
		"title": "네이버",
		"type": "site",
		"url": "http://www.naver.com"
	}, {
		"title": "위키백과",
		"type": "site",
		"url": "http://ko.wikipedia.org/"
	}, {
		"title": "구글",
		"type": "site",
		"url": "http://www.google.co.kr/"
	}, {
		"title": "후이즈 검색",
		"type": "site",
		"url": "http://whois.nida.or.kr/"
	}]
});
bookmarks["children"].push({
	"title": "가게 ♡",
	"type": "section",
	"children": [{
		"title": "[쇼핑] 지마켓",
		"url": "http://www.gmarket.co.kr/"
	}, {
		"title": "11번가",
		"url": "http://www.11st.co.kr/"
	}, {
		"title": "[경매] 옥션",
		"type": "site",
		"url": "http://www.auction.co.kr"
	}, {
		"title": "[책] YES24",
		"type": "site",
		"url": "http://www.yes24.com/"
	}, {
		"title": "[비교] 에누리",
		"url": "http://www.enuri.com/"
	}, {
		"title": "[비교] 다나와",
		"url": "http://www.danawa.com/"
	}]
});
bookmarks["children"].push({
	"title": "참여",
	"type": "section",
	"children": [{
		"title": "정치후원금센터",
		"type": "site",
		"url": "http://www.give.go.kr/"
	}, {
		"title": "오마이뉴스",
		"type": "site",
		"url": "http://www.ohmynews.com/"
	}, {
		"title": "프레시안",
		"type": "site",
		"url": "http://www.pressian.com/"
	}, {
		"title": "물뚝심송",
		"type": "site",
		"url": "http://murutukus.kr/"
	}]
});
bookmarks["children"].push({
	"title": "문화",
	"type": "section",
	"children": [{
		"title": "물생활",
		"type": "site",
		"children": [{
			"title": "담뽀뽀",
			"type": "site",
			"url": "http://www.dampopo.com/"
		}, {
			"title": "ampet",
			"type": "site",
			"url": "http://www.ampet.co.kr/"
		}, {
			"title": "trofish",
			"type": "site",
			"url": "http://www.trofish.net/"
		}, {
			"title": "물의나라",
			"type": "site",
			"url": "http://www.fishworld114.com/"
		}, {
			"title": "피알피쉬",
			"type": "site",
			"url": "http://www.prfish.com/"
		}]
	}, {
		"title": "재미",
		"type": "site",
		"children": [{
			"title": "딸랑이",
			"type": "site",
			"url": "http://blog.joinsmsn.com/media/index.asp?uid=ooyaggo"
		}, {
			"title": "딴지일보",
			"type": "site",
			"url": "http://www.ddanzi.com/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "개발♤",
	"type": "section",
	"children": [{
		"title": "데브피아",
		"type": "site",
		"url": "http://www.devpia.com/"
	}, {
		"title": "마이크로소프트",
		"type": "site",
		"url": "http://www.microsoft.com/"
	}, {
		"title": "한빛 네트워크",
		"type": "site",
		"url": "http://network.hanb.co.kr/list.php"
	}, {
		"title": "자북",
		"type": "site",
		"url": "http://www.jabook.net/"
	}, {
		"title": "HBase",
		"type": "site",
		"children": [{
			"title": "jira",
			"url": "https://issues.apache.org/jira/browse/HBASE/"
		}, {
			"title": "API",
			"url": "https://hbase.apache.org/apidocs/"
		}, {
			"title": "async",
			"url": "http://tsunanet.net/~tsuna/asynchbase/api/"
		}, {
			"title": "Home",
			"url": "https://hbase.apache.org/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "홈페이지",
	"type": "section",
	"children": [{
		"title": "전파의 종류",
		"type": "site",
		"url": "http://blog.naver.com/kilseok2?Redirect=Log&logNo=50019526239"
	}, {
		"title": "사내 및 IDC 필수 설치 프로그램",
		"type": "site",
		"url": "http://vaccine.nhncorp.com/"
	}]
});
bookmarks["children"].push({
	"title": "교육",
	"type": "section",
	"children": [{
		"title": "운중중학교",
		"type": "site",
		"url": "http://www.unjung.ms.kr/"
	}, {
		"title": "판교도서관",
		"type": "site",
		"url": "http://pg.snlib.net/"
	}, {
		"title": "판교청소년수련관",
		"type": "site",
		"url": "http://www.pgyouth.or.kr/"
	}]
});
bookmarks["children"].push({
	"title": "NHN",
	"type": "section",
	"children": [{
		"title": "개발자 센터",
		"type": "site",
		"url": "http://dev.naver.com/"
	}, {
		"title": "메신저 대화내용",
		"type": "site",
		"url": "http://msg-log.nhncorp.com/"
	}, {
		"title": "웹메일",
		"type": "site",
		"url": "http://mail.navercorp.com/"
	}, {
		"title": "보안접속",
		"type": "site",
		"url": "http://insec.nhncorp.com/",
		"children": [{
			"title": "nsa",
			"url": "https://nsasupport.navercorp.com/"
		}, {
			"title": "insec",
			"url": "http://insec.nhncorp.com/"
		}, {
			"title": "neosec",
			"url": "https://neosec.nhncorp.com/"
		}]
	}, {
		"title": "CONNECT",
		"type": "site",
		"url": "http://connect.navercorp.com/"
	}, {
		"title": "인프라솔루션개발랩",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/",
		"children": [{
			"title": "MOSS",
			"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/"
		}, {
			"title": "데브카페",
			"url": "http://devcafe.nhncorp.com/infra/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "nbp Solutions",
	"type": "section",
	"children": [{
		"title": "NSight",
		"type": "site",
		"url": "http://nsight.navercorp.com/",
		"children": [{
			"title": "ci",
			"url": "http://10.99.113.56:8888/hudson/"
		}, {
			"title": "API",
			"url": "http://api.nsight.navercorp.com/monapi/"
		}]
	}, {
		"title": "nms",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "nms",
			"url": "http://nms.navercorp.com/"
		}, {
			"title": "mactrack",
			"url": "http://mactrack.nms.navercorp.com/nms/"
		}]
	}, {
		"title": "TTS",
		"type": "site",
		"url": "http://tts.navercorp.com/"
	}, {
		"title": "BTS",
		"type": "site",
		"url": "http://bts4.navercorp.com/"
	}, {
		"title": "Connect+",
		"type": "site",
		"url": "http://10.99.217.121/"
	}, {
		"title": "IIMS2",
		"type": "site",
		"url": "http://iims2.navercorp.com/",
			"children": [{
				"title": "dev",
				"url": "http://dev-iims2.navercorp.com/"
			}, {
				"title": "dev2",
				"url": "http://dev2-iims2.navercorp.com/"
			}, {
				"title": "alpha",
				"url": "http://alpha-iims2.navercorp.com/"
			}, {
				"title": "real",
				"url": "http://iims2.navercorp.com/"
			}]
	}]
});
bookmarks["children"].push({
	"title": "nbp♡",
	"type": "section",
	"children": [{
		"title": "nCloud",
		"type": "site",
		"url": "http://ncloud.navercorp.com/"
	}, {
		"title": "idms",
		"type": "site",
		"url": "http://idms.navercorp.com/mylist.php"
	}, {
		"title": "E.S.M.",
		"type": "site",
		"url": "http://esm.nhncorp.com/"
	}, {
		"title": "---------------------.",
		"type": "site",
		"url": ""
	}, {
		"title": "Naver Developer Center",
		"type": "site",
		"url": "http://dev.naver.com/"
	}, {
		"title": "데브카페",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/"
	}]
});
bookmarks["children"].push({
	"title": "랩(Lab.)♡",
	"type": "section",
	"children": [{
		"title": "sos.운영(...28)",
		"type": "site",
		"url": "http://sos.navercorp.com/"
	}, {
		"title": "고메즈",
		"type": "site",
		"url": "http://gssm-web.navercorp.com/",
		"children": [{
			"title": "로컬",
			"url": "http://andold.kr/gomez/"
		}, {
			"title": "배치",
			"url": "http://andold.kr/gomez/batch/"
		}, {
			"title": "개발",
			"url": "http://dev.gssm-web.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://dev.gssm-web.navercorp.com/gomez/batch/"
		}, {
			 "title": "aws",
			"url": "http://dev.gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "운영",
			"url": "http://gssm-web.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://gssm-web.navercorp.com/gomez/batch/"
		}, {
			"title": "aws",
			"url": "http://gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "ci",
			"url": "http://dev.gssm-web.navercorp.com/jenkins/"
		}]
	}, {
		"title": "개인정보 취급단말기 인증",
		"type": "site",
		"url": "http://dev.appd.navercorp.com/",
		"children": [{
			"title": "로컬",
			"url": "http://andold.kr/appd/"
		}, {
			"title": "배치",
			"url": "http://andold.kr/appd/batch/"
		}, {
			"title": "개발",
			"url": "http://dev.appd.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://dev.appd.navercorp.com/appd/batch/"
		}, {
			"title": "통계",
			"url": "http://dev.appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "운영",
			"url": "http://appd.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://appd.navercorp.com/appd/batch/"
		}, {
			"title": "통계",
			"url": "http://appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "CI",
			"url": "http://dev.appd.navercorp.com/jenkins/"
		}, {
			"title": "BTS",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/APPD"
		}]
	}, {
		"title": "제니퍼",
		"type": "site",
		"url": "http://apm.nhncorp.com/",
		"children": [{
			"title": "운영",
			"url": "http://apm.nhncorp.com/"
		}, {
			"title": "개발",
			"url": "http://dev.apm.nhncorp.com/"
		}]
	}, {
		"title": "H제니퍼",
		"type": "site",
		"url": "http://10.112.128.97:7941/",
		"children": [{
			"title": "운영",
			"url": "http://10.112.128.97:7941/"
		}, {
			"title": "개발",
			"url": "http://10.25.149.73:7940/"
		}]
	}, {
		"title": "나의 제니퍼",
		"type": "site",
		"url": "http://10.99.68.228:7900/",
		"children": [{
			"title": "개발",
			"url": "http://dev.appd.navercorp.com:7900/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "랩(Lab.)♤",
	"type": "section",
	"children": [{
		"title": "ntree 운영",
		"type": "site",
		"url": "http://ntree.navercorp.com/",
		"children": [{
			"title": "ntree.kr",
			"url": "http://ntree.navercorp.com/ntree/"
		}, {
			"title": "awstats",
			"url": "http://ntree.navercorp.com/awstats/awstats.ntree.html"
		}, {
			"title": "jennifer",
			"url": "http://10.98.129.182:7900/"
		}]
	}, {
		"title": "NTree 개발",
		"type": "site",
		"url": "http://andold.kr/idcassign/",
		"children": [{
			"title": "NTree.kr",
			"url": "http://dev.ntree.navercorp.com/ntree/"
		}, {
			"title": "CI.kr",
			"url": "http://ntreedev.navercorp.com:8888/"
		}, {
			"title": "jennifer",
			"url": "http://10.101.26.192:7900/"
		}, {
			"title": "bts.kr",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/TANGO"
		}, {
			"title": "bts.glb.line",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/NTREEGCMDB"
		}]
	}, {
		"title": "NTree 로컬",
		"type": "site",
		"url": "http://andold.navercorp.com/ntree/",
		"children": [{
			"title": "NTree.kr",
			"url": "http://andold.navercorp.com/ntree/"
		}, {
			"title": "bts.kr",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/TANGO"
		}]
	}, {
		"title": "idcassign",
		"type": "site",
		"url": "http://andold.kr/idcassign/",
		"children": [{
			"title": "운영",
			"description": "운영계 > 상면자동할당",
			"url": "http://ntree.navercorp.com/idcassign/"
		}, {
			"title": "배치",
			"description": "운영계 > 상면자동할당 > 배치",
			"url": "http://ntree.navercorp.com/idcassign/batch/"
		}, {
			"title": "whois",
			"description": "운영계 > 누구게",
			"url": "http://ntree.navercorp.com/idcassign/whois"
		}, {
			"title": "awstats",
			"description": "운영계 > 상면자동할당 > awstats",
			"url": "http://ntree.navercorp.com/awstats/awstats.idcassign.html"
		}, {
			"title": "개발",
			"description": "개발계 > 상면자동할당",
			"url": "http://dev.ntree.navercorp.com/idcassign/"
		}, {
			"title": "배치",
			"description": "개발계 > 상면자동할당 > 배치",
			"url": "http://dev.ntree.navercorp.com/idcassign/batch/"
		}, {
			"title": "andold",
			"description": "로컬 > 상면자동할당",
			"url": "http://andold.kr/idcassign/v2/step1"
		}, {
			"title": "배치",
			"description": "로컬 > 상면자동할당 > 배치",
			"url": "http://andold.kr/idcassign/batch/"
		}, {
			"title": ":8080",
			"url": "http://andold.kr:8080/idcassign/v2/step1"
		}, {
			"title": "CI",
			"url": "http://dev.ntree.navercorp.com/idcassign/jenkins/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "ISAC",
	"url": "http://isac.navercorp.com/",
	"type": "section",
	"children": [{
		"title": "isac",
		"type": "site",
		"url": "http://isac.navercorp.com/",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/"
		}, {
			"title": "bts",
			"url": "http://bts.nhncorp.com/nhnbts/browse/ISAC"
		}, {
			"title": "moss",
			"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/IMSOperTeam/ISAC/"
		}, {
			"title": "ci",
			"url": "http://dev.isac.navercorp.com/jenkins/"
		}, {
			"title": "bds",
			"url": "http://iims2.navercorp.com/"
		}]
	}, {
		"title": "isac.awstats",
		"type": "site",
		"url": "http://isac.navercorp.com/awstats/awstats.isac.html",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/awstats/awstats.isac.html"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/awstats/awstats.isac.html"
		}]

	}]
});
bookmarks["children"].push({
	"title": "Naver Install",
	"type": "section",
	"children": [{
		"title": "[js] CI 환경구축 가이드",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/ajaxui/board_12/325898"
	}, {
		"title": "[js] 주석 문서 만들기",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/ajaxui/board_11/450678"
	}, {
		"title": "[js] Test",
		"type": "site",
		"url": "http://docs.jquery.com/Qunit"
	}, {
		"title": "설치 표준",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/index.php?mid=issuetracker&act=dispIssuetrackerDownload&vid=jdkwebwas"
	}, {
		"title": "QP.설치 표준",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/QPTalk/wiki_1"
	}, {
		"title": "허드슨 설치1",
		"type": "site",
		"url": "http://wikin.nhncorp.com/pages/viewpage.action?pageId=67819814"
	}, {
		"title": "허드슨 설치2",
		"type": "site",
		"url": "http://wikin.nhncorp.com/pages/viewpage.action?pageId=88121921"
	}]
});
bookmarks["children"].push({
	"title": "Naver 개발자 사이트",
	"type": "section",
	"children": [{
		"title": "XML 인터페이스 사내 표준",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/xmlapi/Documents/XML인터페이스개발자QuickReference.docx"
	}, {
		"title": "Quality Dashboard",
		"type": "site",
		"url": "http://nsiq.navercorp.com/"
	}, {
		"title": "TED.kor",
		"type": "site",
		"url": "http://www.ted.com/translate/languages/kor"
	}, {
		"title": "QPTalk",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/QPTalk"
	}, {
		"title": "커넥트스트랩",
		"type": "site",
		"url": "http://connectstrap.naver.com/",
		"children": [{
			"title": "knit",
			"url": "http://knit.naver.com/"
		}]
	}, {
		"title": "Coding Convention",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/NPARK/guide/nccg/"
	}, {
		"title": "Check Style",
		"type": "site",
		"url": "http://devcode.nhncorp.com/projects/csrs/"
	}, {
		"title": "N'SIQ Cpp Style",
		"type": "site",
		"url": "http://devcode.nhncorp.com/projects/nsiqcppcheck"
	}, {
		"title": "NHN 글쓰기 센터",
		"type": "site",
		"url": "http://tc.nhncorp.com/"
	}]
});
bookmarks["children"].push({
	"title": "Data Refenence",
	"type": "section",
	"children": [{
		"title": "아이콘",
		"type": "site",
		"url": "http://www.iconfinder.com/",
		"children": [{
			"title": "alpha",
			"url": "http://www.iconfinder.com/"
		}, {
			"title": "bravo",
			"url": "http://findicons.com/"
		}]
	}, {
		"title": "프레젠테이션",
		"type": "site",
		"url": "http://www.slideshare.net/"
	}, {
		"title": "논문",
		"type": "site",
		"url": "http://www.mendeley.com/"
	}, {
		"title": "HTML Color",
		"type": "site",
		"url": "http://www.jinbo21.net/g4/bbs/board.php?bo_table=study&wr_id=1r"
	}, {
		"title": "SVG Tools",
		"type": "site",
		"url": "http://www.openclipart.org/wiki/SVG_Tools"
	}, {
		"title": "mongodb - org",
		"type": "site",
		"url": "http://api.mongodb.org/java/current/"
	}, {
		"title": "mongodb - spring",
		"type": "site",
		"url": "http://static.springsource.org/spring-data/data-mongodb/docs/current/api/"
	}]
});
bookmarks["children"].push({
	"title": "API Reference",
	"type": "section",
	"children": [{
		"title": "javascript",
		"type": "site",
		"url": "https://developer.mozilla.org/en/JavaScript/Reference",
		"children": [{
			"title": "javascript",
			"url": "https://developer.mozilla.org/en/JavaScript/Reference"
		}, {
			"title": "jQuery",
			"url": "http://api.jquery.com/"
		}, {
			"title": "koxo",
			"url": "http://koxo.com/"
		}]
	}, {
		"title": "JAVA",
		"type": "site",
		"url": "http://docs.oracle.com/javase/8/docs/api/",
		"children": [{
			"title": "Java 6",
			"url": "http://docs.oracle.com/javase/6/docs/api/"
		}, {
			"title": "Java 7",
			"url": "http://docs.oracle.com/javase/7/docs/api/"
		}, {
			"title": "Spring",
			"url": "http://static.springsource.org/spring/docs/3.2.x/javadoc-api/"
		}, {
			"title": "JDOM",
			"type": "site",
			"url": "http://www.jdom.org/docs/apidocs/"
		}, {
			"title": "POI",
			"url": "http://poi.apache.org/apidocs/"
		}]
	}, {
		"title": "NNMS",
		"type": "site",
		"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218",
		"children": [{
			"title": "HBase",
			"url": "https://hbase.apache.org/apidocs/index.html"
		}, {
			"title": "Asynchbase",
			"url": "http://tsunanet.net/~tsuna/asynchbase/api/index.html?org/hbase/async/HBaseClient.html"
		}]
	}, {
		"title": "mongodb API",
		"type": "site",
		"url": "http://api.mongodb.org/java/current/",
		"children": [{
			"title": "org",
			"url": "http://api.mongodb.org/java/current/"
		}, {
			"title": "spring",
			"url": "http://static.springsource.org/spring-data/data-mongodb/docs/current/api/"
		}]
	}, {
		"title": "SVG",
		"type": "site",
		"url": "http://www.w3.org/TR/SVG/"
	}]
});
