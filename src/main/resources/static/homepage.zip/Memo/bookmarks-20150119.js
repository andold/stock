﻿var bookmarks = {
	"title": "잡다한 인연들",
	"type": "root",
	"children": []
};
bookmarks["children"].push({
	"title": "Neo Network Monitoring: 2015-01",
	"type": "section",
	"children": [{
		"title": "API",
		"type": "site",
		"url": "http://dev.kafka.nms.navercorp.com/prototype/",
		"children": [{
			"title": "HBase",
			"url": "https://hbase.apache.org/apidocs/index.html"
		}, {
			"title": "HBase-0.94",
			"url": "https://hbase.apache.org/0.94/apidocs/index.html"
		}, {
			"title": "Hadoop",
			"url": "https://hadoop.apache.org/docs/current/api/index.html"
		}, {
			"title": "HBase Master Info",
			"url": "http://10.99.116.41:60010/"
		}]
	}, {
		"title": "NMS Portal",
		"type": "site",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "위키 - 신규 NMS 개발",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218"
		}, {
			"title": "solarwinds",
			"url": "http://www.solarwinds.com/"
		}]
	}, {
		"title": "Dev.Zone",
		"type": "site",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "local.prototype",
			"url": "http://andold.kr/nms/"
		}, {
			"title": "kafka",
			"url": "http://dev.kafka.nms.navercorp.com/"
		}, {
			"title": "prototype",
			"url": "http://dev.kafka.nms.navercorp.com/prototype/"
		}, {
			"title": "jenkins",
			"url": "http://dev.kafka.nms.navercorp.com/jenkins/"
		}]
	}, {
		"title": "잡다한 조사",
		"type": "site",
		"children": [{
			"title": "zabbix",
			"url": "http://www.zabbix.com/",
		}, {
			"title": "Zabbix User",
			"url": "http://www.zabbix.co.kr/"
		}, {
			"title": "wikipedia",
			"url": "http://en.wikipedia.org/wiki/Zabbix"
		}]
	}]
});
bookmarks["children"].push({
	"title": "localhost",
	"type": "section",
	"children": [{
		"title": "2013년 03월 11일 백업",
		"type": "site",
		"url": "./Memo/20130311.html"
	}, {
		"title": "나의 달력",
		"type": "site",
		"url": "./Calendar/MyCalendar.html"
	}, {
		"title": "테스트",
		"type": "site",
		"url": "/test.html",
		"children": [{
			"title": "household",
			"url": "/test.household.html"
		}, {
			"title": "kant",
			"url": "http://kant.andold.kr/"
		}]
	}, {
		"title": "Suvival",
		"type": "site",
		"url": "Column/20110307.html"
	}]
});
bookmarks["children"].push({
	"title": "andold.kr",
	"type": "section",
	"children": [{
		"title": "andold",
		"type": "site",
		"url": "http://andold.kr/links.html",
		"children": [{
			"title": "infra",
			"url": "http://andold.kr/nbp/"
		}, {
			"title": "pmi",
			"url": "http://andold.kr/pmi/"
		}, {
			"title": "awstats",
			"url": "http://andold.kr/awstats/awstats.andold.html"
		}, {
			"title": "logicalmap",
			"url": "http://andold.kr/logicalmap/"
		}, {
			"title": "ngraph",
			"url": "http://andold.kr/ngraph/viewer/viewer.nhn?esm=N1005"
		}]
	}, {
		"title": "household",
		"type": "site",
		"url": "http://andold.kr/household/",
		"children": [{
			"title": "V3",
			"url": "http://andold.kr/household/v3/"
		}, {
			"title": "v2",
			"url": "http://andold.kr/household/v2/"
		}, {
			"title": "v1",
			"url": "http://andold.kr/household/"
		}, {
			"title": "lex",
			"url": "http://andold.kr/household/test/lex"
		}, {
			"title": "doc",
			"url": "http://andold.kr/javadoc/household/"
		}, {
			"title": "htm",
			"url": "http://andold.kr/links.htm"
		}, {
			"title": "html",
			"url": "http://andold.kr/links.html"
		}]
	}, {
		"title": "javadoc",
		"type": "site",
		"url": "http://andold.kr/javadoc/idcassign/",
		"children": [{
			"title": "idcassign",
			"url": "http://andold.kr/javadoc/idcassign/"
		}, {
			"title": "household",
			"url": "http://andold.kr/javadoc/household/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "ich",
	"type": "section",
	"children": [{
		"title": "ich",
		"type": "site",
		"url": "http://ich.andold.kr/links.htm",
		"children": [{
			"title": "htm",
			"url": "http://ich.andold.kr/links.htm"
		}, {
			"title": "html",
			"url": "http://ich.andold.kr/links.html"
		}, {
			"title": "awstats",
			"url": "http://ich.andold.kr/awstats/awstats.ich.html"
		}, {
			"title": "ci",
			"url": "http://ich.andold.kr/jenkins/"
		}, {
			"title": "download",
			"url": "http://ich.andold.kr/download/repository-20140420.dump.gz"
		}]
	}, {
		"title": "household",
		"type": "site",
		"url": "http://ich.andold.kr/links.htm",
		"children": [{
			"title": "V3",
			"url": "http://ich.andold.kr/household/v3/"
		}, {
			"title": "v2",
			"url": "http://ich.andold.kr/household/v2/"
		}, {
			"title": "v1",
			"url": "http://ich.andold.kr/household/"
		}, {
			"title": "lex",
			"url": "http://ich.andold.kr/household/test/lex"
		}]
	}, {
		"title": "ip",
		"type": "site",
		"url": "http://10.101.48.155/links.html",
		"children": [{
			"title": "V3",
			"url": "http://10.101.48.155/household/v3"
		}, {
			"title": "V2",
			"url": "http://10.101.48.155/household/v2/"
		}, {
			"title": "V1",
			"url": "http://10.101.48.155/household/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "금융♤",
	"type": "section",
	"children": [{
		"title": "은행권",
		"type": "site",
		"children": [{
			"title": "신한",
			"url": "http://www.shinhan.com/"
		}, {
			"title": "하나",
			"url": "http://www.hanabank.com/"
		}, {
			"title": "국민",
			"url": "http://www.kbstar.com/"
		}, {
			"title": "외환",
			"url": "http://www.keb.co.kr/"
		}, {
			"title": "산업",
			"url": "https://www.kdb.co.kr/"
		}, {
			"title": "농협",
			"url": "http://banking.nonghyup.com/"
		}]
	}, {
		"title": "신용카드",
		"type": "site",
		"children": [{
			"title": "현대",
			"url": "http://www.hyundaicard.com/"
		}, {
			"title": "삼성",
			"url": "http://www.samsungcard.co.kr/"
		}]
	}, {
		"title": "증권 기타",
		"type": "site",
		"children": [{
			"title": "한국투자",
			"url": "http://www.truefriend.com/"
		}, {
			"title": "삼성생명",
			"url": "http://www.samsunglife.com/"
		}]
	}, {
		"title": "금융 통계",
		"type": "site",
		"children": [{
			"title": "국세청",
			"url": "http://kosis.kr/nsp/abroad/abroad_01List.jsp"
		}, {
			"title": "한국은행",
			"url": "http://ecos.bok.or.kr/"
		}]
	}, {
		"title": "금융 기관",
		"type": "site",
		"children": [{
			"title": "홈텍스",
			"url": "http://www.hometax.go.kr/"
		}, {
			"title": "지로",
			"url": "http://www.giro.or.kr/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "API Reference 2/2",
	"type": "section",
	"children": [{
		"title": "JS Graph",
		"type": "site",
		"url": "http://neyric.github.com/wireit/",
		"children": [{
			"title": "WireIt",
			"url": "http://neyric.github.com/wireit/"
		}, {
			"title": "Raphael",
			"url": "http://raphaeljs.com/"
		}]
	}, {
		"title": "Neo Network Monitoring System",
		"type": "site",
		"url": "http://dev.kafka.nms.navercorp.com/prototype/",
		"children": [{
			"title": "HBase API",
			"url": "https://hbase.apache.org/apidocs/index.html"
		}, {
			"title": "HBase API-0.94",
			"url": "https://hbase.apache.org/0.94/apidocs/index.html"
		}, {
			"title": "Hadoop",
			"url": "https://hadoop.apache.org/docs/current/api/index.html"
		}, {
			"title": "HBase Master Info",
			"url": "http://10.99.116.41:60010/"
		}]
	}, {
		"title": "JS Chart",
		"type": "site",
		"url": "http://neyric.github.com/wireit/",
		"children": [{
			"title": "Highcharts(예제)",
			"url": "http://localhost/plugins/Highcharts-2.2.1/"
		}, {
			"title": "Open Flash Chart",
			"url": "http://teethgrinder.co.uk/open-flash-chart-2/"
		}]
	}, {
		"title": "dwr",
		"type": "site",
		"url": "http://directwebremoting.org/dwr/documentation/index.html"
	}, {
		"title": "dynatree.jQuery",
		"type": "site",
		"url": "http://code.google.com/p/dynatree/"
	}, {
		"title": "HTML5 Chart",
		"type": "site",
		"children": [{
			"title": "RGraph",
			"url": "http://www.rgraph.net/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}, {
			"title": "Awesome",
			"url": "http://cyberpython.github.com/AwesomeChartJS/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "단골 ♤",
	"type": "section",
	"children": [{
		"title": "매피",
		"type": "site",
		"url": "http://www.speednavi.co.kr/"
	}, {
		"title": "철천지",
		"type": "site",
		"url": "http://www.77g.com/"
	}, {
		"title": "대신특수목재",
		"type": "site",
		"url": "http://www.wood21.co.kr/"
	}, {
		"title": "[메일] 한메일",
		"type": "site",
		"url": "http://www.daum.net/"
	}, {
		"title": "공동육아",
		"type": "site",
		"url": "http://www.gongdong.or.kr/"
	}, {
		"title": "김대성",
		"type": "site",
		"url": "http://www.aeris.net/"
	}, {
		"title": "SKT",
		"type": "site",
		"url": "http://www.tworld.co.kr/"
	}, {
		"title": "[신문] 한겨레신문",
		"type": "site",
		"url": "http://www.hani.co.kr/"
	}]
});
bookmarks["children"].push({
	"title": "찾기",
	"type": "section",
	"children": [{
		"title": "[지도] 네이버",
		"type": "site",
		"url": "http://map.naver.com/"
	}, {
		"title": "[PDA] 투데이스피피시",
		"type": "site",
		"url": "http://www.todaysppc.com/"
	}, {
		"title": "[PDA] Freeware",
		"type": "site",
		"url": "http://www.freewareppc.com/"
	}, {
		"title": "네이버",
		"type": "site",
		"url": "http://www.naver.com"
	}, {
		"title": "위키백과",
		"type": "site",
		"url": "http://ko.wikipedia.org/"
	}, {
		"title": "구글",
		"type": "site",
		"url": "http://www.google.co.kr/"
	}, {
		"title": "후이즈 검색",
		"type": "site",
		"url": "http://whois.nida.or.kr/"
	}]
});
bookmarks["children"].push({
	"title": "가게 ♡",
	"type": "section",
	"children": [{
		"title": "[쇼핑] 지마켓",
		"type": "site",
		"url": "http://www.gmarket.co.kr/"
	}, {
		"title": "[경매] 옥션",
		"type": "site",
		"url": "http://www.auction.co.kr"
	}, {
		"title": "[책] YES24",
		"type": "site",
		"url": "http://www.yes24.com"
	}, {
		"title": "[비교] 에누리",
		"type": "site",
		"url": "http://www.enuri.com"
	}]
});
bookmarks["children"].push({
	"title": "참여",
	"type": "section",
	"children": [{
		"title": "정치후원금센터",
		"type": "site",
		"url": "http://www.give.go.kr/"
	}, {
		"title": "오마이뉴스",
		"type": "site",
		"url": "http://www.ohmynews.com/"
	}, {
		"title": "프레시안",
		"type": "site",
		"url": "http://www.pressian.com/"
	}, {
		"title": "서프라이즈",
		"type": "site",
		"url": "http://www.seoprise.com/"
	}, {
		"title": "외국인 노동자의 집",
		"type": "site",
		"url": "http://www.g4w.net/"
	}, {
		"title": "물뚝심송",
		"type": "site",
		"url": "http://murutukus.kr/"
	}]
});
bookmarks["children"].push({
	"title": "문화",
	"type": "section",
	"children": [{
		"title": "담뽀뽀",
		"type": "site",
		"url": "http://www.dampopo.com/"
	}, {
		"title": "ampet",
		"type": "site",
		"url": "http://www.ampet.co.kr/"
	}, {
		"title": "trofish",
		"type": "site",
		"url": "http://www.trofish.net/"
	}, {
		"title": "물의나라",
		"type": "site",
		"url": "http://www.fishworld114.com/"
	}, {
		"title": "피알피쉬",
		"type": "site",
		"url": "http://www.prfish.com/"
	}, {
		"title": "딸랑이",
		"type": "site",
		"url": "http://blog.joinsmsn.com/media/index.asp?uid=ooyaggo"
	}, {
		"title": "딴지일보",
		"type": "site",
		"url": "http://www.ddanzi.com/"
	}]
});
bookmarks["children"].push({
	"title": "개발♤",
	"type": "section",
	"children": [{
		"title": "데브피아",
		"type": "site",
		"url": "http://www.devpia.com/"
	}, {
		"title": "마이크로소프트",
		"type": "site",
		"url": "http://www.microsoft.com/"
	}, {
		"title": "한빛 네트워크",
		"type": "site",
		"url": "http://network.hanb.co.kr/list.php"
	}, {
		"title": "자북",
		"type": "site",
		"url": "http://www.jabook.net/"
	}]
});
bookmarks["children"].push({
	"title": "홈페이지",
	"type": "section",
	"children": [{
		"title": "전파의 종류",
		"type": "site",
		"url": "http://blog.naver.com/kilseok2?Redirect=Log&logNo=50019526239"
	}, {
		"title": "사내 및 IDC 필수 설치 프로그램",
		"type": "site",
		"url": "http://vaccine.nhncorp.com/"
	}, {
		"title": "서버관리시스템 - 개발계",
		"type": "site",
		"url": "http://dev.server.nhncorp.com/"
	}, {
		"title": "서버관리시스템 - 운영계",
		"type": "site",
		"url": "http://server.nhncorp.com/"
	}, {
		"title": "DMTF",
		"type": "site",
		"url": "http://www.dmtf.org/"
	}, {
		"title": "경기도버스정보시스템",
		"type": "site",
		"url": "http://www.gbis.go.kr/"
	}]
});
bookmarks["children"].push({
	"title": "교육",
	"type": "section",
	"children": [{
		"title": "산운초등학교",
		"type": "hidden",
		"url": "http://sanun.es.kr/"
	}, {
		"title": "운중중학교",
		"type": "site",
		"url": "http://www.unjung.ms.kr/"
	}, {
		"title": "운중고등학교",
		"type": "site",
		"url": "http://www.unjung.hs.kr/"
	}, {
		"title": "판교도서관",
		"type": "site",
		"url": "http://pg.snlib.net/"
	}, {
		"title": "판교청소년수련관",
		"type": "site",
		"url": "http://www.pgyouth.or.kr/"
	}, {
		"title": "필라테스",
		"type": "site",
		"url": "http://www.thinkpilates.co.kr/"
	}, {
		"title": "운중중학교",
		"type": "site",
		"url": "http://unjung.ms.kr/"
	}]
});
bookmarks["children"].push({
	"title": "NHN",
	"type": "section",
	"children": [{
		"title": "서플센터 메인",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/sforum"
	}, {
		"title": "개발자 센터",
		"type": "site",
		"url": "http://dev.naver.com/"
	}, {
		"title": "메신저 대화내용",
		"type": "site",
		"url": "http://msg-log.nhncorp.com/"
	}, {
		"title": "웹메일",
		"type": "site",
		"url": "http://mail.navercorp.com/"
	}, {
		"title": "보안접속",
		"type": "site",
		"url": "http://insec.nhncorp.com/",
		"children": [{
			"title": "nsa",
			"url": "https://nsasupport.navercorp.com/"
		}, {
			"title": "insec",
			"url": "http://insec.nhncorp.com/"
		}, {
			"title": "neosec",
			"url": "https://neosec.nhncorp.com/"
		}]
	}, {
		"title": "CONNECT",
		"type": "site",
		"url": "http://connect.navercorp.com/"
	}, {
		"title": "Project M.S.",
		"type": "site",
		"url": "http://pms.navercorp.com/"
	}, {
		"title": "인프라솔루션개발랩",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/",
		"children": [{
			"title": "MOSS",
			"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/"
		}, {
			"title": "데브카페",
			"url": "http://devcafe.nhncorp.com/infra/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "nbp Solutions",
	"type": "section",
	"children": [{
		"title": "nSight",
		"type": "site",
		"url": "http://nsight.navercorp.com/",
		"children": [{
			"title": "ci",
			"url": "http://10.99.113.56:8888/hudson/"
		}, {
			"title": "API",
			"url": "http://api.nsight.navercorp.com/monapi/"
		}]
	}, {
		"title": "TTS",
		"type": "site",
		"url": "http://tts.navercorp.com/"
	}, {
		"title": "토파즈",
		"type": "site",
		"url": "http://topaz.nhncorp.com/"
	}, {
		"title": "NMS Portal",
		"type": "site",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "위키 - 신규 NMS 개발",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218"
		}, {
			"title": "local.prototype",
			"url": "http://andold.kr/nms/"
		}, {
			"title": "dev.kafka",
			"url": "http://dev.kafka.nms.navercorp.com/"
		}, {
			"title": "dev.prototype.event",
			"url": "http://dev.kafka.nms.navercorp.com/prototype/"
		}, {
			"title": "dev.prototype.ci",
			"url": "http://dev.kafka.nms.navercorp.com/jenkins/"
		}, {
			"title": "solarwinds",
			"url": "http://www.solarwinds.com/"
		}]
	}, {
		"title": "IP Mgr System",
		"type": "site",
		"url": "http://ipadm.nhncorp.com:8099/ipms/"
	}, {
		"title": "BTS",
		"type": "site",
		"url": "http://bts4.nhncorp.com/"
	}, {
		"title": "Connect+",
		"type": "site",
		"url": "http://10.99.217.121/"
	}, {
		"title": "IIMS2",
		"type": "site",
		"url": "http://iims2.navercorp.com/",
			"children": [{
				"title": "dev",
				"url": "http://dev-iims2.navercorp.com/"
			}, {
				"title": "dev2",
				"url": "http://dev2-iims2.navercorp.com/"
			}, {
				"title": "alpha",
				"url": "http://alpha-iims2.navercorp.com/"
			}, {
				"title": "real",
				"url": "http://iims2.navercorp.com/"
			}]
	}]
});
bookmarks["children"].push({
	"title": "nbp♡",
	"type": "section",
	"children": [{
		"title": "nCloud",
		"type": "site",
		"url": "http://ncloud.navercorp.com/"
	}, {
		"title": "idms",
		"type": "site",
		"url": "http://idms.navercorp.com/mylist.php"
	}, {
		"title": "E.S.M.",
		"type": "site",
		"url": "http://esm.nhncorp.com/"
	}, {
		"title": "---------------------.",
		"type": "site",
		"url": ""
	}, {
		"title": "네이버 다이어리",
		"type": "site",
		"url": "http://naver_diary.blog.me/"
	}, {
		"title": "PaaS",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/paas/"
	}, {
		"title": "Technical Library",
		"type": "site",
		"url": "http://lib.nhncorp.com/"
	}, {
		"title": "개발 공통",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/NPARK/dcommon/"
	}, {
		"title": "Naver Developer Center",
		"type": "site",
		"url": "http://dev.naver.com/"
	}, {
		"title": "Hackystat",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/set/EtcTop/Hackystat/"
	}, {
		"title": "데브카페",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/"
	}]
});
bookmarks["children"].push({
	"title": "랩(Lab.)♡",
	"type": "section",
	"children": [{
		"title": "sos.운영(...28)",
		"type": "site",
		"url": "http://sos.navercorp.com/"
	}, {
		"title": "고메즈",
		"type": "site",
		"url": "http://gssm-web.navercorp.com/",
		"children": [{
			"title": "로컬",
			"url": "http://andold.kr/gomez/"
		}, {
			"title": "배치",
			"url": "http://andold.kr/gomez/batch/"
		}, {
			"title": "개발",
			"url": "http://dev.gssm-web.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://dev.gssm-web.navercorp.com/gomez/batch/"
		}, {
			 "title": "aws",
			"url": "http://dev.gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "운영",
			"url": "http://gssm-web.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://gssm-web.navercorp.com/gomez/batch/"
		}, {
			"title": "aws",
			"url": "http://gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "ci",
			"url": "http://dev.gssm-web.navercorp.com/jenkins/"
		}]
	}, {
		"title": "개인정보 취급단말기 인증",
		"type": "site",
		"url": "http://dev.appd.navercorp.com/",
		"children": [{
			"title": "로컬",
			"url": "http://andold.kr/appd/"
		}, {
			"title": "배치",
			"url": "http://andold.kr/appd/batch/"
		}, {
			"title": "개발",
			"url": "http://dev.appd.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://dev.appd.navercorp.com/appd/batch/"
		}, {
			"title": "통계",
			"url": "http://dev.appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "αIIMS",
			"url": "http://alpha-iims2.navercorp.com/"
		}, {
			"title": "테스트",
			"url": "http://dev2-iims2.navercorp.com/"
		}, {
			"title": "운영",
			"url": "http://appd.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://appd.navercorp.com/appd/batch/"
		}, {
			"title": "통계",
			"url": "http://appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "CI",
			"url": "http://dev.appd.navercorp.com/jenkins/"
		}, {
			"title": "BTS",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/APPD"
		}]
	}, {
		"title": "제니퍼",
		"type": "site",
		"url": "http://apm.nhncorp.com/",
		"children": [{
			"title": "운영",
			"url": "http://apm.nhncorp.com/"
		}, {
			"title": "개발",
			"url": "http://dev.apm.nhncorp.com/"
		}]
	}, {
		"title": "H제니퍼",
		"type": "site",
		"url": "http://10.112.128.97:7941/",
		"children": [{
			"title": "운영",
			"url": "http://10.112.128.97:7941/"
		}, {
			"title": "개발",
			"url": "http://10.25.149.73:7940/"
		}]
	}, {
		"title": "나의 제니퍼",
		"type": "site",
		"url": "http://10.99.68.228:7900/",
		"children": [{
			"title": "개발",
			"url": "http://dev.appd.navercorp.com:7900/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "랩(Lab.)♤",
	"type": "section",
	"children": [{
		"title": "ntree 운영",
		"type": "site",
		"url": "http://ntree.navercorp.com/",
		"children": [{
			"title": "ntree.kr",
			"url": "http://ntree.navercorp.com/ntree/"
		}, {
			"title": "src",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/idc_dashboards/trunk/idc_dashboards_new"
		}, {
			"title": "캐시 리셋",
			"url": "http://ntree.navercorp.com/ntree/test/resetMenuCache.jsp"
		}, {
			"title": "awstats",
			"url": "http://ntree.navercorp.com/awstats/awstats.ntree.html"
		}, {
			"title": "jennifer",
			"url": "http://10.98.129.182:7900/"
		}, {
			"title": "ntree.jp",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/idc_dashboards/branches/GCMDB2/idc_dashboards_new"
		}, {
			"title": "src",
			"url": "http://dev.ntree.navercorp.com/"
		}, {
			"title": "LINK.kr",
			"url": "http://ntree.navercorp.com/link/"
		}, {
			"title": "src",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/link/trunk/link_web"
		}, {
			"title": "LINK.glb.src",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/link/branches/GCMDB_Link"
		}, {
			"title": "배치",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/link/trunk/link_batch/tango_outgw"
		}, {
			"title": "배치.glb",
			"url": "http://svn2.bds.nhncorp.com/tango.nhncorp/link/branches/GCMDB_OUTGW"
		}, {
			"title": "report",
			"url": "http://report.ntree.navercorp.com/"
		}]
	}, {
		"title": "NTree 개발",
		"type": "site",
		"url": "http://andold.kr/idcassign/",
		"children": [{
			"title": "NTree.kr",
			"url": "http://dev.ntree.navercorp.com/ntree/"
		}, {
			"title": "NTree.jp.line",
			"url": "http://dev.ntree-jp.navercorp.com/ntree/"
		}, {
			"title": "CI.kr",
			"url": "http://ntreedev.navercorp.com:8888/"
		}, {
			"title": "CI.jp",
			"url": "http://dev.ntree-jp.navercorp.com:8080/"
		}, {
			"title": "jennifer",
			"url": "http://10.101.26.192:7900/"
		}, {
			"title": "bts.kr",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/TANGO"
		}, {
			"title": "bts.glb.line",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/NTREEGCMDB"
		}]
	}, {
		"title": "NTree 로컬",
		"type": "site",
		"url": "http://andold.navercorp.com/ntree/",
		"children": [{
			"title": "NTree.kr",
			"url": "http://andold.navercorp.com/ntree/"
		}, {
			"title": "NTree.jp.line",
			"url": "http://andold.navercorp.com/jp/"
		}, {
			"title": "bts.kr",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/TANGO"
		}, {
			"title": "bts.glb.line",
			"url": "http://bts4.nhncorp.com/nhnbts/browse/NTREEGCMDB"
		}]
	}, {
		"title": "idcassign",
		"type": "site",
		"url": "http://andold.kr/idcassign/",
		"children": [{
			"title": "운영",
			"description": "운영계 > 상면자동할당",
			"url": "http://ntree.navercorp.com/idcassign/"
		}, {
			"title": "배치",
			"description": "운영계 > 상면자동할당 > 배치",
			"url": "http://ntree.navercorp.com/idcassign/batch/"
		}, {
			"title": "whois",
			"description": "운영계 > 누구게",
			"url": "http://ntree.navercorp.com/idcassign/whois"
		}, {
			"title": "awstats",
			"description": "운영계 > 상면자동할당 > awstats",
			"url": "http://ntree.navercorp.com/awstats/awstats.idcassign.html"
		}, {
			"title": "예약",
			"description": "운영계 > 상면자동할당 > 예약 현황",
			"url": "http://ntree.navercorp.com/idcassign/holeReserved"
		}, {
			"title": "개발",
			"description": "개발계 > 상면자동할당",
			"url": "http://dev.ntree.navercorp.com/idcassign/"
		}, {
			"title": "배치",
			"description": "개발계 > 상면자동할당 > 배치",
			"url": "http://dev.ntree.navercorp.com/idcassign/batch/"
		}, {
			"title": "andold",
			"description": "로컬 > 상면자동할당",
			"url": "http://andold.kr/idcassign/"
		}, {
			"title": "andold-v2",
			"description": "로컬 > 상면자동할당",
			"url": "http://andold.kr/idcassign2/"
		}, {
			"title": "배치",
			"description": "로컬 > 상면자동할당 > 배치",
			"url": "http://andold.kr/idcassign/batch/"
		}, {
			"title": "api",
			"description": "로컬 > 상면자동할당 > Javadoc",
			"url": "http://andold.kr/javadoc/idcassign/"
		}, {	
			"title": "춘천",
			"description": "로컬 > 상면자동할당 > 춘천IDC",
			"url": "http://andold.kr/idcassign/chuncheon/"
		}, {
			"title": "NTree 연동",
			"description": "로컬 > 상면자동할당 > NTree 연동",
			"url": "http://andold.kr/idcassign/test.jsp"
		}, {
			"title": "CI",
			"url": "http://dev.ntree.navercorp.com/idcassign/jenkins/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "ISAC",
	"url": "http://isac.navercorp.com/",
	"type": "section",
	"children": [{
		"title": "isac",
		"type": "site",
		"url": "http://isac.navercorp.com/",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/"
		}, {
			"title": "bts",
			"url": "http://bts.nhncorp.com/nhnbts/browse/ISAC"
		}, {
			"title": "moss",
			"url": "http://moss.nhncorp.com/sites/spd/InfraSolDev/IMSOperTeam/ISAC/"
		}, {
			"title": "ci",
			"url": "http://dev.isac.navercorp.com/jenkins/"
		}, {
			"title": "bds",
			"url": "http://iims2.navercorp.com/"
		}]
	}, {
		"title": "isac.awstats",
		"type": "site",
		"url": "http://isac.navercorp.com/awstats/awstats.isac.html",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/awstats/awstats.isac.html"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/awstats/awstats.isac.html"
		}]

	}]
});
bookmarks["children"].push({
	"title": "NHN Install",
	"type": "section",
	"children": [{
		"title": "[js] CI 환경구축 가이드",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/ajaxui/board_12/325898"
	}, {
		"title": "[js] 주석 문서 만들기",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/ajaxui/board_11/450678"
	}, {
		"title": "[js] Test",
		"type": "site",
		"url": "http://docs.jquery.com/Qunit"
	}, {
		"title": "설치 표준",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/index.php?mid=issuetracker&act=dispIssuetrackerDownload&vid=jdkwebwas"
	}, {
		"title": "QP.설치 표준",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/QPTalk/wiki_1"
	}, {
		"title": "허드슨 설치1",
		"type": "site",
		"url": "http://wikin.nhncorp.com/pages/viewpage.action?pageId=67819814"
	}, {
		"title": "허드슨 설치2",
		"type": "site",
		"url": "http://wikin.nhncorp.com/pages/viewpage.action?pageId=88121921"
	}]
});
bookmarks["children"].push({
	"title": "NHN 개발자 사이트",
	"type": "section",
	"children": [{
		"title": "XML 인터페이스 사내 표준",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/xmlapi/Documents/XML인터페이스개발자QuickReference.docx"
	}, {
		"title": "Quality Dashboard",
		"type": "site",
		"url": "http://nsiq.navercorp.com/"
	}, {
		"title": "TED.kor",
		"type": "site",
		"url": "http://www.ted.com/translate/languages/kor"
	}, {
		"title": "QPTalk",
		"type": "site",
		"url": "http://devcafe.nhncorp.com/QPTalk"
	}, {
		"title": "커넥트스트랩",
		"type": "site",
		"url": "http://connectstrap.naver.com/",
		"children": [{
			"title": "knit",
			"url": "http://knit.naver.com/"
		}]
	}, {
		"title": "Coding Convention",
		"type": "site",
		"url": "http://moss.nhncorp.com/sites/NPARK/guide/nccg/"
	}, {
		"title": "Check Style",
		"type": "site",
		"url": "http://devcode.nhncorp.com/projects/csrs/"
	}, {
		"title": "N'SIQ Cpp Style",
		"type": "site",
		"url": "http://devcode.nhncorp.com/projects/nsiqcppcheck"
	}, {
		"title": "NHN 글쓰기 센터",
		"type": "site",
		"url": "http://tc.nhncorp.com/"
	}]
});
bookmarks["children"].push({
	"title": "Data Refenence",
	"type": "section",
	"children": [{
		"title": "아이콘",
		"type": "site",
		"url": "http://www.iconfinder.com/",
		"children": [{
			"title": "alpha",
			"url": "http://www.iconfinder.com/"
		}, {
			"title": "bravo",
			"url": "http://findicons.com/"
		}]
	}, {
		"title": "프레젠테이션",
		"type": "site",
		"url": "http://www.slideshare.net/"
	}, {
		"title": "논문",
		"type": "site",
		"url": "http://www.mendeley.com/"
	}, {
		"title": "HTML Color",
		"type": "site",
		"url": "http://www.jinbo21.net/g4/bbs/board.php?bo_table=study&wr_id=1r"
	}, {
		"title": "SVG Tools",
		"type": "site",
		"url": "http://www.openclipart.org/wiki/SVG_Tools"
	}, {
		"title": "mongodb - org",
		"type": "site",
		"url": "http://api.mongodb.org/java/current/"
	}, {
		"title": "mongodb - spring",
		"type": "site",
		"url": "http://static.springsource.org/spring-data/data-mongodb/docs/current/api/"
	}]
});
bookmarks["children"].push({
	"title": "API Reference",
	"type": "section",
	"children": [{
		"title": "javascript",
		"type": "site",
		"url": "https://developer.mozilla.org/en/JavaScript/Reference",
		"children": [{
			"title": "javascript",
			"url": "https://developer.mozilla.org/en/JavaScript/Reference"
		}, {
			"title": "jQuery",
			"url": "http://api.jquery.com/"
		}, {
			"title": "koxo",
			"url": "http://koxo.com/"
		}]
	}, {
		"title": "JAVA API",
		"type": "site",
		"url": "http://java.sun.com/javase/6/docs/api/",
		"children": [{
			"title": "Java 6",
			"url": "http://java.sun.com/javase/6/docs/api/"
		}, {
			"title": "Spring",
			"url": "http://static.springsource.org/spring/docs/3.2.x/javadoc-api/"
		}, {
			"title": "JDOM",
			"type": "site",
			"url": "http://www.jdom.org/docs/apidocs/"
		}, {
			"title": "POI",
			"url": "http://poi.apache.org/apidocs/"
		}]
	}, {
		"title": "mongodb API",
		"type": "site",
		"url": "http://api.mongodb.org/java/current/",
		"children": [{
			"title": "org",
			"url": "http://api.mongodb.org/java/current/"
		}, {
			"title": "spring",
			"url": "http://static.springsource.org/spring-data/data-mongodb/docs/current/api/"
		}]
	}, {
		"title": "jgraph",
		"type": "site",
		"url": "http://www.jgraph.com/"
	}, {
		"title": "ExtJS3",
		"type": "site",
		"url": "http://localhost/plugins/ext-3.4.0/"
	}, {
		"title": "Highcharts",
		"type": "site",
		"url": "http://www.highcharts.com/ref/"
	}, {
		"title": "ExtJS4",
		"type": "site",
		"url": "http://localhost/plugins/ext-4.0.7-gpl/"
	}, {
		"title": "SVG",
		"type": "site",
		"url": "http://www.w3.org/TR/SVG/"
	}, {
		"title": "Canvas.2d",
		"type": "site",
		"url": "http://dev.w3.org/html5/2dcontext/"
	}]
});
