var	strScreen	=	"";
var	strBuffer	=	"";
var	IMEc	=	"";
var	tbl	=	['��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��',
				'��', '��', '��', '��'];
function	IsNormalKey(c)
{
	return((c >= '1') && (c <= '9'));
}
function	IsSelectKey(c)
{
	return((c == '*') || (c == '0') || (c == '#'));
}
function	IsControlKey(c)
{
	return((c == 'S') || (c == 'C') || (c == 'E'));
}
function	Refresh()
{
	var	v	=	eval(strScreen);
	if(IMEc == '')	v.value	=	strBuffer;
	else			v.value	=	strBuffer + KeyToChar(IMEc, '');
}
function	EventChar(c)
{
	strBuffer	+=	c;
}
function	KeyToChar(c, s)
{
	var	n	=	0;
	if(s == '')	n	=	0;
	else if(s == '*')	n	=	1;
	else if(s == '0')	n	=	2;
	else	n	=	3;
	return(tbl[(c - '1') * 4 + n]);
}
function	EventKey(c)
{
	if(IsNormalKey(c))
	{
		if(IsNormalKey(IMEc))
		{
			EventChar(KeyToChar(IMEc, ''));
			IMEc	=	c;
			Refresh();
			return;
		}
		IMEc	=	c;
		Refresh();
		return;
	}
	if(IsSelectKey(c))
	{
		if(IsNormalKey(IMEc))
		{
			EventChar(KeyToChar(IMEc, c));
			IMEc	=	"";
			Refresh();
			return;
		}
		alert("Error");
		return;
	}
	if(IsControlKey(c))
	{
		if(c == 'C')
		{
			if(IMEc != '')
			{
				IMEc	=	'';
				Refresh();
				return;
			}
			strBuffer	=	String(strBuffer).Left(String(strBuffer).length - 1);
			Refresh();
			return;
		}
		alert("Not Implemented");
		return;
	}
	alert("Error: Not Acceptable.");
	return;
}
