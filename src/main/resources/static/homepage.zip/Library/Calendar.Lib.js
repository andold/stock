//	1841 ~ 2041 �� ������ �����˴ϴ�.
var	gCalendarData;
CalendarDataInitialize();
function	CalendarDataInitialize()	{
	var	cx, cy;
	var	dtm;
	gCalendarData				=	new Object;
	gCalendarData.mSynodicMonth	=	29.530588;		//	1�����(Synodic Month)
	gCalendarData.mSolarPeriod	=	365.2421949;
	gCalendarData.mTropicalYear	=	365.24219879;	//	1ȸ�ͳ�(Tropical Year)
	gCalendarData.mWhat			=	1.472;			//	10^11 ����(�¾� ������)
	gCalendarData.mWhat			=	1.521;			//	10^11 ����(�¾������)
//	1�׼���		=	23:56:04
//	���� �ӵ�	=	299792458 m/s
	gCalendarData.mLunarMonth	=	new Array(0, 29, 30, 58, 59, 59, 60);
	gCalendarData.mLunar		=	new Array();
	cx	=	0;
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 4, 1, 1, 2, 1, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 2, 1, 4, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 5, 2, 1, 2, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 3, 2, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 5, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 5, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 5, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 6, 1, 1, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 2, 1, 2, 2, 3, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 4, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 3, 2, 1, 1, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 2, 1, 2, 1, 1, 5, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 4, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 5, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 4, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 5, 2, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 3, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 5, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 5, 2, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 5, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 5, 2, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 5, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 3, 2, 1, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 4, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 5, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 5, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 3, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 5, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 3, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 5, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 1, 2, 1, 1, 2, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 1, 5, 1, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 6, 1, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 4, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 2, 1, 4, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 4, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 4, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 5, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 3, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 4, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 4, 1, 1, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 1, 5, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 5, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 3, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 5, 2, 1, 1, 2, 1, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 5, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 5, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 5, 1, 2, 1, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 5, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 6, 1, 2, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 3, 2, 1, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 1, 2, 1, 1, 5, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 5, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 5, 1, 2, 1, 2, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 5, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 2, 1, 5, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 3, 2, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 2, 3, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 2, 1, 5, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 1, 5, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 6, 2, 1, 2, 1, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 2, 1, 2, 5, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 3, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 5, 2, 1, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 5, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 2, 1, 5, 1, 2, 1, 1, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 5, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 5, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 4, 1, 1, 2, 1, 2, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 2, 1, 2, 5, 2, 1, 2, 1, 2, 1, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 0);
	gCalendarData.mLunar[cx++]	=	new Array(2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 5, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 0);
	gCalendarData.mLunar[cx++]	=	new Array(1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 0);
	for(cx = 0;cx < gCalendarData.mLunar.length;cx++)	{
		lng	=	0;
		for(cy = 0;cy < 12;cy++)	{
			lng	=	lng + gCalendarData.mLunarMonth[gCalendarData.mLunar[cx][cy]];
		}
		gCalendarData.mLunar[cx][12]	=	lng;
	}
	gCalendarData.mAnniversary	=	new Array();
	gCalendarData.Language				=	new Object;
	gCalendarData.Language.Weekday		=	new Array();
	gCalendarData.Language.Weekday[0]	=	new Array("0", "1", "2", "3", "4", "5", "6");
	gCalendarData.Language.Weekday[1]	=	new Array("��", "��", "ȭ", "��", "��", "��", "��");
	gCalendarData.Language.Weekday[2]	=	new Array("�Ͽ���", "������", "ȭ����", "������", "�����", "�ݿ���", "�����");
	gCalendarData.Language.TABLE		=	new Array("", "<table width=163 cellpadding=2 cellspacing=0>", "<table width=100% height=100% valign=top bgcolor=black cellpadding=5 cellspacing=1>");
	gCalendarData.Language.DayFontSize	=	new Array("<font>", "<font style=\"font-size:10pt\">", "<font style=\"font-size:24pt\">");
}
/*	lngAnniversaryCategory
	0:	Default
	1:	������
	2:	������
	3:	�����
	4:	�Ϲ�����
	lngRepeatType
	0:	default
	1:	�ų�
	2:	�ſ�
	3:	����
	4:	����
	lngRepeatValue
	0:	default
	n:	n��/��/�� ����
*/
function	AddAnniversary(lngAnniversaryCategory, blnSolar, lngRepeatType, lngRepeatValue, lngYear, lngMonth, lngDay,
							blnLunarExtraMonth, lngDiffDays, strTitle, strContent)	{
	var	cx;
	cx	=	gCalendarData.mAnniversary.length;
	gCalendarData.mAnniversary[cx]				=	new Object;
	gCalendarData.mAnniversary[cx].lngCategory	=	lngAnniversaryCategory;
	gCalendarData.mAnniversary[cx].blnSolar		=	blnSolar;
	gCalendarData.mAnniversary[cx].lngRType		=	lngRepeatType;
	gCalendarData.mAnniversary[cx].lngRValue	=	lngRepeatValue;
	gCalendarData.mAnniversary[cx].lngYear		=	lngYear;
	gCalendarData.mAnniversary[cx].lngMonth		=	lngMonth;
	gCalendarData.mAnniversary[cx].lngDay		=	lngDay;
	gCalendarData.mAnniversary[cx].blnLExt		=	blnLunarExtraMonth;
	gCalendarData.mAnniversary[cx].lngDelta		=	lngDiffDays;
	gCalendarData.mAnniversary[cx].strTitle		=	strTitle;
	gCalendarData.mAnniversary[cx].strContent	=	strContent;
}
function	SetMinusDate(oD)	{
	var	lngTotal;
	if(oD.lngYear < 1841 || oD.lngYear > 2041 || oD.lngMonth < 1 || oD.lngMonth > 12)	{
		oD.lngMYear		=	0;
		oD.lngMMonth	=	0;
		oD.lngMDay		=	0;
		oD.lngMFlag		=	false;
		return;
	}
	lngTotal	=	GetTotalDays(oD.lngYear, oD.lngMonth, oD.lngDay) - GetTotalDays(1841, 1, 22);
	oD.lngMYear	=	0;
	while(lngTotal > gCalendarData.mLunar[oD.lngMYear][12])	{
		lngTotal	=	lngTotal - gCalendarData.mLunar[oD.lngMYear][12];
		oD.lngMYear++;
	}
	oD.lngMMonth	=	1;
	while(lngTotal > gCalendarData.mLunarMonth[gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1]])	{
		lngTotal	=	lngTotal - gCalendarData.mLunarMonth[gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1]];
		oD.lngMMonth++;
	}
	oD.lngMFlag	=	false;
	if(((gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1] == 3) || (gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1] == 4)) && (lngTotal > 29))	{
		oD.lngMDay	=	lngTotal - 29;
		oD.lngMFlag	=	true;
	}
	else if(((gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1] == 5) || (gCalendarData.mLunar[oD.lngMYear][oD.lngMMonth - 1] == 6)) && (lngTotal > 30))	{
		oD.lngMDay	=	lngTotal - 30;
		oD.lngMFlag	=	true;
	}
	else	{
		oD.lngMDay	=	lngTotal;
	}
	oD.lngMYear	=	oD.lngMYear + 1841;
}
function	GetMaxDayOfMonth(lngYear, lngMonth)	{
	if((lngMonth == 1) || (lngMonth == 3) || (lngMonth == 5) || (lngMonth == 7)
			|| (lngMonth == 8) || (lngMonth == 10) || (lngMonth == 12))	{
		return(31);
	}
	else if((lngMonth == 4) || (lngMonth == 6) || (lngMonth == 9) || (lngMonth == 11))	{
		return(30);
	}
	else if(lngMonth == 2)	{
		if((lngYear % 400) == 0)	{
			return(29);
		}
		else if((lngYear % 100) == 0)	{
			return(28);
		}
		else if((lngYear % 4) == 0)	{
			return(29);
		}
		else {
			return(28);
		}
	}
	return(0);
}
function	div(p, q)	{
	return((p - (p % q)) / q);
}
function	GetTotalDays(lngYear, lngMonth, lngDay)	{
	var		n, cx;
	n	=	365 * (lngYear - 1);
	n	+=	div(lngYear - 1, 4);
	n	-=	div(lngYear - 1, 100);
	n	+=	div(lngYear - 1, 400);
	for(cx = 1;cx < lngMonth;cx++)	{
		n	+=	GetMaxDayOfMonth(lngYear, cx);
	}
	n	+=	lngDay;
	return(n);
}
function	DateAdd(oD, lngValue)	{
	if(lngValue < 0)	{
		while((oD.lngDay + lngValue) < 0)	{
			lngValue	+=	oD.lngDay;
			if(oD.lngMonth == 1)	{
				oD.lngYear--;
				oD.lngMonth	=	12;
				oD.lngDay	=	31;
			}
			else	{
				oD.lngMonth--;
				oD.lngDay	=	GetMaxDayOfMonth(oD.lngDay, oD.lngMonth);
			}
		}
		oD.lngDay	+=	lngValue;
	}
	else	{
		while((oD.lngDay + lngValue) > GetMaxDayOfMonth(oD.lngDay, oD.lngMonth))	{
			lngValue	-=	(GetMaxDayOfMonth(oD.lngDay, oD.lngMonth) - oD.lngDay);
			if(oD.lngMonth == 12)	{
				oD.lngYear++;
				oD.lngMonth	=	1
			}
			else	{
				oD.lngMonth++;
			}
			oD.lngDay	=	1;
			lngValue--;
		}
		oD.lngDay	+=	lngValue;
	}
	oD.lngDays	=	GetTotalDays(oD.lngYear, oD.lngMonth, oD.lngDay);
	SetMinusDate(oD);
}
function	IsAnniversary(oD, cx)	{
	var	oDay, lng;
	oDay	=	new ODay(oD.lngYear, oD.lngMonth, oD.lngDay);
	DateAdd(oDay, -gCalendarData.mAnniversary[cx].lngDelta);
	if(gCalendarData.mAnniversary[cx].blnSolar)	{	//	���
		if(gCalendarData.mAnniversary[cx].lngRType == 0)	{	//	�׳���
			if((gCalendarData.mAnniversary[cx].lngYear == oDay.lngYear)
				&& (gCalendarData.mAnniversary[cx].lngMonth == oDay.lngMonth)
				&& (gCalendarData.mAnniversary[cx].lngDay == oDay.lngDay))
				return(true);
		}
		else if(gCalendarData.mAnniversary[cx].lngRType == 1)	{	//	�ų�
			if((oDay.lngYear >= gCalendarData.mAnniversary[cx].lngYear)
				&& (((oDay.lngYear - gCalendarData.mAnniversary[cx].lngYear) % gCalendarData.mAnniversary[cx].lngRValue) == 0)
				&& (gCalendarData.mAnniversary[cx].lngMonth == oDay.lngMonth)
				&& (gCalendarData.mAnniversary[cx].lngDay == oDay.lngDay))	{
				return(true);
			}
			else	{
			}
		}
		else if(gCalendarData.mAnniversary[cx].lngRType == 2)	{	//	�ſ�
		}
		else if(gCalendarData.mAnniversary[cx].lngRType == 3)	{	//	����
		}
		else if(gCalendarData.mAnniversary[cx].lngRType == 4)	{	//	����
			lng	=	GetTotalDays(oDay.lngYear, oDay.lngMonth, oDay.lngDay)
						- GetTotalDays(gCalendarData.mAnniversary[cx].lngYear, gCalendarData.mAnniversary[cx].lngMonth, gCalendarData.mAnniversary[cx].lngDay);
			if((lng >= 0) && ((lng % gCalendarData.mAnniversary[cx].lngRValue) == 0))	{
				return(true);
			}
		}
		else	{
		}
	}
	else	{	//	����
		if(!oD.lngMFlag)	{	//	����
			if(gCalendarData.mAnniversary[cx].lngRType == 1)	{	//	�ų�
				if((gCalendarData.mAnniversary[cx].lngRValue == 1)
					&& (gCalendarData.mAnniversary[cx].lngMonth == oDay.lngMMonth)
					&& (gCalendarData.mAnniversary[cx].lngDay == oDay.lngMDay))	{
					return(true);
				}
				else	{
				}
			}
			else if(gCalendarData.mAnniversary[cx].lngRType == 2)	{
			}
			else	{
			}
		}
	}
	return(false);
}
function	SetAnniversary(oD)	{
	var	cx;
	for(cx = 0;cx < gCalendarData.mAnniversary.length;cx++)	{
		if(IsAnniversary(oD, cx))	{
			oD.oAnniversaries[oD.oAnniversaries.length]	=	cx;
		}
	}
}
function	ODay(lngYear, lngMonth, lngDay)	{
	this.lngYear	=	lngYear;
	this.lngMonth	=	lngMonth;
	this.lngDay		=	lngDay;
	this.lngDays	=	GetTotalDays(lngYear, lngMonth, lngDay);
	this.lngMYear	=	0;
	this.lngMMonth	=	0;
	this.lngMDay	=	0;
	this.lngMFlag	=	false;
	this.oAnniversaries	=	new Array();
	SetMinusDate(this);
}
function	OMonth(lngYear, lngMonth)	{
	var	cx;
	this.lngYear	=	lngYear;
	this.lngMonth	=	lngMonth;
	this.ODays		=	new Array();
	for(cx = 0;cx < GetMaxDayOfMonth(lngYear, lngMonth);cx++)	{
		this.ODays[cx]	=	new ODay(lngYear, lngMonth, cx + 1);
		SetAnniversary(this.ODays[cx]);
	}
}
function	DisplayCalendarHead(oMonth, strDIV, lngDisplay)	{
	var	cx, str, dtm;
	str	=	"";
	dtm	=	new Date();
	str	+=	gCalendarData.Language.TABLE[lngDisplay];
	str	+=	"<tr bgcolor=lavender>";
	str	+=	"<td align=left colspan=2>";
	str	+=	"<a href=\"javascript:";
	str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear - 10).toString() + ", " + oMonth.lngMonth.toString() + ", " + lngDisplay.toString() + ")");
	str	+=	"\">��</a>";
	str	+=	"<a href=\"javascript:";
	str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear - 1).toString() + ", " + oMonth.lngMonth.toString() + ", " + lngDisplay.toString() + ")");
	str	+=	"\">��</a>";
	str	+=	"<a href=\"javascript:";
	if(oMonth.lngMonth == 1)	{
		str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear - 1).toString() + ", 12, " + lngDisplay.toString() + ")");
	}
	else	{
		str	+=	("GetCalendar('" + strDIV + "', " + oMonth.lngYear.toString() + ", " + (oMonth.lngMonth - 1).toString() + ", " + lngDisplay.toString() + ")");
	}
	str	+=	"\">��</a></td>";
	str	+=	"<td align=center colspan=3><a href=\"javascript:";
	str	+=	("GetCalendar('" + strDIV + "', " + dtm.getFullYear().toString() + ", " + (dtm.getMonth() + 1).toString() + ", " + lngDisplay.toString() + ")");
	str	+=	"\">";
	str	+=	(gCalendarData.Language.DayFontSize[lngDisplay] + oMonth.lngYear.toString() + "�� " + oMonth.lngMonth.toString() + "��</font>");
	str	+=	"</a></td>";
	str	+=	"<td align=right colspan=2><a href=\"javascript:";
	if(oMonth.lngMonth == 12)	{
		str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear + 1).toString() + ", 1, " + lngDisplay.toString() + ")");
	}
	else	{
		str	+=	("GetCalendar('" + strDIV + "', " + oMonth.lngYear.toString() + ", " + (oMonth.lngMonth + 1).toString() + ", " + lngDisplay.toString() + ")");
	}
	str	+=	"\">��</a>";
	str	+=	"<a href=\"javascript:";
	str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear + 1).toString() + ", " + oMonth.lngMonth.toString() + ", " + lngDisplay.toString() + ")");
	str	+=	"\">��</a>";
	str	+=	"<a href=\"javascript:";
	str	+=	("GetCalendar('" + strDIV + "', " + (oMonth.lngYear + 10).toString() + ", " + oMonth.lngMonth.toString() + ", " + lngDisplay.toString() + ")");
	str	+=	"\">��</a>";
	str	+=	"</td>";
	str	+=	"</tr>";
	str	+=	"<tr bgcolor=lightpink>";
	str	+=	("<td width=14% align=center><font color=red><b>" + gCalendarData.Language.Weekday[lngDisplay][0] + "</b></font></td>");
	for(cx = 1;cx < 6;cx++)	{
		str	+=	("<td width=14% align=center><font color=black><b>" + gCalendarData.Language.Weekday[lngDisplay][cx] + "</b></font></td>");
	}
	str	+=	("<td width=14% align=center><font color=blue><b>" + gCalendarData.Language.Weekday[lngDisplay][6] + "</b></font></td>");
	str	+=	"</tr>";
	return(str);
}
function	GetDayString(oDay, strDIV, lngDisplay)	{
	var	cx, str, strAnniversary, strColor, dtm;
	str				=	"";
	strAnniversary	=	"";
	strColor		=	"black";
	dtm				=	new Date();
	if(lngDisplay != 2)			str	+=	"<td bgcolor=white align=right>";
	else if(dtm.getFullYear() == oDay.lngYear && (dtm.getMonth() + 1) == oDay.lngMonth && dtm.getDate() == oDay.lngDay)
		str	+=	"<td bgcolor=palegreen align=left valign=top>";
	else if((oDay.lngDays % 2) == 0)	str	+=	"<td bgcolor=lavender align=left valign=top>";
	else								str	+=	"<td bgcolor=white align=left valign=top>";
	if((oDay.lngDays % 7) == 6)	strColor	=	"blue";
	if((oDay.lngDays % 7) == 0)	strColor	=	"red";
	for(cx = 0;cx < oDay.oAnniversaries.length;cx++)	{
		if(gCalendarData.mAnniversary[oDay.oAnniversaries[cx]].lngCategory == 1)	{
			strAnniversary	+=	("<font color=red>" + gCalendarData.mAnniversary[oDay.oAnniversaries[cx]].strTitle + "</font><br>");
			strColor	=	"red";
		}
		else	{
			strAnniversary	+=	("<font color=indianred>" + gCalendarData.mAnniversary[oDay.oAnniversaries[cx]].strTitle + "</font><br>");
		}
	}
	str	+=	("<a href=\"javascript:evtDayClick(" + oDay.lngYear.toString() + ", " + oDay.lngMonth.toString() + ", " + oDay.lngDay.toString() + ")\">");
	str	+=	("<font color=" + strColor + ">");
	str	+=	gCalendarData.Language.DayFontSize[lngDisplay];
	str	+=	oDay.lngDay.toString();
	str	+=	"</font>";
	str	+=	"</font>";
	str	+=	"</a>";
	if(lngDisplay == 2)	{
		if((oDay.lngMDay % 5) == 1)	{
			str	+=	" <font color=gray>(";
			if(oDay.lngMFlag)	str	+=	"(��)";
			str	+=	(oDay.lngMMonth.toString() + "." + oDay.lngMDay.toString());
			str	+=	")</font>";
		}
		str	+=	"<br>";
		str	+=	strAnniversary;
	}
	str	+=	"</td>";
	return(str);
}
function	DisplayCalendarMain(oMonth, strDIV, lngDisplay)	{
	var	cx, cy, str, strTR, lngPreMonthMaxDay;
	str	=	"";
	cx	=	div(oMonth.ODays.length + oMonth.ODays[0].lngDays % 7 + 6, 7);
	if(lngDisplay == 2)	{
		strTR	=	"<tr height=" + div(92, cx).toString() + "% bgcolor=lavender>";
	}
	else	{
		strTR	=	"<tr bgcolor=lavender>";
	}
	if(oMonth.lngMonth == 1)	lngPreMonthMaxDay	=	GetMaxDayOfMonth(oMonth.lngYear - 1, 12);
	else						lngPreMonthMaxDay	=	GetMaxDayOfMonth(oMonth.lngYear, oMonth.lngMonth - 1);
	if(oMonth.ODays[0].lngDays % 7)	{
		str	+=	strTR;
		for(cx = lngPreMonthMaxDay - oMonth.ODays[0].lngDays % 7 + 1;cx <= lngPreMonthMaxDay;cx++)	{
			if(lngDisplay == 2)	str	+=	"<td align=left bgcolor=silver valign=top>";
			else				str	+=	"<td align=right bgcolor=white>";
			str	+=	"<font color=gray>";
			str	+=	gCalendarData.Language.DayFontSize[lngDisplay];
		 	str	+=	cx.toString();
			str	+=	"</font></font></td>";
		}
	}
	for(cx = 0;cx < oMonth.ODays.length;cx++)	{
		if((oMonth.ODays[cx].lngDays % 7) == 0)	{
			str	+=	strTR;
		}
		str	+=	GetDayString(oMonth.ODays[cx], strDIV, lngDisplay)
		if((oMonth.ODays[cx].lngDays % 7) == 6)	{
			str	+=	"</tr>";
		}
	}
	if((oMonth.ODays[oMonth.ODays.length - 1].lngDays % 7) != 6)	{
		for(cx = 1;cx < 7 - oMonth.ODays[oMonth.ODays.length - 1].lngDays % 7;cx++)	{
			if(lngDisplay == 2)	str	+=	"<td align=left bgcolor=silver valign=top>";
			else				str	+=	"<td align=right bgcolor=white>";
			str	+=	"<font color=gray>";
			str	+=	gCalendarData.Language.DayFontSize[lngDisplay];
			str	+=	cx.toString();
			str	+=	"</font></font></td>";
		}
		str	+=	"</tr>";
	}
	return(str);
}
function	DisplayCalendarFoot(oMonth, strDIV, lngDisplay)	{
	var	str;
	str	=	"";
	str	+=	"</table>";
	return(str);
}
function	GetCalendarString(strDIV, lngYear, lngMonth, lngDisplay)	{
	var	str, oMonth;
	oMonth	=	new OMonth(lngYear, lngMonth);
	str		=	"";
	str		+=	DisplayCalendarHead(oMonth, strDIV, lngDisplay);
	str		+=	DisplayCalendarMain(oMonth, strDIV, lngDisplay);
	str		+=	DisplayCalendarFoot(oMonth, strDIV, lngDisplay);
	return(str);
}
function	GetCalendarCommandString(strDIV, lngYear, lngMonth, lngDisplay)	{
	var	str;
	str	=	strDIV + ".innerHTML	=	GetCalendarString(\"" + strDIV + "\", " + lngYear.toString() + ", " + lngMonth.toString() + ", " + lngDisplay.toString() + ");";
	return(str);
}
function	GetCalendar(strDIV, lngYear, lngMonth, lngDisplay)	{
	eval(GetCalendarCommandString(strDIV, lngYear, lngMonth, lngDisplay));
}
function	evtDayClick(lngYear, lngMonth, lngDay)	{
	Test();
}
function	Test()	{
	var	cx, oDay, str = "", strHTML = "";
	var	rMid = 18.0, rMin = 18.0, rMax = 18.0;
	var	rMidTotal	=	0, lngCount	=	0;
	oDay	=	new ODay(1842, 1, 1);
	while(false)	{
		DateAdd(oDay, 1);
		str	=	str + "(+)" + oDay.lngYear + "-" + oDay.lngMonth + "-" + oDay.lngDay + " = ";
		str	=	str + "(-)" + oDay.lngMYear + "-" + oDay.lngMMonth + "-" + oDay.lngMDay + "\n";
//		str	=	str + rMin + " < " + rMid + " < " + rMax;
		if(oDay.lngMDay == 1)	{
			if(!confirm(str))	break;
			str	=	"";
		}
	}
//	return;
	str	=	"";
	while(oDay.lngYear < 2041)	{
		DateAdd(oDay, 28 - oDay.lngMDay);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		rMid	+=	(gCalendarData.mSynodicMonth - (oDay.lngDays + rMid) % gCalendarData.mSynodicMonth);
		if(rMid > gCalendarData.mSynodicMonth)	rMid	-=	gCalendarData.mSynodicMonth;
		strHTML	+=	("(-)" + oDay.lngMYear + "-" + oDay.lngMMonth + "-" + oDay.lngMDay + "," + rMid + "<br>");
		if(rMid > rMax)	rMax	=	(rMid + rMax) / 2;
		if(rMid < rMin)	rMin	=	(rMid + rMin) / 2;
		rMidTotal	+=	rMid;
		lngCount++;
		if(false && (oDay.lngYear % 10 == 0) && (oDay.lngMonth == 1))	{
			str	=	str + rMin + " ~ " + rMax + " : " + rMid;
			str	=	str + "(" + oDay.lngDays + ")";
			str	=	str + "(+)" + oDay.lngYear + "-" + oDay.lngMonth + "-" + oDay.lngDay + " = ";
			str	=	str + "(-)" + oDay.lngMYear + "-" + oDay.lngMMonth + "-" + oDay.lngMDay + " ";
			str	=	str + "\n";
			if(!confirm(str))
				break;
		}
	}
	rMin	=	rMidTotal / lngCount;
	oDay	=	new ODay(1842, 1, 1);
	str	=	"";
	while(oDay.lngYear < 2041)	{
		DateAdd(oDay, 28 - oDay.lngMDay);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		if(oDay.lngMDay != 1)	DateAdd(oDay, 1);
		rMid	=	((oDay.lngDays + rMin) % gCalendarData.mSynodicMonth);
		if(rMid > gCalendarData.mSynodicMonth)	rMid	-=	gCalendarData.mSynodicMonth;
		if(rMid > (gCalendarData.mSynodicMonth - 3))	rMid	-=	gCalendarData.mSynodicMonth;
		if(rMid > 1 || rMid < 0)	{
			str	=	str + "[" + rMin + " : " + rMid + "] ";
			str	=	str + "(+)" + oDay.lngYear + "-" + oDay.lngMonth + "-" + oDay.lngDay + " = ";
			str	=	str + "(-)" + oDay.lngMYear + "-" + oDay.lngMMonth + "-" + oDay.lngMDay + " ";
			str	=	str + "\n";
			if(!confirm(str))
				break;
		}
	}
	idTest.innerHTML	=	strHTML;
}
