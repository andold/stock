/**
 * node description:	memory.
 * 		value:	value
 * 		spare:	memory. spare memory for swap.
 * 		less:	less than next address value.
 * 		equal:	equal to next.
 * 		greater:	greater then next address value.
 * 		dirty:	this value changed. so this value not sorted. require processing.
 */
var	bubble	=	{
	bits:	4,	//	memory capacity. address bit count.
	index:	0,	//	currently insert memory point address.
	nodes:	[],	//	memory.
	values:	[],	//	value. input from out side.
	sorted:	true,	//	mark of all data sorted. only true when all dirty bits cleared.
	state:	0,	//	internal state. 0, 1, 2, 3, 0, 1, 2, 3, ...
	idle:	true,	//	all done. nothing to do.
	count:	0,	//	count of value.

	container:	"body",	//	view container.

	dummy:	null
};

bubble.initialize	=	function(bits, container)	{
	bubble.bits	=	bits;
	bubble.container	=	container;

	bubble.initializeGlobal();

	bubble.initializeNodes();
	bubble.initializeViewNodes();

	bubble.initializeValues();
	bubble.initializeViewValues();
};
bubble.initializeGlobal	=	function()	{
	bubble.index	=	0;

	var	html = "";
	html += "<div class='panel panel-default'>";
	html += "<div class='panel-heading text-center'>" + "global" + "</div>";
	html += "<div class='panel-body'>";

	html += "index: currently insert memory point address. count: count of value. state: internal state. 0, 1, 2, 3, 0, 1, 2, 3, ... sorted: mark of all data sorted. only true when all dirty bits cleared.<br>";

	html += "<div id='global-" + "index" + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "index" + "</div>";
	html += "<div class='panel-body'>";
	html += bubble.index;
	html += "</div>";
	html += "</div>";
	html += "<div id='global-" + "count" + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "count" + "</div>";
	html += "<div class='panel-body'>";
	html += bubble.count;
	html += "</div>";
	html += "</div>";
	html += "<div id='global-" + "state" + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "state" + "</div>";
	html += "<div class='panel-body'>";
	html += bubble.state;
	html += "</div>";
	html += "</div>";
	html += "<div id='global-" + "sorted" + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "sorted" + "</div>";
	html += "<div class='panel-body'>";
	html += bubble.sorted;
	html += "</div>";
	html += "</div>";

	html += "<div id='global-" + "error" + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "error" + "</div>";
	html += "<div class='panel-body'>";
	html += "nothing";
	html += "</div>";
	html += "</div>";

	html +=	"<button class='button' onclick='bubble.tick();'>clock</button>";

	html += "</div>";
	html += "</div>";
	jQuery(bubble.container).append(html);
};
bubble.createViewValue	=	function(address)	{
	var	html = "";
	html += "<div id='value-address-" + address + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "value: " + address + "</div>";
	html += "<div class='panel-body'>";
	html += "value: " + bubble.values[address];
	html += "</div>";
	html += "</div>";
	return html;
};
bubble.initializeViewValues	=	function()	{
	var	html = "";
	html += "<div class='panel panel-default'>";
	html += "<div class='panel-heading text-center'>" + "values" + "</div>";
	html += "<div class='panel-body'>";
	for (var cx = 0; cx < Math.pow(2, bubble.bits); cx++) {
		html += bubble.createViewValue(cx);
	}
	html += "</div>";
	html += "</div>";
	jQuery(bubble.container).append(html);
};
bubble.initializeValues	=	function()	{
	bubble.values	=	[];
	for (var cx = 0; cx < Math.pow(2, bubble.bits); cx++) {
		bubble.values.push(Math.floor(Math.random() * 128));
	}
	bubble.count	=	Math.pow(2, bubble.bits);
};
bubble.createViewNode	=	function(address)	{
	var	html = "";
	html += "<div id='node-address-" + address + "' class='panel panel-default pull-left'>";
	html += "<div class='panel-heading text-center'>" + "node: " + address + "</div>";
	html += "<div class='panel-body'>";
	for (var key in bubble.nodes[address]) {
		html += key + ": " + bubble.nodes[address][key] + "<br>";
	}
	html += "</div>";
	html += "</div>";
	return html;
};
bubble.initializeViewNodes	=	function()	{
	var	html = "";
	html += "<div class='panel panel-default'>";
	html += "<div class='panel-heading text-center'>" + "Nodes" + "</div>";
	html += "<div class='panel-body'>";
	for (var cx = 0; cx < Math.pow(2, bubble.bits); cx++) {
		html += bubble.createViewNode(cx);
	}
	html += "</div>";
	html += "</div>";
	jQuery(bubble.container).append(html);
};
bubble.initializeNodes	=	function()	{
	bubble.nodes	=	[];
	for (var cx = 0; cx < Math.pow(2, bubble.bits); cx++) {
		bubble.nodes.push({
			value: 0,
			spare: 0,
			less: false,
			equal: false,
			greater: false,
			dirty: false
		});
	}
};
bubble.error	=	function(message)	{
	jQuery("#global-error div.panel-body").text(message);
	jQuery("#global-error").css("background-color", "#8080FF");
	console.log(message);
	throw new Error(message);
}
bubble.tick	=	function()	{
	if (bubble.state == 0) {
		bubble.error("error: undefined case in state 0.");
		bubble.state = 1;
	} else {
		bubble.error("error: undefined case in state not 0.");
	}
}