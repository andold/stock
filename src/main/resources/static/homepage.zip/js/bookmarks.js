/**
 * @author andold
 * @since 2017-05-02
 */
var bookmarks = {
	"title": "잡다한 인연들",
	"type": "root",
	"children": []
};
bookmarks["children"].push({
	"title": "current: 2019-01",
	"children": [{
		"title": "favorite➊",
		"children": [{
			"title": "ncs email",
			"url": "http://mail.navercorp.com/"
		}, {
			"title": "naver",
			"url": "http://www.naver.com/"
		}, {
			"title": "google",
			"url": "https://www.google.co.kr/"
		}, {
			"title": "wiki",
			"url": "https://wiki.navercorp.com/pages/viewpage.action?pageId=288584885"
		}, {
			"title": "사내정보",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=338613222"
		}, {
			"title": "todo",
			"url": "https://oss.navercorp.com/kwaheon-kwon/andold-utility#boards?repos=18506,59854,26189,26188,18527,16140,53997"
		}]
	}, {
		"title": "favorite➋",
		"children": [{
			"title": "PaaSDev3",
			"url": "https://oss.navercorp.com/PaaSDev3/weeklyreport/issues"
		}, {
			"title": "warning",
			"url": "http://patch.navercorp.com/issue/128"
		}, {
			"title": "oss",
			"url": "https://oss.navercorp.com/"
		}, {
			"title": "pasta",
			"url": "https://pasta.navercorp.com/"
		}]
	}, {
		"title": "favorite➌",
		"children": [{
			"title": "ntree",
			"url": "http://ntree.navercorp.com/"
		}, {
			"title": "share",
			"url": "https://share.navercorp.com/"
		}, {
			"title": "Ⓜ",
			"url": "https://connect.navercorp.com/board/viewByArea/4/1337795?page=1"
		}]
	}, {
		"title": "ssf",
		"children": [{
			"title": "bts",
			"url": "http://bts4.navercorp.com/nhnbts/projects/SSF/issues/SSF-122?filter=allopenissues"
		}, {
			"title": "oss",
			"url": "https://oss.navercorp.com/ssf"
		}, {
			"title": "wiki",
			"url": "https://wiki.navercorp.com/display/~nb10301/SSF"
		}, {
			"title": "my wiki",
			"url": "https://wiki.navercorp.com/pages/viewpage.action?pageId=399870754"
		}, {
			"title": "pasta",
			"url": "https://ssf.pasta.navercorp.com/ndeploy/v2/workspaces/2624/scenarios/2131209"
		}, {
			"title": "test-spring",
			"url": "http://localhost:8080/ssf-web/developer/"
		}, {
			"title": "alpha",
			"url": "http://alpha-intostatic.navercorp.com/ssf-web/developer/"
		}, {
			"title": "iims",
			"url": "http://iims.navercorp.com/"
		}]
	}, {
		"title": "idcassign",
		"children": [{
			"title": "github",
			"url": "https://oss.navercorp.com/idcassign/"
		}, {
			"title": "wiki",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=335472717"
		}, {
			"title": "bts",
			"url": "http://bts4.navercorp.com/nhnbts/issues/?filter=88699"
		}, {
			"title": "pasta",
			"url": "https://andold.pasta.navercorp.com/ndeploy/v2/workspaces/847/scenarios/843130"
		}, {
			"title": "local",
			"url": "http://localhost:8081/idcassign/v3/"
		}, {
			"title": "dev",
			"url": "http://dev.ntree2.navercorp.com/idcassign/v3/"
		}, {
			"title": "real",
			"url": "http://ntree2.navercorp.com/idcassign/v3/"
		}, {
			"title": "dev.ntree2",
			"url": "http://dev.ntree2.navercorp.com/"
		}, {
			"title": "beta.ntree",
			"url": "http://beta.ntree2.navercorp.com/"
		}, {
			"title": "ntree",
			"url": "http://ntree.navercorp.com/"
		}]
	}, {
		"title": "storage",
		"children": [{
			"title": "wiki",
			"url": "http://wiki.navercorp.com/display/~nb10545/Object+Storage%2C+Archive+Storage"
		}]
	}]
});
bookmarks["children"].push({
	"title": "current: 2018-10",
	"children": [{
		"title": "ncp",
		"url": "https://www.ncloud.com/",
		"children": [{
			"title": "ncloud",
			"url": "https://www.ncloud.com/",
		}, {
			"title": "console",
			"url": "https://console.ncloud.com/",
		}, {
			"title": "github-ncp",
			"url": "https://github.com/NaverCloudPlatform"
		}]
	}, {
		"title": "ndms",
		"url": "http://ndms.navercorp.com/ndms/",
		"children": [{
			"title": "oss",
			"url": "https://oss.navercorp.com/CDNTech/ndms"
		}, {
			"title": "wiki",
			"url": "https://wiki.navercorp.com/display/~nb10271/NDMS+-+Naver+Dns+Management+System"
		}, {
			"title": "jenkins",
			"url": "http://batch.backup.navercorp.com:8080/jenkins/job/NDMS_WEB_ND/"
		}, {
			"title": "pasta",
			"url": "https://ndms.pasta.navercorp.com/ndeploy/v2/workspaces/1163/scenarios/691386"
		}, {
			"title": "release",
			"url": "http://ndms.navercorp.com/ndms/"
		}]
	}, {
		"title": "intel",
		"children": [{
			"title": "oss",
			"url": "https://oss.navercorp.com/kwaheon-kwon/intel-nsight"
		}, {
			"title": "issue",
			"url": "https://oss.navercorp.com/kwaheon-kwon/intel-nsight#boards?repos=53997"
		}, {
			"title": "wiki",
			"url": "https://wiki.navercorp.com/pages/viewpage.action?pageId=400376386"
		}, {
			"title": "test",
			"url": "http://localhost:8086/intel-nsight/"
		}, {
			"title": "h2",
			"url": "http://localhost:8086/intel-nsight/h2"
		}, {
			"title": "local",
			"url": "http://localhost/intel-nsight/"
		}, {
			"title": "jenkins",
			"url": "https://jenkins.navercorp.com/andold-public/"
		}, {
			"title": "pasta",
			"url": "https://andold-public.pasta.navercorp.com/ndeploy/v2/workspaces/3679/scenarios/1926317"
		}, {
			"title": "dev",
			"url": "http://10.105.187.99/intel-nsight/"
		}, {
			"title": "beta",
			"url": "http://10.250.36.86/intel-nsight/"
		}, {
			"title": "prod",
			"url": "http://10.250.24.234/intel-nsight/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "2018-07",
	"children": [{
		"title": "nes➊",
		"children": [{
			"title": "oss",
			"url": "https://oss.navercorp.com/ncloud-saas"
		}, {
			"title": "dashboard",
			"url": "https://oss.navercorp.com/ncloud-saas/ncp-email-doc#boards?repos=41426,43020,42020,42882,42017,44449,44373"
		}, {
			"title": "bts",
			"url": "http://bts3.navercorp.com/nhnbts/issues/?filter=1000119602"
		}, {
			"title": "cdncp",
			"url": "https://oss.navercorp.com/cdncp/email-service-web#boards"
		}, {
			"title": "pasta",
			"url": "https://ncp-email.pasta.navercorp.com/ndeploy/v2/workspaces/3245/scenarios?sort=stage"
		}, {
			"title": "my issue",
			"url": "https://oss.navercorp.com/issues/assigned"
		}, {
			"title": "nsight",
			"url": "http://10.106.226.126/nes/"
		}]
	}, {
		"title": "nes➋",
		"children": [{
			"title": "guide",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=353478525"
		}, {
			"title": "dev-iims",
			"url": "http://dev-iims2.navercorp.com/adminPM/Main.nhn"
		}, {
			"title": "dev",
			"url": "https://dev-console.ncloud.com/emailSVR/"
		}, {
			"title": "beta",
			"url": "https://beta-console.ncloud.com/emailSVR/"
		}, {
			"title": "spf",
			"url": "https://mxtoolbox.com/SuperTool.aspx?action=spf%3aclound.com&run=toolpage"
		}]
	}, {
		"title": "nes-jenkins",
		"children": [{
			"title": "dev1",
			"url": "http://dev-email.batch.ncloud.com/1/jenkins/"
		}, {
			"title": "dev2",
			"url": "http://dev-email.batch.ncloud.com/2/jenkins/"
		}, {
			"title": "beta1",
			"url": "http://beta-email.batch.ncloud.com/1/jenkins/"
		}, {
			"title": "beta2",
			"url": "http://beta-email.batch.ncloud.com/2/jenkins/"
		}, {
			"title": "real1",
			"url": "http://email.batch.ncloud.com/1/jenkins/"
		}, {
			"title": "real2",
			"url": "http://email.batch.ncloud.com/2/jenkins/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "2018-05",
	"children": [{
		"title": "commerce",
		"children": [{
			"title": "wiki",
			"url": "http://wiki.navercorp.com/display/~nb10545/Prov+2.0"
		}, {
			"title": "google",
			"url": "https://console.cloud.google.com/"
		}, {
			"title": "amazon",
			"url": "https://aws.amazon.com/ko/"
		}]
	}, {
		"title": "rtbh",
		"children": [{
			"title": "WIKI",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=363038685"
		}, {
			"title": "bts",
			"url": "http://bts4.navercorp.com/nhnbts/browse/RTBH/"
		}, {
			"title": "ipbay",
			"url": "http://ipbay.navercorp.com/blocker.php"
		}, {
			"title": "wiki",
			"url": "http://wiki.navercorp.com/display/~nb10108/IPBay+API+Spec"
		}, {
			"title": "git",
			"url": "https://oss.navercorp.com/RTBH"
		}, {
			"title": "pasta",
			"url": "https://andold.pasta.navercorp.com/ndeploy/v2/workspaces/847/scenarios/1324155"
		}, {
			"title": "local",
			"url": "http://localhost:8082/"
		}, {
			"title": "dev",
			"url": "http://10.113.114.243/"
		}, {
			"title": "web1",
			"url": "http://10.106.141.238:5555/"
		}, {
			"title": "web2",
			"url": "http://10.105.174.236:5555/"
		}, {
			"title": "api1",
			"url": "http://10.106.141.238:5555/api/v1/"
		}, {
			"title": "api2",
			"url": "http://10.105.174.236:5555/api/v1/"
		}]
	}, {
		"title": "ntree2",
		"children": [{
			"title": "github",
			"url": "https://oss.navercorp.com/NTree2/NTree2-Web"
		}, {
			"title": "wiki",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=315770634"
		}, {
			"title": "dev.web",
			"url": "http://dev.ntree2.navercorp.com/"
		}, {
			"title": "ntree",
			"url": "http://ntree.navercorp.com/"
		}, {
			"title": "old",
			"url": "http://old.ntree.navercorp.com/"
		}]
	}, {
		"title": "etc",
		"children": [{
			"title": "ITONetBill",
			"url": "https://oss.navercorp.com/ITONetBill"
		}, {
			"title": "infraeve-github",
			"url": "https://oss.navercorp.com/andold-infraeve/infraeve-hbase"
		}]
	}]
});
bookmarks["children"].push({
	"title": "NMS2",
	"children": [{
		"title": "Portal",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "wiki",
			"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218"
		}, {
			"title": "yobi",
			"url": "http://yobi.navercorp.com/organizations/NMS"
		}, {
			"title": "github",
			"url": "https://oss.navercorp.com/NMS"
		}, {
			"title": "pasta",
			"url": "https://nms.pasta.navercorp.com/ndeploy/"
		}, {
			"title": "ndeploy",
			"url": "http://ndeploy.navercorp.com/"
		}, {
			"title": "bts",
			"url": "http://bts4.navercorp.com/nhnbts/issues/?filter=83204"
		}, {
			"title": "nelo",
			"url": "http://nelo2.navercorp.com/"
		}, {
			"title": "nsight",
			"url": "http://localhost/nsight/index.html"
		}, {
			"title": "npot",
			"url": "http://npot.navercorp.com/"
		}]
	}, {
		"title": "dev",
		"url": "http://nms.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://dev.nms2.navercorp.com/"
		}, {
			"title": "tm",
			"url": "http://10.113.182.89:9001/topology/meta/"
		}, {
			"title": "batch/ci",
			"url": "http://ci.nms.navercorp.com/jenkins/"
		}, {
			"title": "cloudera",
			"url": "http://10.105.170.206:7180/"	//	since 2018-01-11
				
		}]
	}, {
		"title": "real",
		"url": "http://nms2.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://nms2.navercorp.com/"
		}, {
			"title": "awstats",
			"url": "http://nms2.navercorp.com/awstats/awstats.nms2.html"
		}, {
			"title": "batch1",
			"url": "http://batch1.nms2.navercorp.com/"
		}, {
			"title": "1-tm",
			"url": "http://batch1.nms2.navercorp.com/topology/meta/"
		}, {
			"title": "batch2",
			"url": "http://batch2.nms2.navercorp.com/"
		}, {
			"title": "2-tm",
			"url": "http://batch2.nms2.navercorp.com/topology/meta/"
		}, {
			"title": "cloudera",
			"url": "http://10.114.37.41:7180/"
		}]
	}, {
		"title": "line",
		"url": "http://nms2.linecorp.com/",
		"children": [{
			"title": "web",
			"url": "http://nms2.linecorp.com/"
		}, {
			"title": "awstats",
			"url": "http://nms2.linecorp.com/awstats/awstats.nms2.html"
		}, {
			"title": "batch1",
			"url": "http://batch1.nms2.linecorp.com/"
		}, {
			"title": "1-tm",
			"url": "http://batch1.nms2.linecorp.com/topology/meta/"
		}, {
			"title": "batch2",
			"url": "http://batch2.nms2.linecorp.com/"
		}, {
			"title": "2-tm",
			"url": "http://batch2.nms2.linecorp.com/topology/meta/"
		}, {
			"title": "cloudera",
			"url": "http://10.128.134.213:7180/"
		}]
	}, {
		"title": "consumer",
		"children": [{
			"title": "pasta",
			"url": "https://nms.pasta.navercorp.com/ndeploy/v2/workspaces/837/scenarios/42807"
		}, {
			"title": "oss",
			"url": "https://oss.navercorp.com/NMS/consumer"
		}]
	}]
});
bookmarks["children"].push({
	"title": "API Reference",
	"children": [{
		"title": "javascript",
		"url": "https://developer.mozilla.org/en/JavaScript/Reference",
		"children": [{
			"title": "javascript",
			"url": "https://developer.mozilla.org/en/JavaScript/Reference"
		}, {
			"title": "jQuery",
			"url": "http://api.jquery.com/"
		}, {
			"title": "koxo",
			"url": "http://koxo.com/"
		}]
	}, {
		"title": "HTML",
		"children": [{
			"title": "thymeleaf2",
			"url": "http://www.thymeleaf.org/doc/tutorials/2.1/usingthymeleaf.html"
		}, {
			"title": "bootstrap",
			"url": "https://getbootstrap.com/"
		}, {
			"title": "iconic",
			"url": "https://useiconic.com/open/"
		}]
	}, {
		"title": "JAVA",
		"url": "http://docs.oracle.com/javase/8/docs/api/",
		"children": [{
			"title": "Java 6",
			"url": "http://docs.oracle.com/javase/6/docs/api/"
		}, {
			"title": "Java 7",
			"url": "http://docs.oracle.com/javase/7/docs/api/"
		}, {
			"title": "Java 8",
			"url": "http://docs.oracle.com/javase/8/docs/api/",
		}, {
			"title": "formatter",
			"url": "http://docs.oracle.com/javase/7/docs/api/java/util/Formatter.html"
		}, {
			"title": "Spring",
			"url": "http://static.springsource.org/spring/docs/3.2.x/javadoc-api/"
		}, {
			"title": "JDOM",
			"type": "site",
			"url": "http://www.jdom.org/docs/apidocs/"
		}, {
			"title": "POI",
			"url": "http://poi.apache.org/apidocs/"
		}]
	}, {
		"title": "NMS",
		"url": "http://wiki.navercorp.com/pages/viewpage.action?pageId=269628218",
		"children": [{
			"title": "hbase",
			"url": "https://hbase.apache.org/apidocs/"
		}, {
			"title": "hadoop",
			"url": "http://hadoop.apache.org/docs/stable/api/"
		}, {
			"title": "asynchbase",
			"url": "http://tsunanet.net/~tsuna/asynchbase/api/index.html?org/hbase/async/HBaseClient.html"
		}, {
			"title": "antlr",
			"url": "http://www.antlr.org/api/Java/index.html"
		}]
	}, {
		"title": "mongodb API",
		"url": "http://api.mongodb.org/java/current/",
		"children": [{
			"title": "org",
			"url": "http://api.mongodb.org/java/current/"
		}, {
			"title": "spring",
			"url": "http://static.springsource.org/spring-data/data-mongodb/docs/current/api/"
		}]
	}, {
		"title": "etc",
		"children": [{
			"title": "SVG",
			"url": "http://www.w3.org/TR/SVG/"
		}, {
			"title": "ipbay",
			"url": "http://wiki.navercorp.com/display/~nb10108/IPBay+API+Spec"
		}, {
			"title": "maven",
			"url": "http://search.maven.org/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "localhost",
	"children": [{
		"title": "relative",
		"children": [{
			"title": "2017년 3월 28일 백업",
			"url": "/Memo/20170328.html"
		}, {
			"title": "나의 달력",
			"url": "/Calendar/MyCalendar.html"
		}, {
			"title": "Suvival",
			"url": "/Column/20110307.html"
		}, {
			"title": "nsight",
			"url": "/nsight/index.html"
		}]
	}, {
		"title": "local",
		"url": "http://localhost/links.html",
		"children": [{
			"title": "html",
			"url": "http://localhost/links.html"
		}, {
			"title": "household",
			"url": "http://localhost/household/"
		}, {
			"title": "jenkins",
			"url": "http://localhost/jenkins/"
		}, {
			"title": "nsight",
			"url": "http://localhost/nsight/index.html"
		}]
	}, {
		"title": "home",
		"children": [{
			"title": "github",
			"url": "https://github.com/andold/home"
		}, {
			"title": "oss",
			"url": "https://oss.navercorp.com/kwaheon-kwon/andold-home"
		}, {
			"title": "pasta",
			"url": "https://andold.pasta.navercorp.com/ndeploy/v2/workspaces/847/scenarios/1187296"
		}, {
			"title": "jenkins",
			"url": "https://jenkins.navercorp.com/andold-banana/"
		}, {
			"title": "test",
			"url": "http://localhost:8084"
		}, {
			"title": "local",
			"url": "http://localhost/"
		}, {
			"title": "ich",
			"url": "http://ich.andold.kr/"
		}, {
			"title": "ip",
			"url": "http://10.113.255.175/"
		}]
	}, {
		"title": "household",
		"children": [{
			"title": "github",
			"url": "https://github.com/andold/household"
		}, {
			"title": "oss",
			"url": "https://oss.navercorp.com/kwaheon-kwon/andold-household"
		}, {
			"title": "pasta",
			"url": "https://andold.pasta.navercorp.com/ndeploy/v2/workspaces/847/scenarios/1386204"
		}, {
			"title": "test",
			"url": "http://localhost:8080/household/"
		}, {
			"title": "local",
			"url": "http://localhost/household/"
		}, {
			"title": "ich",
			"url": "http://ich.andold.kr/household/"
		}, {
			"title": "ip",
			"url": "http://10.113.255.175/household/"
		}]
	}, {
		"title": "ich",
		"children": [{
			"title": "html",
			"url": "http://ich.andold.kr/links.html"
		}, {
			"title": "nsight",
			"url": "http://ich.andold.kr/nsight/index.html"
		}, {
			"title": "ip",
			"url": "http://10.113.255.175/links.html",
		}]
	}]
});
bookmarks["children"].push({
	"title": "금융♤",
	"children": [{
		"title": "은행권",
		"children": [{
			"title": "신한",
			"url": "http://www.shinhan.com/"
		}, {
			"title": "KEB하나",
			"url": "https://www.kebhana.com/"
		}, {
			"title": "국민",
			"url": "http://www.kbstar.com/"
		}, {
			"title": "기업",
			"url": "http://www.ibk.co.kr/"
		}, {
			"title": "산업",
			"url": "https://www.kdb.co.kr/"
		}, {
			"title": "농협",
			"url": "http://banking.nonghyup.com/"
		}]
	}, {
		"title": "신용카드",
		"children": [{
			"title": "현대",
			"url": "http://www.hyundaicard.com/"
		}, {
			"title": "신한",
			"url": "https://www.shinhancard.com/"
		}, {
			"title": "하나",
			"url": "https://www.kebhana.com/card/index.do"
		}]
	}, {
		"title": "증권 기타",
		"children": [{
			"title": "한국투자",
			"url": "http://www.truefriend.com/"
		}, {
			"title": "삼성생명",
			"url": "http://www.samsunglife.com/"
		}]
	}, {
		"title": "금융 통계",
		"children": [{
			"title": "국가통계포털",
			"url": "http://kosis.kr/"
		}, {
			"title": "한국은행",
			"url": "http://ecos.bok.or.kr/"
		}]
	}, {
		"title": "금융 기관",
		"children": [{
			"title": "위택스",
			"url": "https://www.wetax.go.kr/"
		}, {
			"title": "홈텍스",
			"url": "http://www.hometax.go.kr/"
		}, {
			"title": "지로",
			"url": "http://www.giro.or.kr/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "API Reference 2/2",
	"children": [{
		"title": "js 2d",
		"type": "site",
		"children": [{
			"title": "Raphael",
			"url": "http://raphaeljs.com/"
		}]
	}, {
		"title": "js 3d",
		"type": "site",
		"children": [{
			"title": "three.js",
			"url": "http://threejs.org/examples/"
		}, {
			"title": "three.js",
			"url": "https://stemkoski.github.io/Three.js/"
		}, {
			"title": "pre3d",
			"url": "http://ich.deanmcnamee.com/pre3d/"
		}, {
			"title": "d3js",
			"url": "http://d3js.org/"
		}, {
			"title": "babylonjs",
			"url": "http://www.babylonjs.com/"
		}]
	}, {
		"title": "js chart",
		"children": [{
			"title": "RGraph",
			"url": "http://www.rgraph.net/"
		}, {
			"title": "Highcharts",
			"url": "http://www.highcharts.com/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}, {
			"title": "Awesome",
			"url": "http://cyberpython.github.com/AwesomeChartJS/"
		}, {
			"title": "ZingC",
			"url": "http://www.zingchart.com/"
		}]
	}, {
		"title": "webGL",
		"children": [{
			"title": "home",
			"url": "https://www.khronos.org/webgl/"
		}, {
			"title": "wikipedia",
			"url": "https://ko.wikipedia.org/wiki/WebGL"
		}, {
			"title": "Tutorial",
			"url": "https://developer.mozilla.org/ko/docs/Web/API/WebGL_API/Tutorial/Getting_started_with_WebGL"
		}, {
			"title": "demo",
			"url": "https://www.chromeexperiments.com/webgl"
		}, {
			"title": "demo",
			"url": "https://developer.mozilla.org/ko/demos/tag/tech%3Awebgl"
		}]
	}]
});
bookmarks["children"].push({
	"title": "단골 ♤",
	"type": "section",
	"children": [{
		"title": "private",
		"children": [{
			"title": "[메일] 한메일",
			"url": "http://www.daum.net/"
		}, {
			"title": "공동육아",
			"url": "http://www.gongdong.or.kr/"
		}, {
			"title": "김대성",
			"url": "http://www.aeris.net/"
		}, {
			"title": "SKT",
			"url": "http://www.tworld.co.kr/"
		}]
	}, {
		"title": "포털",
		"children": [{
			"title": "[지도] 네이버",
			"url": "http://map.naver.com/"
		}, {
			"title": "다음",
			"url": "http://www.daum.net/"
		}, {
			"title": "구글",
			"url": "http://www.google.co.kr/"
		}, {
			"title": "네이버",
			"url": "http://www.naver.com"
		}]
	}, {
		"title": "위키백과",
		"url": "http://ko.wikipedia.org/"
	}, {
		"title": "후이즈 검색",
		"url": "http://whois.nida.or.kr/"
	}]
});
bookmarks["children"].push({
	"title": "가게 ♡",
	"children": [{
		"title": "쇼핑",
		"url": "http://www.auction.co.kr/",
		"children": [{
			"title": "지마켓",
			"url": "http://www.gmarket.co.kr/"
		}, {
			"title": "11번가",
			"url": "http://www.11st.co.kr/"
		}, {
			"title": "옥션",
			"url": "http://www.auction.co.kr/"
		}, {
			"title": "YES24",
			"url": "http://www.yes24.com/"
		}]
	}, {
		"title": "목재",
		"children": [{
			"title": "철천지",
			"url": "http://www.77g.com/"
		}, {
			"title": "대신특수목재",
			"url": "http://www.wood21.co.kr/"
		}, {
			"title": "이목손",
			"url": "http://imokson.com/"
		}]
	}, {
		"title": "재미",
		"children": [{
			"title": "netflix",
			"url": "https://www.netflix.com/kr/"
		}, {
			"title": "재미월드",
			"url": "http://www.zemiworld.com/"
		}, {
			"title": "dos 게임",
			"url": "https://archive.org/details/softwarelibrary_msdos_games"
		}]
	}, {
		"title": "비교",
		"url": "http://www.enuri.com/",
		"children": [{
			"title": "에누리",
			"url": "http://www.enuri.com/"
		}, {
			"title": "다나와",
			"url": "http://www.danawa.com/",
		}]
	}]
});
bookmarks["children"].push({
	"title": "문화",
	"type": "section",
	"children": [{
		"title": "물생활",
		"children": [{
			"title": "담뽀뽀",
			"type": "site",
			"url": "http://www.dampopo.com/"
		}, {
			"title": "ampet",
			"type": "site",
			"url": "http://www.ampet.co.kr/"
		}, {
			"title": "trofish",
			"type": "site",
			"url": "http://www.trofish.net/"
		}, {
			"title": "물의나라",
			"type": "site",
			"url": "http://www.fishworld114.com/"
		}, {
			"title": "피알피쉬",
			"type": "site",
			"url": "http://www.prfish.com/"
		}]
	}, {
		"title": "재미",
		"children": [{
			"title": "딸랑이",
			"url": "https://ooyaggo.blogspot.kr/"	//	2016-12-07
		}, {
			"title": "블랙홀",
			"url": "http://m304050.blogspot.com/"
		}, {
			"title": "전파의 종류",
			"url": "http://blog.naver.com/kilseok2?Redirect=Log&logNo=50019526239"
		}, {
			"title": "TED",
			"url": "http://www.ted.com/"
		}]
	}, {
		"title": "참여",
		"children": [{
			"title": "정의당",
			"url": "http://www.justice21.org/"
		}, {
			"title": "정치후원금",
			"url": "http://www.give.go.kr/"
		}, {
			"title": "경향",
			"url": "http://www.khan.co.kr/"
		}, {
			"title": "한겨레",
			"url": "http://www.hani.co.kr/"
		}, {
			"title": "오마이뉴스",
			"url": "http://www.ohmynews.com/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "개발♤",
	"children": [{
		"title": "개발♤",
		"children": [{
			"title": "데브피아",
			"url": "http://www.devpia.com/"
		}, {
			"title": "마이크로소프트",
			"url": "http://www.microsoft.com/"
		}]
	}, {
		"title": "개발♤",
		"children": [{
			"title": "요타3",
			"url": "https://forum.xda-developers.com/yotaphone-3/development"
		}, {
			"title": "요타",
			"url": "https://forum.xda-developers.com/yotaphone-one"
		}]
	}, {
		"title": "HBase",
		"children": [{
			"title": "jira",
			"url": "https://issues.apache.org/jira/browse/HBASE/"
		}, {
			"title": "API",
			"url": "https://hbase.apache.org/apidocs/"
		}, {
			"title": "async",
			"url": "http://tsunanet.net/~tsuna/asynchbase/api/"
		}, {
			"title": "Home",
			"url": "https://hbase.apache.org/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "교육",
	"children": [{
		"title": "학교",
		"children": [{
			"title": "보평고",
			"url": "http://bopyung.hs.kr/"
		}, {
			"title": "운중중학교",
			"url": "http://www.unjung.ms.kr/"
		}]
	}, {
		"title": "기관",
		"children": [{
			"title": "판교도서관",
			"url": "http://pg.snlib.net/"
		}, {
			"title": "판교청소년수련관",
			"url": "http://www.pgyouth.or.kr/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "Naver Corp.",
	"children": [{
		"title": "포털",
		"children": [{
			"title": "사내 및 IDC 필수 설치 프로그램",
			"url": "http://vaccine.navercorp.com/"
		}, {
			"title": "a2d",
			"url": "http://a2d.navercorp.com/"
		}]
	}, {
		"title": "보안접속",
		"url": "http://insec.navercorp.com/",
		"children": [{
			"title": "nsa",
			"url": "https://nsasupport.navercorp.com/"
		}, {
			"title": "insec",
			"url": "http://insec.navercorp.com/"
		}, {
			"title": "neosec",
			"url": "https://neosec.navercorp.com/"
		}]
	}, {
		"title": "isac",
		"url": "http://isac.navercorp.com/",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/"
		}, {
			"title": "bts",
			"url": "http://bts.navercorp.com/nhnbts/browse/ISAC"
		}, {
			"title": "moss",
			"url": "http://moss.navercorp.com/sites/spd/InfraSolDev/IMSOperTeam/ISAC/"
		}, {
			"title": "ci",
			"url": "http://dev.isac.navercorp.com/jenkins/"
		}, {
			"title": "bds",
			"url": "http://iims2.navercorp.com/"
		}]
	}, {
		"title": "isac.awstats",
		"url": "http://isac.navercorp.com/awstats/awstats.isac.html",
		"children": [{
			"title": "운영",
			"url": "http://isac.navercorp.com/awstats/awstats.isac.html"
		}, {
			"title": "개발",
			"url": "http://dev.isac.navercorp.com/awstats/awstats.isac.html"
		}]
	}, {
	}]
});
bookmarks["children"].push({
	"title": "NBP Portal",
	"type": "section",
	"children": [{
		"title": "favorite➊",
		"children": [{
			"title": "nsight",
			"url": "http://nsight.navercorp.com/"
		}, {
			"title": "nsight-line",
			"url": "http://nsight.linecorp.com/"
		}, {
			"title": "ntree",
			"url": "http://ntree.navercorp.com/"
		}, {
			"title": "ncloud-internal",
			"url": "http://ncloud.navercorp.com/"
		}]
	}, {
		"title": "favorite➋",
		"children": [{
			"title": "nms",
			"url": "http://nms.navercorp.com/"
		}, {
			"title": "mactrack",
			"url": "http://mactrack.nms.navercorp.com/nms/"
		}, {
			"title": "tts",
			"url": "http://tts.navercorp.com/"
		}, {
			"title": "idms",
			"url": "http://idms.navercorp.com/"
		}, {
			"title": "esm",
			"url": "http://esm.navercorp.com/"
		}, {
			"title": "dbip",
			"url": "http://dbip2.navercorp.com/"
		}]
	}, {
		"title": "IIMS2",
		"url": "http://iims2.navercorp.com/",
		"children": [{
			"title": "dev",
			"url": "http://dev-iims2.navercorp.com/"
		}, {
			"title": "alpha",
			"url": "http://alpha-iims2.navercorp.com/"
		}, {
			"title": "beta",
			"url": "http://beta-iims2.navercorp.com/"
		}, {
			"title": "real",
			"url": "http://iims2.navercorp.com/"
		}, {
			"title": "dev2.deprecated",
			"url": "http://dev2-iims2.navercorp.com/"
		}]
	}, {
		"title": "etc",
		"children": [{
			"title": "Naver Developer Center",
			"url": "https://developers.naver.com/"
		}, {
			"title": "데브카페",
			"url": "http://devcafe.navercorp.com/"
		}, {
			"title": "bts",
			"url": "http://bts4.navercorp.com/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "랩(Lab.)♡",
	"children": [{
		"title": "gssm-real",
		"url": "http://gssm-web.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://gssm-web.navercorp.com/"
		}, {
			"title": "batch",
			"url": "http://gssm-web.navercorp.com/gomez/batch/"
		}, {
			"title": "aws",
			"url": "http://gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "ci",
			"url": "http://dev.gssm-web.navercorp.com/jenkins/"
		}]
	}, {
		"title": "gssm-dev",
		"url": "http://gssm-web.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://dev.gssm-web.navercorp.com/"
		}, {
			"title": "batch",
			"url": "http://dev.gssm-web.navercorp.com/gomez/batch/"
		}, {
			 "title": "aws",
			"url": "http://dev.gssm-web.navercorp.com/awstats/awstats.gomez.html"
		}, {
			"title": "ci",
			"url": "http://dev.gssm-web.navercorp.com/jenkins/"
		}, {
			"title": "local",
			"url": "http://localhost/gomez/"
		}, {
			"title": "batch",
			"url": "http://localhost/gomez/batch/"
		}]
	}, {
		"title": "appd-real",
		"url": "http://appd.navercorp.com/",
		"children": [{
			"title": "web",
			"url": "http://appd.navercorp.com/"
		}, {
			"title": "batch",
			"url": "http://appd.navercorp.com/appd/batch/"
		}, {
			"title": "awstats",
			"url": "http://appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "BTS",
			"url": "http://bts4.navercorp.com/nhnbts/browse/APPD"
		}]
	}, {
		"title": "appd-dev",
		"url": "http://appd.navercorp.com/",
		"children": [{
			"title": "로컬",
			"url": "http://localhost/appd/"
		}, {
			"title": "배치",
			"url": "http://localhost/appd/batch/"
		}, {
			"title": "개발",
			"url": "http://dev.appd.navercorp.com/"
		}, {
			"title": "배치",
			"url": "http://dev.appd.navercorp.com/appd/batch/"
		}, {
			"title": "통계",
			"url": "http://dev.appd.navercorp.com/awstats/awstats.appd.html"
		}, {
			"title": "CI",
			"url": "http://dev.appd.navercorp.com/jenkins/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "Naver Install",
	"children": [{
		"title": "javascript",
		"url": "http://devcafe.navercorp.com/ajaxui/board_12/325898",
		"children": [{
			"title": "CI 환경구축 가이드",
			"url": "http://devcafe.navercorp.com/ajaxui/board_12/325898"
		}, {
			"title": "주석 문서 만들기",
			"url": "http://devcafe.navercorp.com/ajaxui/board_11/450678"
		}, {
			"title": "Test",
			"url": "http://docs.jquery.com/Qunit"
		}]
	}, {
		"title": "설치",
		"url": "http://devcafe.navercorp.com/index.php?mid=issuetracker&act=dispIssuetrackerDownload&vid=jdkwebwas",
		"children": [{
			"title": "설치 표준",
			"url": "http://devcafe.navercorp.com/index.php?mid=issuetracker&act=dispIssuetrackerDownload&vid=jdkwebwas"
		}, {
			"title": "QP.설치 표준",
			"url": "http://devcafe.navercorp.com/QPTalk/wiki_1"
		}, {
			"title": "허드슨 설치1",
			"url": "http://wikin.navercorp.com/pages/viewpage.action?pageId=67819814"
		}, {
			"title": "허드슨 설치2",
			"url": "http://wikin.navercorp.com/pages/viewpage.action?pageId=88121921"
		}]
	}]
});
bookmarks["children"].push({
	"title": "Naver 개발자 사이트",
	"children": [{
		"title": "사내 표준 α",
		"children": [{
			"title": "XML 인터페이스",
			"url": "http://moss.navercorp.com/sites/xmlapi/Documents/XML인터페이스개발자QuickReference.docx"
		}, {
			"title": "NHN 글쓰기 센터",
			"url": "http://tc.navercorp.com/"
		}]
	}, {
		"title": "사내 표준 β",
		"children": [{
			"title": "Quality Dashboard",
			"url": "http://nsiq.navercorp.com/"
		}, {
			"title": "QPTalk",
			"url": "http://devcafe.navercorp.com/QPTalk"
		}, {
			"title": "Coding Convention",
			"url": "http://moss.navercorp.com/sites/NPARK/guide/nccg/"
		}, {
			"title": "Check Style",
			"url": "http://devcode.navercorp.com/projects/csrs/"
		}]
	}, {
		"title": "사내 표준 γ",
		"children": [{
			"title": "N'SIQ Cpp Style",
			"url": "http://devcode.navercorp.com/projects/nsiqcppcheck"
		}, {
			"title": "knit",
			"url": "http://knit.naver.com/"
		}]
	}]
});
bookmarks["children"].push({
	"title": "Data Refenence",
	"children": [{
		"title": "아이콘",
		"children": [{
			"title": "alpha",
			"url": "http://www.iconfinder.com/"
		}, {
			"title": "bravo",
			"url": "http://findicons.com/"
		}]
	}, {
		"title": "HTML",
		"children": [{
			"title": "Color",
			"url": "https://www.w3schools.com/colors/"
		}, {
			"title": "Symbol",
			"url": "https://www.toptal.com/designers/htmlarrows/"
		}]
	}, {
		"title": "바탕화면",
		"children": [{
			"title": "alpha",
			"url": "http://wallpaperswide.com/"
		}]
	}, {
		"title": "기타",
		"children": [{
			"title": "프레젠테이션",
			"url": "http://www.slideshare.net/"
		}, {
			"title": "논문",
			"url": "http://www.mendeley.com/"
		}, {
			"title": "SVG Tools",
			"url": "http://www.openclipart.org/wiki/SVG_Tools"
		}]
	}]
});
