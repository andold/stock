﻿function	DisplayStyle()
{
	var	str;
	str	=	"<STYLE>\n"
		+ "body	{	font-family:\"나눔고딕\",\"나눔고딕\",\"SEOUL\";\n"
		+ "				font-size:9pt;\n"
		+ "				margin-left:0;\n"
		+ "				margin-right:0;\n"
		+ "				margin-top:0;\n"
		+ 					"BACKGROUND-COLOR:white;\n"
		+ 					"COLOR:black;\n"
		+ "			}\n"
		+ "td {font-family:\"나눔고딕\",\"나눔고딕\",\"SEOUL\";font-size:9pt;"
		+ "}\n"
		+ "a:hover {text-decoration:underline;}\n"
		+ "a:link {text-decoration:none;color:black;}\n"
		+ "a:visited {text-decoration:none;color:black;}\n"
		+ ".home	{color:white;font-size:16pt;font-weight:bold;font-style:italic;}\n"
		+ ".home	A {color:white;font-size:16pt;font-weight:bold;font-style:italic;}\n"
		+ ".home	A:hover {color:#CCCCCC;text-decoration:none;}\n"
		+ ".home	a:link {text-decoration:none;color:white;}\n"
		+ ".home	a:visited {text-decoration:none;color:white;}\n"
		+ ".home1	{color:white;font-size:10pt;font-weight:bold;}\n"
		+ ".home1	A {color:white;font-size:10pt;font-weight:bold;}\n"
		+ ".home1	A:hover {color:#CCCCCC;text-decoration:none;}\n"
		+ ".home1	a:link {text-decoration:none;color:white;}\n"
		+ ".home1	a:visited {text-decoration:none;color:white;}\n"
		+ ".head1	{color:white;font-size:16pt;font-weight:bold;}\n"
		+ ".head1	a {color:white;font-size:16pt;font-weight:bold;}\n"
		+ ".head1	a:hover {color:#CCCCCC;text-decoration:none;}\n"
		+ ".head1	a:link {text-decoration:none;color:white;}\n"
		+ ".head1	a:visited {text-decoration:none;color:white;}\n"
		+ ".normal	{color:white;font-size:9pt;}\n"
		+ ".normal	a {color:white;font-size:16pt;font-weight:bold;}\n"
		+ ".normal	a:hover {color:#CCCCCC;text-decoration:none;}\n"
		+ ".normal	a:link {text-decoration:none;color:white;}\n"
		+ ".normal	a:visited {text-decoration:none;color:white;}\n"
		+ "</STYLE>\n";
	document.write(str);
}
function	DisplayHeader(strPath)
{
	var	str;
	str	=	"<table width=100% border=0 cellpadding=10 cellspacing=0>\n"
		+		"<tr bgcolor=darkblue>\n"
		+			"<td>\n"
		+				"<table width=100% align=left border=0 cellpadding=0 cellspacing=0>\n"
		+					"<tr>\n"
		+						"<td width=20 align=left></td>\n"
		+						"<td width=120 align=left><font class=home>무자</font></td>\n"
		+						"<td align=left>\n"
		+							"<font class=home1>\n"
		+								"| <a href=\"" + strPath + "/links.htm\">Links</a>\n"
		+								"| <a href=\"" + strPath + "/Memo.htm\">끄적이기</a>\n"
		+							"</font>\n"
		+						"</td>\n"
		+						"<td align=right><a href=\"mailto:권과헌<andold@naver.com>\"><img src=\"" + strPath + "/Images/EMail.gif\" border=0></a></td>\n"
		+						"<td width=20 align=right></td>\n"
		+					"</tr>\n"
		+				"</table>\n"
		+			"</td>\n"
		+		"</tr>\n"
		+	"<table>\n";
	document.write(str);
}
function	DisplayFooter(strPath)
{
	var	str;
	str	=	"<table width=100% border=0 cellpadding=10 cellspacing=0>"
		+	"	<tr bgcolor=darkblue>"
		+		"	<td>"
		+			"	<table align=left border=0 cellpadding=0 cellspacing=0>"
		+				"	<tr>"
		+					"	<td width=5 align=left></td>"
		+					"	<td width=100 align=left><font class=home1>쥔장:무자</font></td>"
		+					"	<td width=50 align=right></td>"
		+				"	</tr>"
		+			"	</table>"
		+		"	</td>"
		+	"	</tr>"
		+"</table>";
	document.write(str);
}
DisplayStyle();